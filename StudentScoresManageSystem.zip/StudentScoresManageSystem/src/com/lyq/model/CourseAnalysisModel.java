package com.lyq.model;

public class CourseAnalysisModel {
	
	private int jionNum = 0;
	private int noneScore = 0;
	private int f0t60 = 0;
	private int f60t70 = 0;
	private int f70to80 = 0;
	private int f80to90 = 0;
	private int f90to100 = 0;
	private int f100 = 0;
	private double ave = 0;
	private double std = 0;
	private double failRate = 0;
	private double max = 0;
	private double min = 0;
	private int classNum = 0;
	private String classname = null;
	public int getJionNum() {
		return jionNum;
	}
	public void setJionNum(int jionNum) {
		this.jionNum = jionNum;
	}
	public int getNoneScore() {
		return noneScore;
	}
	public void setNoneScore(int noneScore) {
		this.noneScore = noneScore;
	}
	public int getF0t60() {
		return f0t60;
	}
	public void setF0t60(int f0t60) {
		this.f0t60 = f0t60;
	}
	public int getF60t70() {
		return f60t70;
	}
	public void setF60t70(int f60t70) {
		this.f60t70 = f60t70;
	}
	public int getF70to80() {
		return f70to80;
	}
	public void setF70to80(int f70to80) {
		this.f70to80 = f70to80;
	}
	public int getF80to90() {
		return f80to90;
	}
	public void setF80to90(int f80to90) {
		this.f80to90 = f80to90;
	}
	public int getF90to100() {
		return f90to100;
	}
	public void setF90to100(int f90to100) {
		this.f90to100 = f90to100;
	}
	public int getF100() {
		return f100;
	}
	public void setF100(int f100) {
		this.f100 = f100;
	}
	public double getAve() {
		return ave;
	}
	public void setAve(double ave) {
		this.ave = ave;
	}
	public double getStd() {
		return std;
	}
	public void setStd(double std) {
		this.std = std;
	}
	public double getFailRate() {
		return failRate;
	}
	public void setFailRate(double failRate) {
		this.failRate = failRate;
	}
	public double getMax() {
		return max;
	}
	public void setMax(double max) {
		this.max = max;
	}
	public double getMin() {
		return min;
	}
	public void setMin(double min) {
		this.min = min;
	}
	public int getClassNum() {
		return classNum;
	}
	public void setClassNum(int classNum) {
		this.classNum = classNum;
	}
	
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public CourseAnalysisModel(int jionNum, int noneScore, int f0t60, int f60t70, int f70to80, int f80to90,
			int f90to100, int f100, double ave, double std, double failRate, double max, double min, String classname) {
		super();
		this.jionNum = jionNum;
		this.noneScore = noneScore;
		this.f0t60 = f0t60;
		this.f60t70 = f60t70;
		this.f70to80 = f70to80;
		this.f80to90 = f80to90;
		this.f90to100 = f90to100;
		this.f100 = f100;
		this.ave = ave;
		this.std = std;
		this.failRate = failRate;
		this.max = max;
		this.min = min;
		this.classname = classname;
	}
	public CourseAnalysisModel() {
		super();
	}
	@Override
	public String toString() {
		return "CourseAnalysisModel [jionNum=" + jionNum + ", noneScore=" + noneScore + ", f0t60=" + f0t60 + ", f60t70="
				+ f60t70 + ", f70to80=" + f70to80 + ", f80to90=" + f80to90 + ", f90to100=" + f90to100 + ", f100=" + f100
				+ ", ave=" + ave + ", std=" + std + ", failRate=" + failRate + ", max=" + max + ", min=" + min
				+ ", classNum=" + classNum + "]";
	}
	
}
