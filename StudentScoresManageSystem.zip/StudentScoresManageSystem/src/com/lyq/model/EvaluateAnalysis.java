package com.lyq.model;

public class EvaluateAnalysis {

	private String Cname = null;
	private String CourseId = null;
	private int lessonfcmy = 0;	//对课堂教学觉得非常满意的学生数量
	private int lessonhmy = 0;	//对课堂教学觉得很满意的学生数量
	private int lessonmy = 0;	//对课堂教学觉得满意的学生数量
	private int lessonyb = 0;	//对课堂教学觉得一般的学生数量
	private int lessonbmy = 0;	//对课堂教学觉得不满意的学生数量
	private int homeworkfcmy = 0;	//对作业批改觉得非常满意的学生数量
	private int homeworkhmy = 0;	//对作业批改觉得很满意的学生数量
	private int homeworkmy = 0;	//对作业批改觉得满意的学生数量
	private int homeworkyb = 0;	//对作业批改觉得一般的学生数量
	private int homeworkbmy = 0;	//对作业批改觉得不满意的学生数量
	private int jionNum = 0; //参加课程的学生数量
	private int evaluated = 0;//已经进行评价的学生数量
	private double satisfactoryRate = 0; //满意率（只有当课堂教学和作业批改的满意时才算满意）
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getCourseId() {
		return CourseId;
	}
	public void setCourseId(String courseId) {
		CourseId = courseId;
	}
	public int getJionNum() {
		return jionNum;
	}
	public void setJionNum(int jionNum) {
		this.jionNum = jionNum;
	}
	public int getEvaluated() {
		return evaluated;
	}
	public void setEvaluated(int evaluated) {
		this.evaluated = evaluated;
	}
	public int getLessonfcmy() {
		return lessonfcmy;
	}
	public void setLessonfcmy(int lessonfcmy) {
		this.lessonfcmy = lessonfcmy;
	}
	public int getLessonhmy() {
		return lessonhmy;
	}
	public void setLessonhmy(int lessonhmy) {
		this.lessonhmy = lessonhmy;
	}
	public int getLessonmy() {
		return lessonmy;
	}
	public void setLessonmy(int lessonmy) {
		this.lessonmy = lessonmy;
	}
	public int getLessonyb() {
		return lessonyb;
	}
	public void setLessonyb(int lessonyb) {
		this.lessonyb = lessonyb;
	}
	public int getLessonbmy() {
		return lessonbmy;
	}
	public void setLessonbmy(int lessonbmy) {
		this.lessonbmy = lessonbmy;
	}
	public int getHomeworkfcmy() {
		return homeworkfcmy;
	}
	public void setHomeworkfcmy(int homeworkfcmy) {
		this.homeworkfcmy = homeworkfcmy;
	}
	public int getHomeworkhmy() {
		return homeworkhmy;
	}
	public void setHomeworkhmy(int homeworkhmy) {
		this.homeworkhmy = homeworkhmy;
	}
	public int getHomeworkmy() {
		return homeworkmy;
	}
	public void setHomeworkmy(int homeworkmy) {
		this.homeworkmy = homeworkmy;
	}
	public int getHomeworkyb() {
		return homeworkyb;
	}
	public void setHomeworkyb(int homeworkyb) {
		this.homeworkyb = homeworkyb;
	}
	public int getHomeworkbmy() {
		return homeworkbmy;
	}
	public void setHomeworkbmy(int homeworkbmy) {
		this.homeworkbmy = homeworkbmy;
	}
	public double getSatisfactoryRate() {
		return satisfactoryRate;
	}
	public void setSatisfactoryRate(double satisfactoryRate) {
		this.satisfactoryRate = satisfactoryRate;
	}
	public EvaluateAnalysis() {
		super();
	}
	public EvaluateAnalysis(String cname, String courseId, int lessonfcmy, int lessonhmy, int lessonmy, int lessonyb,
			int lessonbmy, int homeworkfcmy, int homeworkhmy, int homeworkmy, int homeworkyb, int homeworkbmy,
			int jionNum, int evaluated, double satisfactoryRate) {
		super();
		Cname = cname;
		CourseId = courseId;
		this.lessonfcmy = lessonfcmy;
		this.lessonhmy = lessonhmy;
		this.lessonmy = lessonmy;
		this.lessonyb = lessonyb;
		this.lessonbmy = lessonbmy;
		this.homeworkfcmy = homeworkfcmy;
		this.homeworkhmy = homeworkhmy;
		this.homeworkmy = homeworkmy;
		this.homeworkyb = homeworkyb;
		this.homeworkbmy = homeworkbmy;
		this.jionNum = jionNum;
		this.evaluated = evaluated;
		this.satisfactoryRate = satisfactoryRate;
	}
	@Override
	public String toString() {
		return "EvaluateAnalysis [Cname=" + Cname + ", CourseId=" + CourseId + ", lessonfcmy=" + lessonfcmy
				+ ", lessonhmy=" + lessonhmy + ", lessonmy=" + lessonmy + ", lessonyb=" + lessonyb + ", lessonbmy="
				+ lessonbmy + ", homeworkfcmy=" + homeworkfcmy + ", homeworkhmy=" + homeworkhmy + ", homeworkmy="
				+ homeworkmy + ", homeworkyb=" + homeworkyb + ", homeworkbmy=" + homeworkbmy + ", jionNum=" + jionNum
				+ ", evaluated=" + evaluated + ", satisfactoryRate=" + satisfactoryRate + "]";
	}
	
	
}
