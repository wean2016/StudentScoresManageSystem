package com.lyq.model;

public class Manage {
	private int wrongTimes;
	private int isLocking;
	private String id;
	private String password;
	public Manage() {
		super();
	}
	public Manage(String id, String password) {
		super();
		this.id = id;
		this.password = password;
	}
	public int getWrongTimes() {
		return wrongTimes;
	}
	public void setWrongTimes(int wrongTimes) {
		this.wrongTimes = wrongTimes;
	}
	public int getIsLocking() {
		return isLocking;
	}
	public void setIsLocking(int isLocking) {
		this.isLocking = isLocking;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
