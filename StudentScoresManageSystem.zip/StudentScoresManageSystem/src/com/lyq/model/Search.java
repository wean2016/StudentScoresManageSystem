package com.lyq.model;
/**
 * 成绩查询的模型
 * @author hasee
 *
 */
public class Search {
	
	private String exam;	//查询的测验
	private String stuGrade;	//查询的年级
	private String stuClass;	//查询的班级
	private String name;	//查询的姓名
	private String course;//要查询的课程、学号或者绩点
	private int start;	//查询的起点
	private Long end;	//查询的终点
	private String sequence;	//结果的顺序
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public Long getEnd() {
		return end;
	}
	public void setEnd(Long end) {
		this.end = end;
	}
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	public String getExam() {
		return exam;
	}
	public void setExam(String exam) {
		this.exam = exam;
	}
	public String getStuGrade() {
		return stuGrade;
	}
	public void setStuGrade(String stuGrade) {
		this.stuGrade = stuGrade;
	}
	public String getStuClass() {
		return stuClass;
	}
	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Search() {
		super();
	}
	public Search(String exam, String stuGrade, String stuClass, String name, String course, int start, Long end,
			String sequence) {
		super();
		this.exam = exam;
		this.stuGrade = stuGrade;
		this.stuClass = stuClass;
		this.name = name;
		this.course = course;
		this.start = start;
		this.end = end;
		this.sequence = sequence;
	}
}
