package com.lyq.model;

import java.util.Date;
import java.util.List;

public class InformSearchModel {

	private Date start = null;
	private Date end = null;
	private List<String> keywords = null;
	private String sequence = null;

	public InformSearchModel() {
	}

	public InformSearchModel(Date start, Date end, List<String> keywords, String sequence) {
		super();
		this.start = start;
		this.end = end;
		this.keywords = keywords;
		this.sequence = sequence;
	}

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getEnd() {
		return end;
	}

	public void setEnd(Date end) {
		this.end = end;
	}

	public List<String> getKeywords() {
		return keywords;
	}

	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

}
