package com.lyq.model;

public class Evaluate {
	
	private String student_id;
	private String teacher_id;
	private String lesson;
	private String homework;
	private String CourseId;
	private String Cname;
	private String Teachername;
	private String term;
	private int evaluated = 0;
	
	public String getStudent_id() {
		return student_id;
	}

	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}

	public String getTeacher_id() {
		return teacher_id;
	}

	public void setTeacher_id(String teacher_id) {
		this.teacher_id = teacher_id;
	}

	public String getLesson() {
		return lesson;
	}

	public void setLesson(String lesson) {
		this.lesson = lesson;
	}

	public String getHomework() {
		return homework;
	}

	public void setHomework(String homework) {
		this.homework = homework;
	}

	public String getCourseId() {
		return CourseId;
	}

	public void setCourseId(String courseId) {
		CourseId = courseId;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getCname() {
		return Cname;
	}

	public void setCname(String cname) {
		Cname = cname;
	}

	public String getTeachername() {
		return Teachername;
	}

	public void setTeachername(String teachername) {
		Teachername = teachername;
	}

	public int getEvaluated() {
		return evaluated;
	}

	public void setEvaluated(int evaluated) {
		this.evaluated = evaluated;
	}

	public Evaluate() {
		super();
	}

	public Evaluate(String teacher_id, String courseId, String term) {
		super();
		this.teacher_id = teacher_id;
		CourseId = courseId;
		this.term = term;
	}

	public Evaluate(String student_id, String teacher_id, String courseId, String term) {
		super();
		this.student_id = student_id;
		this.teacher_id = teacher_id;
		CourseId = courseId;
		this.term = term;
	}
	
}
