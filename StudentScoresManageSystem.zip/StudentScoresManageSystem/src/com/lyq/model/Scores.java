package com.lyq.model;

public class Scores {

	private String term = null;
	private String stuClass = null;
	private String CourseId = null;
	private String Cname = null;
	private String StudentId = null;
	private double credit = 0;
	private double score = 0;
	private double GPA = 0;
	private String TeacherName;
	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getStuClass() {
		return stuClass;
	}

	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}

	public String getCourseId() {
		return CourseId;
	}

	public void setCourseId(String courseId) {
		CourseId = courseId;
	}

	public String getStudentId() {
		return StudentId;
	}

	public void setStudentId(String studentId) {
		StudentId = studentId;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public double getGPA() {
		return GPA;
	}

	public void setGPA(double gPA) {
		GPA = gPA;
	}

	public String getCname() {
		return Cname;
	}

	public void setCname(String cname) {
		Cname = cname;
	}

	public double getCredit() {
		return credit;
	}

	public void setCredit(double credit) {
		this.credit = credit;
	}

	public String getTeacherName() {
		return TeacherName;
	}

	public void setTeacherName(String teacherName) {
		TeacherName = teacherName;
	}

	public Scores(String stuClass, String courseId, String cname, double credit, double score, double gPA) {
		super();
		this.stuClass = stuClass;
		CourseId = courseId;
		Cname = cname;
		this.credit = credit;
		this.score = score;
		GPA = gPA;
	}

	public Scores(String courseId, String cname, double credit, double score, double gPA) {
		super();
		CourseId = courseId;
		Cname = cname;
		this.credit = credit;
		this.score = score;
		GPA = gPA;
	}

	public Scores(String term, String stuClass, String courseId, String studentId) {
		super();
		this.term = term;
		this.stuClass = stuClass;
		CourseId = courseId;
		StudentId = studentId;
	}

	public Scores() {
		super();
	}

	public Scores(String term, String courseId) {
		super();
		this.term = term;
		CourseId = courseId;
	}

	@Override
	public String toString() {
		return "Scores [term=" + term + ", stuClass=" + stuClass + ", CourseId=" + CourseId + ", Cname=" + Cname
				+ ", StudentId=" + StudentId + ", credit=" + credit + ", score=" + score + ", GPA=" + GPA
				+ ", TeacherName=" + TeacherName + "]";
	}

}
