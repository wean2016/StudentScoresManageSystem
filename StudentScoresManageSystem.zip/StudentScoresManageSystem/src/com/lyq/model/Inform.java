package com.lyq.model;

import java.util.Date;

public class Inform {
	private int id;
	private String publisher;
	private Date publishTime;
	private Date updateTime;
	private String title;
	private String content;
	private String attachmentName;
	private String attachmentUrl;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public Date getPublishTime() {
		return publishTime;
	}
	public void setPublishTime(Date publishTime) {
		this.publishTime = publishTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAttachmentName() {
		return attachmentName;
	}
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}
	public String getAttachmentUrl() {
		return attachmentUrl;
	}
	public void setAttachmentUrl(String attachmentUrl) {
		this.attachmentUrl = attachmentUrl;
	}
	public Inform() {
		super();
	}
	@Override
	public String toString() {
		return "Inform [id=" + id + ", publisher=" + publisher + ", publishTime=" + publishTime + ", updateTime="
				+ updateTime + ", title=" + title + ", content=" + content + ", attachmentName=" + attachmentName
				+ ", attachmentUrl=" + attachmentUrl + "]";
	}
	
	
}
