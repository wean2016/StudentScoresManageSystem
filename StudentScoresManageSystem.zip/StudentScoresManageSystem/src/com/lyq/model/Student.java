package com.lyq.model;

public class Student {
	private int wrongTimes;
	private int isLocking;
	private String id;
	private String password;
	private String name;
	private String gender;
	private String phone;
	private String address;
	private String e_mail;
	private String pic;
	private int stuGrade;
	private String stuClass;
	//定义查询成绩相关属性
	private String exam;
	private double score;
	private double GPA;
	private int index;
	private double PassCourseSum;
	private double failSum;
	private double courseSum;
	private double passRate;
	private double ave;
	public Student() {
		super();
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public int getWrongTimes() {
		return wrongTimes;
	}
	public void setWrongTimes(int wrongTimes) {
		this.wrongTimes = wrongTimes;
	}
	public int getIsLocking() {
		return isLocking;
	}
	public void setIsLocking(int isLocking) {
		this.isLocking = isLocking;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getE_mail() {
		return e_mail;
	}
	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}
	public int getStuGrade() {
		return stuGrade;
	}
	public void setStuGrade(int stuGrade) {
		this.stuGrade = stuGrade;
	}
	public String getStuClass() {
		return stuClass;
	}
	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}
	
	public double getGPA() {
		return GPA;
	}
	public void setGPA(double gPA) {
		GPA = gPA;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	
	public String getExam() {
		return exam;
	}
	public void setExam(String exam) {
		this.exam = exam;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public double getPassCourseSum() {
		return PassCourseSum;
	}
	public void setPassCourseSum(double passCourseSum) {
		PassCourseSum = passCourseSum;
	}
	public double getCourseSum() {
		return courseSum;
	}
	public void setCourseSum(double courseSum) {
		this.courseSum = courseSum;
	}
	public double getPassRate() {
		return passRate;
	}
	public void setPassRate(double passRate) {
		this.passRate = passRate;
	}
	public double getAve() {
		return ave;
	}
	public void setAve(double ave) {
		this.ave = ave;
	}
	public double getFailSum() {
		return failSum;
	}
	public void setFailSum(double failSum) {
		this.failSum = failSum;
	}
	
	
	
	
}
