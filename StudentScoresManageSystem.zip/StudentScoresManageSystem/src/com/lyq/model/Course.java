package com.lyq.model;

public class Course {

	public Course() {
	}
	private String term = null;
	private String CourseId = null;
	private String Cname = null;
	private String TeacherId = null;
	private double credit = 0;
	private String TeacherName = null;
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getCourseId() {
		return CourseId;
	}
	public void setCourseId(String courseId) {
		CourseId = courseId;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getTeacherId() {
		return TeacherId;
	}
	public void setTeacherId(String teacherId) {
		TeacherId = teacherId;
	}
	
	public double getCredit() {
		return credit;
	}
	public void setCredit(double credit) {
		this.credit = credit;
	}
	public String getTeacherName() {
		return TeacherName;
	}
	public void setTeacherName(String teacherName) {
		TeacherName = teacherName;
	}
	public Course(String term, String courseId, String cname) {
		super();
		this.term = term;
		CourseId = courseId;
		Cname = cname;
	}
	public Course(String term, String courseId, String cname, String teacherId) {
		super();
		this.term = term;
		CourseId = courseId;
		Cname = cname;
		TeacherId = teacherId;
	}
	public Course(String term, String courseId, String cname, double credit) {
		super();
		this.term = term;
		CourseId = courseId;
		Cname = cname;
		this.credit = credit;
	}
	public Course(String term, String courseId, String cname, String teacherId, double credit) {
		super();
		this.term = term;
		CourseId = courseId;
		Cname = cname;
		TeacherId = teacherId;
		this.credit = credit;
	}
	@Override
	public String toString() {
		return "Course [term=" + term + ", CourseId=" + CourseId + ", Cname=" + Cname + ", TeacherId=" + TeacherId
				+ ", credit=" + credit + ", TeacherName=" + TeacherName + "]";
	}
	

}
