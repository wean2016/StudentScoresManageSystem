package com.lyq.util;

import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.codec.binary.Base64;

public class PBEUtils {

	public PBEUtils() {
	}

	/**
	 * 定义PBE加密
	 * 
	 * @param id
	 *            将传入的id作为盐
	 * @param password
	 *            将密码作为加密对象
	 * @return 返回加密后的密码字符串
	 * @throws Exception
	 */
	public String encrypt(String id, String password) {
		try {
			// 初始化盐
			byte[] salt = new byte[8]; // 定义盐
			byte[] b = id.getBytes();
			for (int i = 0; i < 7; i++) {
				salt[i] = b[i];
			}
			int iterationCount = 49; // 定义撒盐次数为49次

			// 定义口令和密钥
			String secretkey = "StudentScoresManageSystem";// 定义PBE口令
			PBEKeySpec pbeKeySpec = new PBEKeySpec(secretkey.toCharArray());
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBEWITHMD5andDES");
			Key key = factory.generateSecret(pbeKeySpec);// 密钥

			// 加密
			PBEParameterSpec pbeParameterSpec = new PBEParameterSpec(salt, iterationCount);
			Cipher cipher = Cipher.getInstance("PBEWITHMD5andDES");
			cipher.init(Cipher.ENCRYPT_MODE, key, pbeParameterSpec);
			String result = Base64.encodeBase64String(cipher.doFinal(password.getBytes()));
			
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static void main(String[] args){
		PBEUtils u = new PBEUtils();
		System.out.println("tch567123    " + u.encrypt("tch567123", "123456"));
	}
}
