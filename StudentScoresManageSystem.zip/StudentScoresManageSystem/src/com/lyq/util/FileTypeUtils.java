package com.lyq.util;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

public class FileTypeUtils {

	public FileTypeUtils() {}
	
	public final static Map<String, String> FILE_TYPE_MAP = new HashMap<String, String>();
	
	static{
		getAllFileType();// 初始化文件类型信息
	}
	/**
	 * 定义文件偷信息
	 */
	private static void getAllFileType(){
		FILE_TYPE_MAP.put(".jpg", "FFD8FF");// JPEG (jpg)
		FILE_TYPE_MAP.put(".png", "89504E47");// PNG (png)
		FILE_TYPE_MAP.put(".gif", "47494638");// GIF (gif)
		FILE_TYPE_MAP.put(".bmp", "424D");// Windows Bitmap (bmp)
		FILE_TYPE_MAP.put(".zip", "504B0304");// zip 压缩文件
		FILE_TYPE_MAP.put(".rar", "52617221");// rar 压缩文件
	}
	//用此函数前先确认是图片
	public final static String getImageFileType(InputStream ips){
		try {
			ImageInputStream iis = ImageIO.createImageInputStream(ips);
			Iterator<ImageReader> iter = ImageIO.getImageReaders(iis);
			if(!iter.hasNext()){
				return null;
			}
			ImageReader reader = iter.next();
			iis.close();
			return "."+reader.getFormatName();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	/**
	 * 判断文件是否是图片
	 * @param ips 文件的Stream流
	 * @return	true 是 | false 否
	 */
	public static final boolean isImage(InputStream ips) {
		boolean flag = false;
		try {
			BufferedImage bufreader = ImageIO.read(ips);
			int width = bufreader.getWidth();
			int height = bufreader.getHeight();
			if(width==0 || height==0){
				flag = false;
			}else{
				flag = true;
			}
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}
	public final static String getFileType(InputStream ips){
		String fileType = null;
		byte[] b = new byte[50];//储存文件流的前几个字符，用来判断文件类型
		try {
			ips.read(b);
			String fileTypeHex = String.valueOf(getFileHexString(b));
			Iterator<Entry<String,String>> entryiterator = FILE_TYPE_MAP.entrySet().iterator();
			while(entryiterator.hasNext()){
				Entry<String,String> entry = entryiterator.next();
				String fileTypeHexValue = entry.getValue();
				if(fileTypeHex.toUpperCase().startsWith(fileTypeHexValue)){
					return entry.getKey();
				}
			}
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	private final static String getFileHexString(byte[] b){
		StringBuilder sb = new StringBuilder();
		if(b == null || b.length <= 0){
			return null;
		}
		for(int i = 0; i < b.length; i++){
			int value = b[i] & 0xFF;	//不懂目的
			String hexValue = Integer.toHexString(value);
			if(hexValue.length() < 2){
				sb.append(0);
			}
			sb.append(hexValue);
		}
		return sb.toString();
	}
	
}
