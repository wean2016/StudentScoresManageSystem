package com.lyq.util;

import java.util.Iterator;
import java.util.List;

import com.lyq.model.Scores;

public class CalStudentTermGPA {
	
	//计算某个学生一个学期的绩点
	public static double getGPA(List<Scores> s){
		double numerator = 0;
		double denominator = 0;
		Iterator<Scores> iter = s.iterator();
		Scores sc = null;
		while(iter.hasNext()){
			sc = iter.next();
			//判断该课程是否已经给分,若已经给分，则进行计算，若未给分，则略过
			if(sc.getScore() > 0){
				numerator += sc.getGPA() * sc.getCredit();
				denominator += sc.getCredit();
			}
		}
		//判断分子分母是否为0，若一个以上为0，则返回0，否则计算计算返回
		if(numerator == 0 || denominator == 0){
			return 0;
		}else{
			return numerator / denominator;
		}
	}

}
