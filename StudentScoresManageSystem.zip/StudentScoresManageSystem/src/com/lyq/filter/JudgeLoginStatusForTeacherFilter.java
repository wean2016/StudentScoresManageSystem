package com.lyq.filter;

import java.io.IOException;
import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class JudgeLoginStatusForTeacherFilter implements Filter {
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest req = (HttpServletRequest) request;
		HttpSession session = req.getSession();
		//检查是否有登陆标记和登陆账号是否为空
		boolean logined = false;
		boolean isTeacher = false;
		if(session.getAttribute("logined") != null){
			logined = (Boolean) session.getAttribute("logined");
			isTeacher = (session.getAttribute("tch_info") != null)?true:false;
		}
		if(logined && isTeacher){
			chain.doFilter(request, response);
		}else{
			response.getWriter().print("请登陆！三秒后自动前往登陆页面");
			response.getWriter().print("<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/login.jsp'\",3000)</script>");
			
		}
	}


	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}


	@Override
	public void destroy() {
		// TODO 自动生成的方法存根
		
	}

}
