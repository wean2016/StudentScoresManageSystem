package com.lyq.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.xml.GetterType;

import com.lyq.model.Course;
import com.lyq.model.Manage;
import com.lyq.model.Pager;
import com.lyq.model.Student;
import com.lyq.model.Teacher;

public class ManageDao {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String url = "jdbc:mysql://localhost:3306/db_studentscoremanagesystem";
	private String user = "root";
	private String password = "root";
	// 定义操作时要用到的变量
	private String sql = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	/**
	 * 定义内部函数开始
	 */
	// 获取连接
	private Connection getConnection() throws SQLException {
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}

	// 关闭操作和连接
	private void closeOperate() throws Exception {
		pst.close();
		conn.close();
	}

	/**
	 * 检查管理员账号状态
	 * 
	 * @param id
	 *            传入的管理员账号id
	 * @return 返回null代表无此管理员，否则将该管理员的密码错误次数和锁定状态打包返回
	 * @throws Exception
	 */
	public Manage checkManageStatus(String id) throws Exception {
		Manage mng = null;
		conn = getConnection();
		sql = "select wrongTimes,isLocking from t_manage where id=?";
		pst = conn.prepareStatement(sql);

		pst.setString(1, id);

		rs = pst.executeQuery();

		if (rs.next()) {
			mng = new Manage();
			mng.setId(id);
			mng.setWrongTimes(rs.getInt("wrongTimes"));
			mng.setIsLocking(rs.getInt("isLocking"));
			closeOperate();
			return mng;
		} else {
			closeOperate();
			return null;
		}
	}

	/**
	 * 更新管理员账号密码错误次数和锁定状态
	 * 
	 * @param id
	 *            要操作的管理员对象的id
	 * @param operation
	 *            true为密码错误增加一次，false为密码错误次数清零并解除锁定状态 当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return true为账号正常或者被修改为正常，false为账号被锁定
	 * @throws Exception
	 */
	public boolean updateManageStatus(String id, boolean operation) throws Exception {
		Manage mng = checkManageStatus(id);
		conn = getConnection();
		if (operation) {
			int times = mng.getWrongTimes() + 1;
			mng.setWrongTimes(times);
			if (times >= 3) {
				sql = "update t_manage set wrongTimes=?,isLocking=1 where id=?";
				pst = conn.prepareStatement(sql);
				pst.setInt(1, times);
				pst.setString(2, id);
				pst.executeUpdate();
				closeOperate();

				return false;
			} else {
				sql = "update t_manage set wrongTimes=? where id=?";
				pst = conn.prepareStatement(sql);
				pst.setInt(1, times);
				pst.setString(2, id);
				pst.executeUpdate();
				closeOperate();
				return true;
			}
		} else {
			sql = "update t_manage set wrongTimes=0,isLocking=0 where id=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			pst.executeUpdate();
			closeOperate();
			return true;
		}
	}

	// 精确查询
	public Manage findManageById(String id) {
		try {
			conn = getConnection();
			sql = "select * from t_manage where id=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, id);
			rs = pst.executeQuery();

			if (rs.next()) { // 判断是否查询到该管理员
				Manage mng = new Manage(); // 如果查找到该管理员
				mng.setId(rs.getString("id"));
				mng.setPassword(rs.getString("password"));
				closeOperate();
				return mng;
			} else {
				closeOperate();
				return null; // 查找不到该管理员
			}
		} catch (Exception e) {
			return null; // 程序出错
		}

	}

	/**
	 * 定义结束
	 */
	// 查找所有管理员
	public List<Manage> findAllManage() throws Exception {
		List<Manage> list = new ArrayList<Manage>();
		Manage mn = null;
		conn = getConnection();
		sql = "select * from t_manage";
		pst = conn.prepareStatement(sql);

		rs = pst.executeQuery();

		while (rs.next()) {
			mn = new Manage();
			mn.setId(rs.getString("id"));
			mn.setPassword(rs.getString("password"));

			list.add(mn);
		}
		closeOperate();
		return list;
	}

	// 添加课程
	public boolean addCourse(Course crs) {
		try {
			conn = getConnection();
			sql = "INSERT INTO t_course(term, CourseId, Cname, TeacherId, credit) VALUE(?, ?, ?, ?, ?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, crs.getTerm());
			pst.setString(2, crs.getCourseId());
			pst.setString(3, crs.getCname());
			pst.setString(4, crs.getTeacherId());
			pst.setDouble(5, crs.getCredit());

			pst.executeUpdate();
			closeOperate();

			return true; // 添加成功
		} catch (Exception e) {
			return false; // 添加失败
		}
	}

	// 查找课程
	/**
	 * 定义分页查询
	 * 
	 * @param searchModel
	 *            传入要查询的条件
	 * @param pageNum
	 *            要查看第几页数据
	 * @param pageSize
	 *            每页显示多少条数据
	 * @return 将搜索到的数据打包返回
	 */
	public Pager<Course> findCourse(Course searchModel, int pageNum, int pageSize) {
		Pager<Course> result = null;
		// 存放查询参数
		List<Object> paramList = new ArrayList<Object>();
		// 定义基础查询语句
		StringBuilder sql = new StringBuilder(
				"SELECT c.CourseId,c.Cname,c.term,c.credit,c.TeacherId,t.`name` FROM t_course as c LEFT JOIN t_teacher as t ON c.TeacherId=t.id WHERE 1=1");
		StringBuilder countSql = new StringBuilder(
				"SELECT count(c.CourseId) as totalRecord FROM t_course as c LEFT JOIN t_teacher as t ON c.TeacherId=t.id WHERE 1=1");
		// 添加查询条件
		String Cname = searchModel.getCname();
		if (Cname != null && !"".equals(Cname)) {
			sql.append(" and c.Cname like ?");
			countSql.append(" and c.Cname like ?");
			paramList.add("%" + Cname + "%");
		}

		String term = searchModel.getTerm();
		if (term != null && !"".equals(term)) {
			sql.append(" and c.term=?");
			countSql.append(" and c.term=?");
			paramList.add(term);
		}

		String CourseId = searchModel.getCourseId();
		if (term != null && !"".equals(term)) {
			sql.append(" and c.CourseId=?");
			countSql.append(" and c.CourseId=?");
			paramList.add(CourseId);
		}

		String TeacherId = searchModel.getTeacherId();
		if (TeacherId != null && !"".equals(TeacherId)) {
			sql.append(" and c.TeacherId=?");
			countSql.append(" and c.TeacherId=?");
			paramList.add(TeacherId);
		}

		String name = searchModel.getTeacherName();
		if (name != null && !"".equals(name)) {
			sql.append(" and t.`name` like ?");
			countSql.append(" and t.`name` like ?");
			paramList.add("%" + name + "%");
		}

		// 起始索引
		int fromIndex = pageSize * (pageNum - 1);

		// 使用limit关键字实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);

		// 存放所有查询出的课程对象
		List<Course> courseList = new ArrayList<Course>();

		try {
			// 获取数据库连接
			conn = getConnection();
			// 获取总记录数
			pst = conn.prepareStatement(countSql.toString());
			int index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord"); // 总记录数

			// 获取查询的学生记录
			pst = conn.prepareStatement(sql.toString());
			index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			Course crs;
			while (rs.next()) {
				crs = new Course();
				crs.setCname(rs.getString("Cname"));
				crs.setCourseId(rs.getString("CourseId"));
				crs.setCredit(rs.getDouble("credit"));
				crs.setTeacherId(rs.getString("TeacherId"));
				crs.setTeacherName(rs.getString("name"));
				crs.setTerm(rs.getString("term"));
				courseList.add(crs);
			}
			// 获取总页数
			int totalPage = totalRecord / pageSize;
			if (totalRecord % pageSize != 0) {
				totalPage++;
			}
			// 组装pager对象
			result = new Pager<Course>(pageSize, pageNum, totalRecord, totalPage, courseList);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				closeOperate(); // 释放资源
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result; // 返回结果
	}

	// 查找某个课程
	public Course findCourseById(String CourseId) {
		try {
			conn = getConnection();
			sql = "SELECT c.CourseId,c.Cname,c.term,c.credit,c.TeacherId,t.`name` FROM t_course as c LEFT JOIN t_teacher as t ON c.TeacherId=t.id WHERE c.CourseId=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, CourseId);
			rs = pst.executeQuery();
			Course crs = null;
			if (rs.next()) {
				crs = new Course();
				crs.setCname(rs.getString("Cname"));
				crs.setCourseId(rs.getString("CourseId"));
				crs.setCredit(rs.getDouble("credit"));
				crs.setTeacherId(rs.getString("TeacherId"));
				crs.setTeacherName(rs.getString("name"));
				crs.setTerm(rs.getString("term"));
			}
			closeOperate();
			return crs;
		} catch (Exception e) {
			return null;
		}
	}

	// 更新某个课程的教师信息
	public boolean updateCourseTeacherInformation(Course crs) {
		try {
			conn = getConnection();
			sql = "UPDATE t_course as c SET c.TeacherId=? WHERE c.CourseId=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, crs.getTeacherId());
			pst.setString(2, crs.getCourseId());

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 失败
			}
		} catch (Exception e) {
			return false;
		}
	}

	// 删除课程
	public boolean deleteCourse(String CourseId) {
		try {
			conn = getConnection();
			sql = "delete from t_course where CourseId=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, CourseId);

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有该课程
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}

	// 添加学期
	public boolean addTerm(String term) {
		try {
			conn = getConnection();
			sql = "INSERT INTO t_term(term) VALUE(?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, term);

			pst.executeUpdate();
			closeOperate();

			return true; // 添加成功
		} catch (Exception e) {
			return false; // 添加失败
		}
	}

	// 查找学期
	/**
	 * 定义分页查询
	 * 
	 * @param searchModel
	 *            传入要查询的条件
	 * @param pageNum
	 *            要查看第几页数据
	 * @param pageSize
	 *            每页显示多少条数据
	 * @return 将搜索到的数据打包返回
	 */
	public Pager<String> findTerm(String searchModel, int pageNum, int pageSize) {
		Pager<String> result = null;
		// 存放查询参数
		List<Object> paramList = new ArrayList<Object>();
		// 定义基础查询语句
		StringBuilder sql = new StringBuilder("SELECT term FROM t_term WHERE 1=1");
		StringBuilder countSql = new StringBuilder("SELECT count(term) as totalRecord FROM t_term WHERE 1=1");
		// 添加查询条件
		if (searchModel != null && !"".equals(searchModel)) {
			sql.append(" and term like ?");
			countSql.append(" and term like ?");
			paramList.add("%" + searchModel + "%");
		}
		// 设置为降序
		sql.append(" ORDER BY term DESC");
		// 起始索引
		int fromIndex = pageSize * (pageNum - 1);

		// 使用limit关键字实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);

		// 存放所有查询出的学期对象
		List<String> termList = new ArrayList<String>();

		try {
			// 获取数据库连接
			conn = getConnection();
			// 获取总记录数
			pst = conn.prepareStatement(countSql.toString());
			int index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord"); // 总记录数

			// 获取查询的学期记录
			pst = conn.prepareStatement(sql.toString());
			index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			while (rs.next()) {

				termList.add(rs.getString("term"));
			}
			// 获取总页数
			int totalPage = totalRecord / pageSize;
			if (totalRecord % pageSize != 0) {
				totalPage++;
			}
			// 组装pager对象
			result = new Pager<String>(pageSize, pageNum, totalRecord, totalPage, termList);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				closeOperate(); // 释放资源
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result; // 返回结果
	}

	// 删除学期
	public boolean deleteTerm(String term) {
		try {
			conn = getConnection();
			sql = "delete from t_term where term=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, term);

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有该学期
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}

	// 添加年级
	public boolean addGrade(int grade) {
		try {
			conn = getConnection();
			sql = "INSERT INTO t_grade(stuGrade) VALUE(?)";
			pst = conn.prepareStatement(sql);
			pst.setInt(1, grade);

			pst.executeUpdate();
			closeOperate();

			return true; // 添加成功
		} catch (Exception e) {
			return false; // 添加失败
		}
	}

	// 查找年级
	/**
	 * 定义分页查询
	 * 
	 * @param searchModel
	 *            传入要查询的条件
	 * @param pageNum
	 *            要查看第几页数据
	 * @param pageSize
	 *            每页显示多少条数据
	 * @return 将搜索到的数据打包返回
	 */
	public Pager<Integer> findGrade(int searchModel, int pageNum, int pageSize) {
		Pager<Integer> result = null;
		// 存放查询参数
		List<Object> paramList = new ArrayList<Object>();
		// 定义基础查询语句
		StringBuilder sql = new StringBuilder("SELECT stuGrade FROM t_grade WHERE 1=1");
		StringBuilder countSql = new StringBuilder("SELECT count(stuGrade) as totalRecord FROM t_grade WHERE 1=1");
		// 添加查询条件
		if (searchModel != -1) {
			sql.append(" and stuGrade=?");
			countSql.append(" and stuGrade=?");
			paramList.add(searchModel);
		}
		// 设置为降序
		sql.append(" ORDER BY stuGrade DESC");
		// 起始索引
		int fromIndex = pageSize * (pageNum - 1);

		// 使用limit关键字实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);

		// 存放所有查询出的年级对象
		List<Integer> gradeList = new ArrayList<Integer>();

		try {
			// 获取数据库连接
			conn = getConnection();
			// 获取总记录数
			pst = conn.prepareStatement(countSql.toString());
			int index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord"); // 总记录数

			// 获取查询的年级记录
			pst = conn.prepareStatement(sql.toString());
			index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			while (rs.next()) {
				gradeList.add(rs.getInt("stuGrade"));
			}
			// 获取总页数
			int totalPage = totalRecord / pageSize;
			if (totalRecord % pageSize != 0) {
				totalPage++;
			}
			// 组装pager对象
			result = new Pager<Integer>(pageSize, pageNum, totalRecord, totalPage, gradeList);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				closeOperate(); // 释放资源
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result; // 返回结果
	}

	// 删除年级
	public boolean deleteGrade(int grade) {
		try {
			conn = getConnection();
			sql = "delete from t_grade where stuGrade=?";
			pst = conn.prepareStatement(sql);

			pst.setInt(1, grade);

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有该年级
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}

	// 添加班级
	public boolean addClass(String addclass) {
		try {
			conn = getConnection();
			sql = "INSERT INTO t_class(stuClass) VALUE(?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, addclass);

			pst.executeUpdate();
			closeOperate();

			return true; // 添加成功
		} catch (Exception e) {
			return false; // 添加失败
		}
	}

	// 查找班级
	/**
	 * 定义分页查询
	 * 
	 * @param searchModel
	 *            传入要查询的条件
	 * @param pageNum
	 *            要查看第几页数据
	 * @param pageSize
	 *            每页显示多少条数据
	 * @return 将搜索到的数据打包返回
	 */
	public Pager<String> findClasses(String searchModel, int pageNum, int pageSize) {
		Pager<String> result = null;
		// 存放查询参数
		List<Object> paramList = new ArrayList<Object>();
		// 定义基础查询语句
		StringBuilder sql = new StringBuilder("SELECT stuClass FROM t_class WHERE 1=1");
		StringBuilder countSql = new StringBuilder("SELECT count(stuClass) as totalRecord FROM t_class WHERE 1=1");
		// 添加查询条件
		if (searchModel != null && !"".equals(searchModel)) {
			sql.append(" and stuClass like ?");
			countSql.append(" and stuClass like ?");
			paramList.add("%" + searchModel + "%");
		}
		// 设置为降序
		sql.append(" ORDER BY stuClass DESC");
		// 起始索引
		int fromIndex = pageSize * (pageNum - 1);

		// 使用limit关键字实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);

		// 存放所有查询出的班级对象
		List<String> classList = new ArrayList<String>();

		try {
			// 获取数据库连接
			conn = getConnection();
			// 获取总记录数
			pst = conn.prepareStatement(countSql.toString());
			int index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord"); // 总记录数

			// 获取查询的年级记录
			pst = conn.prepareStatement(sql.toString());
			index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			while (rs.next()) {
				classList.add(rs.getString("stuClass"));
			}
			// 获取总页数
			int totalPage = totalRecord / pageSize;
			if (totalRecord % pageSize != 0) {
				totalPage++;
			}
			// 组装pager对象
			result = new Pager<String>(pageSize, pageNum, totalRecord, totalPage, classList);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				closeOperate(); // 释放资源
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result; // 返回结果
	}

	// 删除班级
	public boolean deleteClass(String delClass) {
		try {
			conn = getConnection();
			sql = "delete from t_class where stuClass=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, delClass);

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有该年级
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}
}
