package com.lyq.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.lyq.model.Evaluate;
import com.lyq.model.EvaluateAnalysis;

public class EvaluateDao {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private String url = "jdbc:mysql://localhost:3306/db_studentscoremanagesystem";
	private String user = "root";
	private String password = "root";
	//定义操作时要用到的变量
	private String sql = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	/**
	 * 定义内部函数开始
	 */
	//获取连接
	private Connection getConnection() throws SQLException {
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}
	//关闭操作和连接
	private void closeOperate() throws Exception {
		pst.close();
		conn.close();
	}
	/**
	 * 定义结束
	 */
	// 选课时创建评价但是不设置评价内容,将是否评价设置为0（代表未评价）
	public boolean addEvaluate(Evaluate ev){
		try {
			conn = getConnection();
			sql = "insert into t_evaluate(CourseId,term,student_id,teacher_id,evaluated) value(?,?,?,?,?)";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, ev.getCourseId());
			pst.setString(2, ev.getTerm());
			pst.setString(3, ev.getStudent_id());
			pst.setString(4, ev.getTeacher_id());
			pst.setInt(5, 0);
			
			if(pst.executeUpdate()==1){
				closeOperate();
				return true;
			}else{
				closeOperate();
				return false;

			}
		} catch (Exception e) {
			return false;		//添加失败
		}
	}
	
	// 学生进行评价，并将是否评价设置为1（代表已评价）
	public boolean updateEvaluate(Evaluate ev){
		try {
			conn = getConnection();
			sql = "update t_evaluate set lesson=?,homework=?,evaluated=? where student_id=? and CourseId=?";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, ev.getLesson());
			pst.setString(2, ev.getHomework());
			pst.setInt(3, 1);
			pst.setString(4, ev.getStudent_id());
			pst.setString(5, ev.getCourseId());
			
			if(pst.executeUpdate()==1){
				closeOperate();
				return true;
			}else{
				closeOperate();
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * 检查是否已经评价
	 * @param ev 查询的条件
	 * @return	-1代表未选课，0代表未评价，1代表已评价
	 */
	public int ifIsEvaluated(Evaluate ev){
		try {
			conn = getConnection();
			sql = "select evaluated from t_evaluate where student_id=? and CourseId=?";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, ev.getStudent_id());
			pst.setString(2, ev.getCourseId());
			
			rs = pst.executeQuery();
			
			if(rs.next()){
				return rs.getInt(1);
			}else{
				return -1;
			}
		} catch (SQLException e) {
			return -1;
		}
		
	}
	//学生进入评价教师页面
	public Evaluate findEvaluate(Evaluate ev){
		try {
			conn = getConnection();
			sql = "SELECT e.CourseId, c.Cname, e.teacher_id, t.`name` as Teachername, e.evaluated FROM t_evaluate as e, t_teacher as t, t_course as c WHERE e.teacher_id = t.id AND e.CourseId = c.CourseId AND e.student_id=? AND e.CourseId=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, ev.getStudent_id());
			pst.setString(2, ev.getCourseId());
			
			rs = pst.executeQuery();
			if(rs.next()){				//如果查找到了
				Evaluate ret_val = new Evaluate();
				ret_val.setCourseId(rs.getString("CourseId"));
				ret_val.setCname(rs.getString("Cname"));
				ret_val.setTeacher_id(rs.getString("teacher_id"));
				ret_val.setTeachername(rs.getString("Teachername"));
				ret_val.setEvaluated(rs.getInt("evaluated"));
				closeOperate();
				return ret_val;
			}else{
				return null;			//如果查找不到
			}
		} catch (Exception e){
			e.printStackTrace();
			return null;				//程序出错
		}
	}
	//找出某个学生某学期的学生评价教师表
	public List<Evaluate> findEvaluateByStudentAndTerm(Evaluate ev){
		List<Evaluate> result = new ArrayList<Evaluate>();
		try {
			conn = getConnection();
			sql = "SELECT e.CourseId, c.Cname, e.teacher_id, t.`name` as Teachername ,e.evaluated FROM t_evaluate as e, t_teacher as t, t_course as c WHERE e.teacher_id = t.id AND e.CourseId = c.CourseId AND e.student_id=? AND e.term=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, ev.getStudent_id());
			pst.setString(2, ev.getTerm());
			rs = pst.executeQuery();
			Evaluate ret_val = null;
			while(rs.next()){
				ret_val = new Evaluate();
				ret_val.setCourseId(rs.getString("CourseId"));
				ret_val.setCname(rs.getString("Cname"));
				ret_val.setTeacher_id(rs.getString("teacher_id"));
				ret_val.setTeachername(rs.getString("Teachername"));
				ret_val.setEvaluated(rs.getInt("evaluated"));
				result.add(ret_val);
			}
			closeOperate();
			return result;
		} catch (Exception e) {
			return result;
		}
	}
	//统计某个课程的教学评价
	public EvaluateAnalysis getEvaluateAnalysis(String CourseId){
		EvaluateAnalysis ea = new EvaluateAnalysis();
		DecimalFormat df = new DecimalFormat("######0.00");
		try {
			conn = getConnection();
			sql = "SELECT t_course.Cname, t_evaluate.CourseId, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='非常满意' AND t_evaluate.CourseId=?) AS lessonfcmy, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='很满意' AND t_evaluate.CourseId=?) AS lessonhmy, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='满意' AND t_evaluate.CourseId=?) AS lessonmy, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='一般' AND t_evaluate.CourseId=?) AS lessonyb, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='不满意' AND t_evaluate.CourseId=?) AS lessonbmy, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.homework='非常满意' AND t_evaluate.CourseId=?) AS homeworkfcmy, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.homework='很满意' AND t_evaluate.CourseId=?) AS homeworkhmy, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.homework='满意' AND t_evaluate.CourseId=?) AS homeworkmy, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.homework='一般' AND t_evaluate.CourseId=?) AS homeworkyb, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.homework='不满意' AND t_evaluate.CourseId=?) AS homeworkbmy, COUNT(t_evaluate.student_id) AS jionNum, (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.evaluated='1' AND t_evaluate.CourseId=?) AS evaluated, (1-(((SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='不满意' OR t_evaluate.lesson='一般'  AND t_evaluate.CourseId=?) + (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.homework='不满意' OR t_evaluate.homework='一般'  AND t_evaluate.CourseId=?) - ((SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='一般' AND t_evaluate.homework='一般' AND t_evaluate.CourseId=?) + (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='不满意' AND t_evaluate.homework='一般' AND t_evaluate.CourseId=?) + (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='一般' AND t_evaluate.homework='不满意' AND t_evaluate.CourseId=?) + (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.lesson='不满意' AND t_evaluate.homework='不满意' AND t_evaluate.CourseId=?))) / (SELECT COUNT(t_evaluate.student_id) FROM t_evaluate WHERE t_evaluate.evaluated='1' AND t_evaluate.CourseId=?))) * 100 AS satisfactoryRate FROM t_evaluate, t_course WHERE t_evaluate.CourseId = t_course.CourseId AND t_course.CourseId = ? GROUP BY t_course.CourseId";
			pst = conn.prepareStatement(sql);
			for(int i=1; i<=19; i++){
				pst.setString(i, CourseId);
			}
			rs = pst.executeQuery();
			if(rs.next()){
				ea = new EvaluateAnalysis(rs.getString(1),rs.getString(2),
						rs.getInt(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7),
						rs.getInt(8),rs.getInt(9),rs.getInt(10),rs.getInt(11),rs.getInt(12),
						rs.getInt(13),rs.getInt(14),Double.parseDouble(df.format(rs.getDouble(15))));
			}
			return ea;
		} catch (SQLException e) {
			e.printStackTrace();
			return ea;
		}
	}
	
}
