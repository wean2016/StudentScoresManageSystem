package com.lyq.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lyq.model.Student;

public class TermDao {

	public TermDao() {
		// TODO 自动生成的构造函数存根
	}

	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String url = "jdbc:mysql://localhost:3306/db_studentscoremanagesystem";
	private String user = "root";
	private String password = "root";
	// 定义操作时要用到的变量
	private String sql = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	/**
	 * 定义内部函数开始
	 */
	// 获取连接
	private Connection getConnection() throws SQLException {
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}

	// 关闭操作和连接
	private void closeOperate() throws Exception {
		pst.close();
		conn.close();
	}

	/**
	 * 定义结束
	 */
	// 获得默认
	public String getDefaultTerm() {
		try {
			conn = getConnection();
			sql = "select term from t_defaultterm where id=1";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			if (rs.next()) {
				String defaultterm = rs.getString("term");
				closeOperate();
				return defaultterm;// 得到默认学期
			} else {
				closeOperate();
				return null; // 没有设置默认学期，返回null
			}
		} catch (Exception e) {
			return null; // 出错，返回null
		}
	}

	// 获得学期列表
	public List<String> getTerms() {
		try {
			List<String> result = new ArrayList<String>();
			conn = getConnection();
			sql = "select * from t_term";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while (rs.next()) {
				result.add(rs.getString("term"));
			}
			closeOperate();
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// 设置默认学期
	public boolean updateDefaultterm(String defaultterm) {
		try {
			conn = getConnection();
			sql = "update t_defaultterm set term=? where id=1";
			pst = conn.prepareStatement(sql);
			pst.setString(1, defaultterm);
			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有设置默认学期
			}
		} catch (Exception e) {
			return false; // 操作出错
		}

	}

}
