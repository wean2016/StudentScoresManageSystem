package com.lyq.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lyq.dao.innerfunction.InnerFunction;
import com.lyq.model.Pager;
import com.lyq.model.Search;
import com.lyq.model.Student;

public class StudentDao {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private String url = "jdbc:mysql://localhost:3306/db_studentscoremanagesystem";
	private String user = "root";
	private String password = "root";
	//定义操作时要用到的变量
	private String sql = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	/**
	 * 定义内部函数开始
	 */
	//获取连接
	private Connection getConnection() throws SQLException {
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}
	//关闭操作和连接
	private void closeOperate() throws Exception {
		pst.close();
		conn.close();
	}
	/**
	 * 定义结束
	 */
	
	//添加学生
	public boolean addStudent(Student stu){
		try {
			conn = getConnection();
			sql = "insert into t_student(id,name,password,gender,phone,address,e_mail,pic,stuGrade,stuClass) value(?,?,?,?,?,?,?,?,?,?)";
			pst = conn.prepareStatement(sql);
		
			pst.setString(1, stu.getId());
			pst.setString(2, stu.getName());
			pst.setString(3, stu.getPassword());
			pst.setString(4, stu.getGender());
			pst.setString(5, stu.getPhone());
			pst.setString(6, stu.getAddress());
			pst.setString(7, stu.getE_mail());
			pst.setString(8, stu.getPic());
			pst.setInt(9, stu.getStuGrade());
			pst.setString(10, stu.getStuClass());
			
			pst.executeUpdate();
			closeOperate();
			
			return true;	//添加学生成功
		}catch (Exception e) {
			return false;	//添加学生失败
			
		}
		
	}
	//删除学生
	public boolean deleteStudent(String id){
		try {
			conn = getConnection();
			sql = "delete from t_student where id=?";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, id);
			
			if(pst.executeUpdate() == 1){		//判断操作是否有影响到数据
			closeOperate();
			
			return true;						//操作成功
			}else{
				closeOperate();
				return false;					//没有该学生
			}
		}catch (Exception e) {
			return false;						//操作出错
		}
		
	}
	//更新学生基本信息
	public boolean updateStudentBasicInformation(Student stu){
		try {
			conn = getConnection();
			sql = "UPDATE t_student SET t_student.`name`=?, t_student.gender=?, t_student.phone=?, t_student.address=?, t_student.e_mail=?, t_student.stuGrade=?, t_student.stuClass=? WHERE t_student.id=?";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, stu.getName());
			pst.setString(2, stu.getGender());
			pst.setString(3, stu.getPhone());
			pst.setString(4, stu.getAddress());
			pst.setString(5, stu.getE_mail());
			pst.setInt(6, stu.getStuGrade());
			pst.setString(7, stu.getStuClass());
			pst.setString(8, stu.getId());
			
			if(pst.executeUpdate() > 0){		//判断操作是否有影响到数据
				closeOperate();
				
				return true;						//操作成功
				}else{
					closeOperate();
					return false;					//没有该学生
				}
		} catch (Exception e) {
			return false;						//操作出错
		}
		
	}
	//修改学生头像
	public boolean updateStudentPicInformation(Student stu){
		try {
			conn = getConnection();
			sql = "update t_student set pic=? where id=?";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, stu.getPic());
			pst.setString(2, stu.getId());
			
			if(pst.executeUpdate() == 1){		//判断操作是否有影响到数据
				closeOperate();
				
				return true;						//操作成功
				}else{
					closeOperate();
					return false;					//没有该学生
				}
		} catch (Exception e) {
			return false;						//操作出错
		}
	}
	//更新学生密码
	public boolean updateStudentPasswordInformation(Student stu){
		try {
			conn = getConnection();
			sql = "update t_student set password=? where id=?";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, stu.getPassword());
			pst.setString(2, stu.getId());
			
			if(pst.executeUpdate() == 1){		//判断操作是否有影响到数据
				closeOperate();
				
				return true;						//操作成功
				}else{
					closeOperate();
					return false;					//没有该学生
				}
		} catch (Exception e) {
			return false;						//操作出错
		}
	}

	/**
	 * 定义分页查询
	 * @param searchModel 传入要查询的条件
	 * @param pageNum	要查看第几页数据
	 * @param pageSize	每页显示多少条数据
	 * @return	将搜索到的数据打包返回
	 */
	public Pager<Student> findStudent(Student searchModel, int pageNum, int pageSize){
		Pager<Student> result = null;
		//存放查询参数
		List<Object> paramList = new ArrayList<Object>();
		//定义基础查询语句
		StringBuilder sql = new StringBuilder(
				"select * from t_student where 1=1");
		StringBuilder countSql = new StringBuilder(
				"select count(id) as totalRecord from t_student where 1=1");
		//添加查询条件
		int status = searchModel.getIsLocking();
		if(status != -1){
			//-1为不搜索记号
			sql.append(" and isLocking=?");
			countSql.append(" and isLocking=?");
			paramList.add(status);
		}
		
		String id = searchModel.getId();
		if(id != null && !"".equals(id)){
			sql.append(" and id like ?");
			countSql.append(" and id like ?");
			paramList.add("%"+id+"%");
		}
		
		String name = searchModel.getName();
		if(name != null && !"".equals(name)){
			sql.append(" and name like ?");
			countSql.append(" and name like ?");
			paramList.add("%"+name+"%");
		}
		
		String gender = searchModel.getGender();
		if(gender != null && !"".equals(gender) && !"全部".equals(gender)){
			sql.append(" and gender=?");
			countSql.append(" and gender=?");
			paramList.add(gender);
		}
		
		String phone = searchModel.getPhone();
		if(phone != null && !"".equals(phone)){
			sql.append(" and phone=?");
			countSql.append(" and phone=?");
			paramList.add(phone);
		}
		
		String address = searchModel.getAddress();
		if(address != null && !"".equals(address)){
			sql.append(" and address like ?");
			countSql.append(" and address like ?");
			paramList.add("%"+address+"%");
		}
		
		String e_mail = searchModel.getE_mail();
		if(e_mail != null && !"".equals(e_mail)){
			sql.append(" and e_mail=?");
			countSql.append(" and e_mail=?");
			paramList.add(e_mail); 
		}
		
		int stuGrade = searchModel.getStuGrade();
		if(stuGrade != 0){
			sql.append(" and stuGrade=?");
			countSql.append(" and stuGrade=?");
			paramList.add(stuGrade); 
		}
		
		String stuClass = searchModel.getStuClass();
		if(stuClass != null && !"".equals(stuClass)){
			sql.append(" and stuClass=?");
			countSql.append(" and stuClass=?");
			paramList.add(stuClass); 
		}
		
		//起始索引
		int fromIndex = pageSize * ( pageNum - 1 );
		
		//使用limit关键字实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);
		
		//存放所有查询出的学生对象
		List<Student> studentList = new ArrayList<Student>();
		
		
		try {
			//获取数据库连接
			conn = getConnection();
			//获取总记录数
			pst = conn.prepareStatement(countSql.toString());
			int index = 1;
			if(!paramList.isEmpty()){
				for(int i = 0; i < paramList.size(); i++){
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord");	//总记录数
			
			//获取查询的学生记录
			pst = conn.prepareStatement(sql.toString());
			index = 1;
			if(!paramList.isEmpty()){
				for(int i = 0; i < paramList.size(); i++){
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			Student stu;
			while(rs.next()){
				stu = new Student();
				stu.setWrongTimes(rs.getInt("wrongTimes"));
				stu.setIsLocking(rs.getInt("isLocking"));
				stu.setId(rs.getString("id"));
				stu.setPassword(rs.getString("password"));
				stu.setName(rs.getString("name"));
				stu.setGender(rs.getString("gender"));
				stu.setPhone(rs.getString("phone"));
				stu.setAddress(rs.getString("address"));
				stu.setE_mail(rs.getString("e_mail"));
				stu.setPic(rs.getString("pic"));
				stu.setStuGrade(rs.getInt("stuGrade"));
				stu.setStuClass(rs.getString("stuClass"));
				studentList.add(stu);	
			}
			//获取总页数
			int totalPage = totalRecord / pageSize;
			if(totalRecord % pageSize != 0){
				totalPage++;
			}
			//组装pager对象
			result = new Pager<Student>(pageSize, pageNum, totalRecord, totalPage, studentList);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				closeOperate();		//释放资源
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;	//返回结果
	}
	

	
	//精确查询学生账号信息
	public Student findStudentById(String id){
		try {
			conn = getConnection();
			sql = "select * from t_student where id=?";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, id);
			rs = pst.executeQuery();

			if(rs.next()){					//判断是否查询到该学生
				Student stu = new Student();		//如果查找到该学生
				stu.setId(rs.getString("id"));
				stu.setPassword(rs.getString("password"));
				stu.setName(rs.getString("name"));
				stu.setGender(rs.getString("gender"));
				stu.setPhone(rs.getString("phone"));
				stu.setAddress(rs.getString("address"));
				stu.setE_mail(rs.getString("e_mail"));
				stu.setPic(rs.getString("pic"));
				stu.setStuGrade(rs.getInt("stuGrade"));
				stu.setStuClass(rs.getString("stuClass"));
				
				closeOperate();
				return stu;
			}else{
				closeOperate();
				return null;					//查找不到该学生
			}
		} catch (Exception e) {
			return null;						//程序出错
		}
		
	}
	//模糊查询
	public List<Student> findStudentByName(String name) throws Exception {
		conn = getConnection();
		sql = "select * from t_student where name like ?";
		pst = conn.prepareStatement(sql);
		pst.setString(1, "%"+name+"%");
		rs = pst.executeQuery();
		Student stu = null;
		List<Student> list = new ArrayList<Student>();
		while (rs.next()) {
			stu = new Student();
			stu.setId(rs.getString("id"));
			stu.setPassword(rs.getString("password"));
			stu.setName(rs.getString("name"));
			stu.setGender(rs.getString("gender"));
			stu.setPhone(rs.getString("phone"));
			stu.setAddress(rs.getString("address"));
			stu.setE_mail(rs.getString("e_mail"));
			stu.setPic(rs.getString("pic"));
			stu.setStuGrade(rs.getInt("stuGrade"));
			stu.setStuClass(rs.getString("stuClass"));
			list.add(stu);
		}
		closeOperate();

		return list;
	}
	
	//查找全部学生信息
	public List<Student> findAllStudent() throws Exception{
		conn = getConnection();
		sql = "select * from t_student";
		pst = conn.prepareStatement(sql);
		
		rs = pst.executeQuery();

		List<Student> list = new ArrayList<Student>();
		Student stu = null;
		while(rs.next()){
			stu = new Student();
			stu.setId(rs.getString("id"));
			stu.setPassword(rs.getString("password"));
			stu.setName(rs.getString("name"));
			stu.setGender(rs.getString("gender"));
			stu.setPhone(rs.getString("phone"));
			stu.setAddress(rs.getString("address"));
			stu.setE_mail(rs.getString("e_mail"));
			stu.setPic(rs.getString("pic"));
			stu.setStuGrade(rs.getInt("stuGrade"));
			stu.setStuClass(rs.getString("stuClass"));
			
			list.add(stu);
		}
		closeOperate();
		return list;
	}
	//按某项数据按顺序查找所有学生
	public List<Student> findAllStudentByFactorAndSequence(String factor, String sequence) throws Exception{
		List<Student> list = new ArrayList<Student>();
		Student stu = null;
		
		conn = getConnection();
		sql = "select * from t_student order by " + factor + " " + sequence;
		pst = conn.prepareStatement(sql);
		rs = pst.executeQuery();

		
		while(rs.next()){
			stu = new Student();
			stu.setId(rs.getString("id"));
			stu.setPassword(rs.getString("password"));
			stu.setName(rs.getString("name"));
			stu.setGender(rs.getString("gender"));
			stu.setPhone(rs.getString("phone"));
			stu.setAddress(rs.getString("address"));
			stu.setE_mail(rs.getString("e_mail"));
			stu.setPic(rs.getString("pic"));
			stu.setStuGrade(rs.getInt("stuGrade"));
			stu.setStuClass(rs.getString("stuClass"));
			
			list.add(stu);
		}
		closeOperate();
		return list;
	}

	/**
	 * 检查学生账号状态
	 * @param id	传入的学生账号id
	 * @return	返回null代表无此学生，否则将该学生的密码错误次数和锁定状态打包返回
	 * @throws Exception
	 */
	public Student checkStudentStatus(String id) throws Exception{
		Student stu = null;
		conn = getConnection();
		sql = "select wrongTimes,isLocking from t_student where id=?";
		pst = conn.prepareStatement(sql);
		
		pst.setString(1, id);
		
		rs = pst.executeQuery();
		
		
		if(rs.next()){
			stu = new Student();
			stu.setId(id);
			stu.setWrongTimes(rs.getInt("wrongTimes"));
			stu.setIsLocking(rs.getInt("isLocking"));
			closeOperate();
			return stu;
		}else{
			closeOperate();
			return null;
		}
	}
	/**
	 * 更新学生账号密码错误次数和锁定状态
	 * @param id			要操作的学生对象的id			
	 * @param operation		true为密码错误增加一次，false为密码错误次数清零并解除锁定状态
	 * 当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return	true为账号正常或者被修改为正常，false为账号被锁定
	 * @throws Exception 
	 */
	public boolean updateStudentStatus(String id,boolean operation) throws Exception{
		Student stu = checkStudentStatus(id);
		conn = getConnection();
		if(operation){
			int times = stu.getWrongTimes() + 1;
			stu.setWrongTimes(times);
			if(times >= 3){
				sql = "update t_student set wrongTimes=?,isLocking=1 where id=?";
				pst = conn.prepareStatement(sql);
				pst.setInt(1, times);
				pst.setString(2, id);
				pst.executeUpdate();
				closeOperate();
				
				return false;
			}else{
				sql = "update t_student set wrongTimes=? where id=?";
				pst = conn.prepareStatement(sql);
				pst.setInt(1, times);
				pst.setString(2, id);
				pst.executeUpdate();
				closeOperate();
				return true;
			}
		}else{
			sql = "update t_student set wrongTimes=0,isLocking=0 where id=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			pst.executeUpdate();
			closeOperate();
			return true;
		}
	}
}
