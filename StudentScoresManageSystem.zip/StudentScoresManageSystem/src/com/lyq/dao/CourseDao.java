package com.lyq.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.lyq.model.Course;
import com.lyq.model.CourseAnalysisModel;
import com.lyq.model.Pager;
import com.lyq.model.Scores;
import com.lyq.model.Student;

public class CourseDao {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String url = "jdbc:mysql://localhost:3306/db_studentscoremanagesystem";
	private String user = "root";
	private String password = "root";
	// 定义操作时要用到的变量
	private String sql = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	/**
	 * 定义内部函数开始
	 */
	// 获取连接
	private Connection getConnection() throws SQLException {
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}

	// 关闭操作和连接
	private void closeOperate() throws Exception {
		pst.close();
		conn.close();
	}

	/**
	 * 定义结束
	 */
	// 添加课程
	public boolean addCourse(Course crs) {
		try {
			conn = getConnection();
			sql = "INSERT INTO t_course(term, CourseId, Cname, TeacherId, credit) VALUE(?, ?, ?, ?, ?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, crs.getTerm());
			pst.setString(2, crs.getCourseId());
			pst.setString(3, crs.getCname());
			pst.setString(4, crs.getTeacherId());
			pst.setDouble(5, crs.getCredit());

			pst.executeUpdate();
			closeOperate();

			return true; // 添加成功
		} catch (Exception e) {
			return false; // 添加失败
		}
	}

	// 查找课程
	/**
	 * 定义分页查询
	 * 
	 * @param searchModel
	 *            传入要查询的条件
	 * @param pageNum
	 *            要查看第几页数据
	 * @param pageSize
	 *            每页显示多少条数据
	 * @return 将搜索到的数据打包返回
	 */
	public Pager<Course> findCourse(Course searchModel, int pageNum, int pageSize) {
		Pager<Course> result = null;
		// 存放查询参数
		List<Object> paramList = new ArrayList<Object>();
		// 定义基础查询语句
		StringBuilder sql = new StringBuilder(
				"SELECT c.CourseId,c.Cname,c.term,c.credit,c.TeacherId,t.`name` FROM t_course as c LEFT JOIN t_teacher as t ON c.TeacherId=t.id WHERE 1=1");
		StringBuilder countSql = new StringBuilder(
				"SELECT count(c.CourseId) as totalRecord FROM t_course as c LEFT JOIN t_teacher as t ON c.TeacherId=t.id WHERE 1=1");
		// 添加查询条件
		String Cname = searchModel.getCname();
		if (Cname != null && !"".equals(Cname)) {
			sql.append(" and c.Cname like ?");
			countSql.append(" and c.Cname like ?");
			paramList.add("%" + Cname + "%");
		}

		String term = searchModel.getTerm();
		if (term != null && !"".equals(term)) {
			sql.append(" and c.term=?");
			countSql.append(" and c.term=?");
			paramList.add(term);
		}

		String CourseId = searchModel.getCourseId();
		if (CourseId != null && !"".equals(CourseId)) {
			sql.append(" and c.CourseId=?");
			countSql.append(" and c.CourseId=?");
			paramList.add(CourseId);
		}

		String TeacherId = searchModel.getTeacherId();
		if (TeacherId != null && !"".equals(TeacherId)) {
			sql.append(" and c.TeacherId=?");
			countSql.append(" and c.TeacherId=?");
			paramList.add(TeacherId);
		}

		String name = searchModel.getTeacherName();
		if (name != null && !"".equals(name)) {
			sql.append(" and t.`name` like ?");
			countSql.append(" and t.`name` like ?");
			paramList.add("%" + name + "%");
		}

		// 起始索引
		int fromIndex = pageSize * (pageNum - 1);

		// 使用limit关键字实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);

		// 存放所有查询出的课程对象
		List<Course> courseList = new ArrayList<Course>();

		try {
			// 获取数据库连接
			conn = getConnection();
			// 获取总记录数
			pst = conn.prepareStatement(countSql.toString());
			int index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord"); // 总记录数

			// 获取查询的学生记录
			pst = conn.prepareStatement(sql.toString());
			index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			Course crs;
			while (rs.next()) {
				crs = new Course();
				crs.setCname(rs.getString("Cname"));
				crs.setCourseId(rs.getString("CourseId"));
				crs.setCredit(rs.getDouble("credit"));
				crs.setTeacherId(rs.getString("TeacherId"));
				crs.setTeacherName(rs.getString("name"));
				crs.setTerm(rs.getString("term"));
				courseList.add(crs);
			}
			// 获取总页数
			int totalPage = totalRecord / pageSize;
			if (totalRecord % pageSize != 0) {
				totalPage++;
			}
			// 组装pager对象
			result = new Pager<Course>(pageSize, pageNum, totalRecord, totalPage, courseList);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				closeOperate(); // 释放资源
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result; // 返回结果
	}

	// 查找某个课程
	public Course findCourseById(String CourseId) {
		try {
			conn = getConnection();
			sql = "SELECT c.CourseId,c.Cname,c.term,c.credit,c.TeacherId,t.`name` FROM t_course as c LEFT JOIN t_teacher as t ON c.TeacherId=t.id WHERE c.CourseId=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, CourseId);
			rs = pst.executeQuery();
			Course crs = null;
			if (rs.next()) {
				crs = new Course();
				crs.setCname(rs.getString("Cname"));
				crs.setCourseId(rs.getString("CourseId"));
				crs.setCredit(rs.getDouble("credit"));
				crs.setTeacherId(rs.getString("TeacherId"));
				crs.setTeacherName(rs.getString("name"));
				crs.setTerm(rs.getString("term"));
			}
			closeOperate();
			return crs;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

	// 更新某个课程的教师信息
	public boolean updateCourseTeacherInformation(Course crs) {
		try {
			conn = getConnection();
			sql = "UPDATE t_course as c SET c.TeacherId=? WHERE c.CourseId=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, crs.getTeacherId());
			pst.setString(2, crs.getCourseId());

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 失败
			}
		} catch (Exception e) {
			return false;
		}
	}

	// 删除课程
	public boolean deleteCourse(String CourseId) {
		try {
			conn = getConnection();
			sql = "delete from t_course where CourseId=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, CourseId);

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有该课程
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}

	// 获得某个教师的课程
	public List<Course> findCourseByTeacher(String TeacherId, String term) {
		List<Course> result = new ArrayList<Course>();
		try {
			conn = getConnection();
			sql = "SELECT * FROM t_course WHERE TeacherId=? AND term=? ORDER BY term";
			pst = conn.prepareStatement(sql);
			pst.setString(1, TeacherId);
			pst.setString(2, term);
			rs = pst.executeQuery();
			Course crs = null;
			while (rs.next()) {
				crs = new Course();
				crs.setCname(rs.getString("Cname"));
				crs.setCourseId(rs.getString("CourseId"));
				crs.setCredit(rs.getDouble("credit"));
				crs.setTeacherId(rs.getString("TeacherId"));
				crs.setTerm(rs.getString("term"));
				result.add(crs);
			}
			closeOperate();
		} catch (Exception e) {
			return null;
		}
		return result;
	}

	// 科目分数统计
	public Pager<Student> analysisCourseStudent(String courseId, String factor, String sequence, int pageNum,
			int pageSize) {
		Pager<Student> result = null;
		// 存放查询参数
		List<Object> paramList = new ArrayList<Object>();
		// 定义基础查询语句
		StringBuilder sql = new StringBuilder(
				"SELECT t_student.id, t_student.`name`, t_student.gender, t_student.stuGrade, t_student.stuClass, t_scores.score, t_scores.GPA FROM t_student INNER JOIN t_scores ON t_scores.StudentId = t_student.id WHERE t_scores.CourseId = ?");
		StringBuilder countSql = new StringBuilder(
				"SELECT count(t_student.id) as totalRecord FROM t_student INNER JOIN t_scores ON t_scores.StudentId = t_student.id WHERE t_scores.CourseId = ?");
		// 添加查询条件
		paramList.add(courseId);

		if (factor != null && !"".equals(factor) && sequence != null && !"".equals(sequence)) {
			sql.append(" order by " + factor + " " + sequence);
		}
		// 起始索引
		int fromIndex = pageSize * (pageNum - 1);

		// 使用limit关键字实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);

		// 存放所有查询出的课程对象
		List<Student> studentList = new ArrayList<Student>();

		try {
			// 获取数据库连接
			conn = getConnection();
			// 获取总记录数
			pst = conn.prepareStatement(countSql.toString());
			int index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord"); // 总记录数

			// 获取查询的学生记录
			pst = conn.prepareStatement(sql.toString());
			index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			Student stu;
			while (rs.next()) {
				stu = new Student();
				stu.setId(rs.getString("id"));
				stu.setName(rs.getString("name"));
				stu.setGender(rs.getString("gender"));
				stu.setStuGrade(rs.getInt("stuGrade"));
				stu.setStuClass(rs.getString("stuClass"));
				stu.setScore(rs.getDouble("score"));
				stu.setGPA(rs.getDouble("GPA"));

				studentList.add(stu);
			}
			// 获取总页数
			int totalPage = totalRecord / pageSize;
			if (totalRecord % pageSize != 0) {
				totalPage++;
			}
			// 组装pager对象
			result = new Pager<Student>(pageSize, pageNum, totalRecord, totalPage, studentList);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				closeOperate(); // 释放资源
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result; // 返回结果
	}

	// 科目分数分析
	public CourseAnalysisModel CourseAnalysis(String CourseId) {
		CourseAnalysisModel cam = null;
		DecimalFormat df = new DecimalFormat("######0.00");
		try {
			conn = getConnection();
			sql = "SELECT Count(s.StudentId) AS jionNum, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score = 0) AS noneScore, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score > 0 AND s.score < 60) AS `0-60`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score >= 60 AND s.score < 70) AS `60-70`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score >= 70 AND s.score < 80) AS `70-80`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score >= 80 AND s.score < 90) AS `80-90`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score >= 90 AND s.score < 100) AS `90-100`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score = 100) AS `100`, (SELECT AVG(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score > 0) AS ave, (SELECT STD(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score > 0) AS std, ((SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score > 0 AND s.score < 60) / (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score > 0 )) * 100 AS failRate, (SELECT MAX(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score > 0 ) AS max, (SELECT MIN(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.score > 0 ) AS min, COUNT(distinct(s.stuClass)) AS classNum FROM t_scores AS s WHERE s.CourseId=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, CourseId);
			pst.setString(2, CourseId);
			pst.setString(3, CourseId);
			pst.setString(4, CourseId);
			pst.setString(5, CourseId);
			pst.setString(6, CourseId);
			pst.setString(7, CourseId);
			pst.setString(8, CourseId);
			pst.setString(9, CourseId);
			pst.setString(10, CourseId);
			pst.setString(11, CourseId);
			pst.setString(12, CourseId);
			pst.setString(13, CourseId);
			pst.setString(14, CourseId);
			rs = pst.executeQuery();

			if (rs.next()) {
				cam = new CourseAnalysisModel(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8), Double.parseDouble(df.format(rs.getDouble(9))),
						Double.parseDouble(df.format(rs.getDouble(10))),
						Double.parseDouble(df.format(rs.getDouble(11))), rs.getDouble(12), rs.getDouble(13), "所有班级");
			}
			closeOperate();
			return cam;
		} catch (Exception e) {
			return cam;
		}
	}

	// 针对不同班级的科目分数分析
	public CourseAnalysisModel CourseAnalysisByClass(String CourseId, String classname) {
		CourseAnalysisModel cam = null;
		DecimalFormat df = new DecimalFormat("######0.00");
		try {
			conn = getConnection();
			sql = "SELECT Count(s.StudentId) AS jionNum, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score = 0) AS noneScore, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score > 0 AND s.score < 60) AS `0-60`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score >= 60 AND s.score < 70) AS `60-70`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score >= 70 AND s.score < 80) AS `70-80`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score >= 80 AND s.score < 90) AS `80-90`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score >= 90 AND s.score < 100) AS `90-100`, (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score = 100) AS `100`, (SELECT AVG(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score > 0) AS ave, (SELECT STD(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score > 0) AS std, ((SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score > 0 AND s.score < 60) / (SELECT COUNT(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score > 0 )) * 100 AS failRate, (SELECT MAX(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score > 0 ) AS max, (SELECT MIN(s.score) FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=? AND s.score > 0 ) AS min FROM t_scores AS s WHERE s.CourseId=? AND s.stuClass=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, CourseId);
			pst.setString(2, classname);
			pst.setString(3, CourseId);
			pst.setString(4, classname);
			pst.setString(5, CourseId);
			pst.setString(6, classname);
			pst.setString(7, CourseId);
			pst.setString(8, classname);
			pst.setString(9, CourseId);
			pst.setString(10, classname);
			pst.setString(11, CourseId);
			pst.setString(12, classname);
			pst.setString(13, CourseId);
			pst.setString(14, classname);
			pst.setString(15, CourseId);
			pst.setString(16, classname);
			pst.setString(17, CourseId);
			pst.setString(18, classname);
			pst.setString(19, CourseId);
			pst.setString(20, classname);
			pst.setString(21, CourseId);
			pst.setString(22, classname);
			pst.setString(23, CourseId);
			pst.setString(24, classname);
			pst.setString(25, CourseId);
			pst.setString(26, classname);
			pst.setString(27, CourseId);
			pst.setString(28, classname);
			
			rs = pst.executeQuery();

			if (rs.next()) {
				cam = new CourseAnalysisModel(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8), Double.parseDouble(df.format(rs.getDouble(9))),
						Double.parseDouble(df.format(rs.getDouble(10))),
						Double.parseDouble(df.format(rs.getDouble(11))), rs.getDouble(12), rs.getDouble(13), classname);
			}
			closeOperate();
			return cam;
		} catch (Exception e) {
			return cam;
		}
	}
	//获得某个科目的所有班级名称
	public List<String> getClassList(String courseId){
		List<String> result = new ArrayList<String>();
		try {
			conn = getConnection();
			sql = "SELECT DISTINCT t_scores.stuClass FROM t_scores WHERE t_scores.CourseId = ? GROUP BY t_scores.stuClass";
			pst = conn.prepareStatement(sql);
			pst.setString(1, courseId);
			rs = pst.executeQuery();
			String s = null;
			while(rs.next()){
				s = rs.getString("stuClass");
				result.add(s);
			}
			closeOperate();
			return result;
		} catch (Exception e) {
			return result;
		}
		
	}

	public static void main(String[] agrs) {
		System.out.println(new CourseDao().CourseAnalysis("CRS454"));
	}
}
