package com.lyq.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lyq.model.Pager;
import com.lyq.model.Student;
import com.lyq.model.Teacher;

public class TeacherDao {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String url = "jdbc:mysql://localhost:3306/db_studentscoremanagesystem";
	private String user = "root";
	private String password = "root";
	// 定义操作时要用到的变量
	private String sql = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	/**
	 * 定义内部函数开始
	 */
	// 获取连接
	private Connection getConnection() throws SQLException {
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}

	// 关闭操作和连接
	private void closeOperate() throws Exception {
		pst.close();
		conn.close();
	}

	/**
	 * 定义结束
	 */
	// 增加教师
	public boolean addTeacher(Teacher tch) {
		try {
			conn = getConnection();
			sql = "insert into t_teacher(id,password,name,gender,phone,address,e_mail) value(?,?,?,?,?,?,?)";
			pst = conn.prepareStatement(sql);

			pst.setString(1, tch.getId());
			pst.setString(2, tch.getPassword());
			pst.setString(3, tch.getName());
			pst.setString(4, tch.getGender());
			pst.setString(5, tch.getPhone());
			pst.setString(6, tch.getAddress());
			pst.setString(7, tch.getE_mail());

			pst.executeUpdate();
			closeOperate();

			return true; // 添加成功
		} catch (Exception e) {
			return false; // 添加失败
		}
	}

	// 删除教师
	public boolean deleteTeacher(String id) {
		try {
			conn = getConnection();
			sql = "delete from t_teacher where id=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, id);

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有该教师
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}

	// 修改基本教师信息
	public boolean updateTeacherBasicInformation(Teacher tch) {
		try {
			conn = getConnection();
			sql = "update t_teacher set name=?,gender=?,phone=?,address=?,e_mail=? where id=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, tch.getName());
			pst.setString(2, tch.getGender());
			pst.setString(3, tch.getPhone());
			pst.setString(4, tch.getAddress());
			pst.setString(5, tch.getE_mail());
			pst.setString(6, tch.getId());

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有该教师
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}

	// 更新教师密码
	public boolean updateTeacherPasswordInformation(Teacher tch) {
		try {
			conn = getConnection();
			sql = "update t_teacher set password=? where id=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, tch.getPassword());
			pst.setString(2, tch.getId());

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有该教师
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}

	// 精确查询
	public Teacher findTeacherById(String id) {
		try {
			conn = getConnection();
			sql = "select * from t_teacher where id=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, id);
			rs = pst.executeQuery();

			if (rs.next()) { // 判断是否查询到该教师
				Teacher tch = new Teacher(); // 如果查找到该教师
				tch.setId(rs.getString("id"));
				tch.setPassword(rs.getString("password"));
				tch.setName(rs.getString("name"));
				tch.setGender(rs.getString("gender"));
				tch.setPhone(rs.getString("phone"));
				tch.setE_mail(rs.getString("e_mail"));
				tch.setAddress(rs.getString("address"));
				closeOperate();
				return tch;
			} else {
				closeOperate();
				return null; // 查找不到该教师
			}
		} catch (Exception e) {
			return null; // 程序出错
		}

	}

	// 模糊查询
	public List<Teacher> findTeacherByName(String name) throws Exception {
		conn = getConnection();
		sql = "select * from t_teacher where name like '%" + name + "%'";
		pst = conn.prepareStatement(sql);
		rs = pst.executeQuery();
		Teacher tch = null;
		List<Teacher> list = new ArrayList<Teacher>();
		while (rs.next()) {
			tch = new Teacher(); // 如果查找到该教师
			tch.setId(rs.getString("id"));
			tch.setPassword(rs.getString("password"));
			tch.setName(rs.getString("name"));
			tch.setGender(rs.getString("gender"));
			tch.setPhone(rs.getString("phone"));
			tch.setE_mail(rs.getString("e_mail"));
			tch.setAddress(rs.getString("address"));

			list.add(tch);
		}
		closeOperate();

		return list;
	}

	// 查找全部教师信息
	public List<Teacher> findAllTeacher() throws Exception {
		conn = getConnection();
		sql = "select * from t_teacher";
		pst = conn.prepareStatement(sql);

		rs = pst.executeQuery();

		List<Teacher> list = new ArrayList<Teacher>();
		Teacher tch = null;
		while (rs.next()) {
			tch = new Teacher(); // 如果查找到该教师
			tch.setId(rs.getString("id"));
			tch.setPassword(rs.getString("password"));
			tch.setName(rs.getString("name"));
			tch.setGender(rs.getString("gender"));
			tch.setPhone(rs.getString("phone"));
			tch.setE_mail(rs.getString("e_mail"));
			tch.setAddress(rs.getString("address"));

			list.add(tch);
		}
		closeOperate();
		return list;
	}

	/**
	 * 检查教师账号状态
	 * 
	 * @param id
	 *            传入的教师账号id
	 * @return 返回null代表无此教师，否则将该教师的密码错误次数和锁定状态打包返回
	 * @throws Exception
	 */
	public Teacher checkTeacherStatus(String id) {
		
		try {
			Teacher tch = null;
			conn = getConnection();
			sql = "select wrongTimes,isLocking from t_teacher where id=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, id);

			rs = pst.executeQuery();

			if (rs.next()) {
				tch = new Teacher();
				tch.setId(id);
				tch.setWrongTimes(rs.getInt("wrongTimes"));
				tch.setIsLocking(rs.getInt("isLocking"));
				closeOperate();
				return tch;
			} else {
				closeOperate();
				return null;
			}
		} catch (Exception e) {
			return null;
		}
		
	}

	/**
	 * 更新教师账号密码错误次数和锁定状态
	 * 
	 * @param id
	 *            要操作的教师对象的id
	 * @param operation
	 *            true为密码错误增加一次，false为密码错误次数清零并解除锁定状态 当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return true为账号正常或者被修改为正常，false为账号被锁定
	 * @throws Exception
	 */
	public boolean updateTeacherStatus(String id, boolean operation) throws Exception {
		Teacher tch = checkTeacherStatus(id);
		conn = getConnection();
		if (operation) {
			int times = tch.getWrongTimes() + 1;
			tch.setWrongTimes(times);
			if (times >= 3) {
				sql = "update t_teacher set wrongTimes=?,isLocking=1 where id=?";
				pst = conn.prepareStatement(sql);
				pst.setInt(1, times);
				pst.setString(2, id);
				pst.executeUpdate();
				closeOperate();

				return false;
			} else {
				sql = "update t_teacher set wrongTimes=? where id=?";
				pst = conn.prepareStatement(sql);
				pst.setInt(1, times);
				pst.setString(2, id);
				pst.executeUpdate();
				closeOperate();
				return true;
			}
		} else {
			sql = "update t_teacher set wrongTimes=0,isLocking=0 where id=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			pst.executeUpdate();
			closeOperate();
			return true;
		}
	}
	/**
	 * 定义分页查询
	 * @param searchModel 传入要查询的条件
	 * @param pageNum	要查看第几页数据
	 * @param pageSize	每页显示多少条数据
	 * @return	将搜索到的数据打包返回
	 */
	public Pager<Teacher> findTeacher(Teacher searchModel, int pageNum, int pageSize){
		Pager<Teacher> result = null;
		//存放查询参数
		List<Object> paramList = new ArrayList<Object>();
		//定义基础查询语句
		StringBuilder sql = new StringBuilder(
				"select * from t_teacher where 1=1");
		StringBuilder countSql = new StringBuilder(
				"select count(id) as totalRecord from t_teacher where 1=1");
		//添加查询条件
		int status = searchModel.getIsLocking();
		if(status != -1){
			//-1为不搜索记号
			sql.append(" and isLocking=?");
			countSql.append(" and isLocking=?");
			paramList.add(status);
		}
		
		String id = searchModel.getId();
		if(id != null && !"".equals(id)){
			sql.append(" and id like ?");
			countSql.append(" and id like ?");
			paramList.add("%"+id+"%");
		}
		
		String name = searchModel.getName();
		if(name != null && !"".equals(name)){
			sql.append(" and name like ?");
			countSql.append(" and name like ?");
			paramList.add("%"+name+"%");
		}
		
		String gender = searchModel.getGender();
		if(gender != null && !"".equals(gender) && !"全部".equals(gender)){
			sql.append(" and gender=?");
			countSql.append(" and gender=?");
			paramList.add(gender);
		}
		
		String phone = searchModel.getPhone();
		if(phone != null && !"".equals(phone)){
			sql.append(" and phone=?");
			countSql.append(" and phone=?");
			paramList.add(phone);
		}
		
		String address = searchModel.getAddress();
		if(address != null && !"".equals(address)){
			sql.append(" and address like ?");
			countSql.append(" and address like ?");
			paramList.add("%"+address+"%");
		}
		
		String e_mail = searchModel.getE_mail();
		if(e_mail != null && !"".equals(e_mail)){
			sql.append(" and e_mail=?");
			countSql.append(" and e_mail=?");
			paramList.add(e_mail); 
		}
		
		//起始索引
		int fromIndex = pageSize * ( pageNum - 1 );
		
		//使用limit关键字实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);
		
		//存放所有查询出的教师对象
		List<Teacher> teacherList = new ArrayList<Teacher>();
		
		
		try {
			//获取数据库连接
			conn = getConnection();
			//获取总记录数
			pst = conn.prepareStatement(countSql.toString());
			int index = 1;
			if(!paramList.isEmpty()){
				for(int i = 0; i < paramList.size(); i++){
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord");	//总记录数
			
			//获取查询的教师记录
			pst = conn.prepareStatement(sql.toString());
			index = 1;
			if(!paramList.isEmpty()){
				for(int i = 0; i < paramList.size(); i++){
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			Teacher tch;
			FindTeacherCourse fdc = new FindTeacherCourse();
			while(rs.next()){
				tch = new Teacher();
				tch.setIsLocking(rs.getInt("isLocking"));
				tch.setId(rs.getString("id"));
				tch.setPassword(rs.getString("password"));
				tch.setName(rs.getString("name"));
				tch.setGender(rs.getString("gender"));
				tch.setPhone(rs.getString("phone"));
				tch.setAddress(rs.getString("address"));
				tch.setE_mail(rs.getString("e_mail"));
				tch.setCourse(fdc.findTeacherCourse(tch.getId()));
				
				teacherList.add(tch);	
			}
			//获取总页数
			int totalPage = totalRecord / pageSize;
			if(totalRecord % pageSize != 0){
				totalPage++;
			}
			//组装pager对象
			result = new Pager<Teacher>(pageSize, pageNum, totalRecord, totalPage, teacherList);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				closeOperate();		//释放资源
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;	//返回结果
	}

	//获取所教科目
	private class FindTeacherCourse{
		public List<String> findTeacherCourse(String TeacherId){
			List<String> result = new ArrayList<String>();
			try {
				Connection conn1 = getConnection();
				String sql1 = "SELECT t_course.Cname, t_course.CourseId FROM t_course WHERE t_course.TeacherId=?;";
				PreparedStatement pst1 = conn1.prepareStatement(sql1);
				pst1.setString(1, TeacherId);
				ResultSet rs1 = pst1.executeQuery();
				
				String course = null;
				while(rs1.next()){
					course = rs1.getString("Cname") +"("+ rs1.getString("CourseId")+")";
					result.add(course);
				}
				pst1.close();
				rs1.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}
	}
}
