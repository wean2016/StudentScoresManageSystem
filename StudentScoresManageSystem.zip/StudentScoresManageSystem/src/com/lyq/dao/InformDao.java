package com.lyq.dao;

import java.sql.Connection;
import java.util.Date;
import java.util.Iterator;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.lyq.model.Inform;
import com.lyq.model.InformSearchModel;
import com.lyq.model.Pager;

public class InformDao {
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String url = "jdbc:mysql://localhost:3306/db_studentscoremanagesystem";
	private String user = "root";
	private String password = "root";
	// 定义操作时要用到的变量
	private String sql = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	/**
	 * 定义内部函数开始
	 */
	// 获取连接
	private Connection getConnection() throws SQLException {
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}

	// 关闭操作和连接
	private void closeOperate() throws Exception {
		pst.close();
		conn.close();
	}

	/**
	 * 定义结束
	 */

	// 添加通知
	public boolean addInform(Inform im) {
		try {
			conn = getConnection();
			sql = "insert into t_inform(publisher,publishTime,updateTime,title,content,attachmentName,attachmentUrl) value(?,?,?,?,?,?,?)";
			pst = conn.prepareStatement(sql);

			pst.setString(1, im.getPublisher());
			pst.setObject(2, im.getPublishTime());
			pst.setObject(3, im.getUpdateTime());
			pst.setString(4, im.getTitle());
			pst.setString(5, im.getContent());
			pst.setString(6, im.getAttachmentName());
			pst.setString(7, im.getAttachmentUrl());

			if (pst.executeUpdate() == 1) {
				closeOperate();
				return true; // 添加成功
			} else {
				closeOperate();
				return false; // 添加失败
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false; // 程序出错
		}
	}

	/**
	 * 查找符合条件的通知（分页）
	 * 
	 * @param searchModel
	 *            条件
	 * @param pageNum
	 *            第几页
	 * @param pageSize
	 *            每页几条数据
	 * @return 结果
	 */
	public Pager<Inform> findInform(InformSearchModel searchModel, int pageNum, int pageSize) {
		Pager<Inform> result = null;
		// 存放查询参数
		List<Object> paramList = new ArrayList<Object>();
		// 定义基础查询语句
		StringBuilder sql = new StringBuilder("select * from t_inform where 1=1");
		StringBuilder countsql = new StringBuilder("select count(id) as totalReCord from t_inform where 1=1");
		// 添加查询条件
		Date start = searchModel.getStart();
		if (start != null) {
			sql.append(" and publishTime >= ?");
			countsql.append(" and publishTime >= ?");
			paramList.add(start);
		}
		Date end = searchModel.getEnd();
		if (end != null) {
			sql.append(" and publishTime <= ?");
			countsql.append(" and publishTime <= ?");
			paramList.add(end);
		}
		List<String> keywords = searchModel.getKeywords();
		boolean firstKeyword = true; // 标记第一个keyword专门设置sql语句段
		if (keywords != null) {
			Iterator<String> it = keywords.iterator();
			String param = null;
			while (it.hasNext()) {
				param = (String) it.next();
				if (firstKeyword) {
					sql.append(" and title like ?");
					countsql.append(" and title like ?");
					paramList.add("%" + param + "%");
					sql.append(" or content like ?");
					countsql.append(" or content like ?");
					paramList.add("%" + param + "%");
					firstKeyword = false;
				} else {
					sql.append(" or title like ?");
					countsql.append(" or title like ?");
					paramList.add("%" + param + "%");
					sql.append(" or content like ?");
					countsql.append(" or content like ?");
					paramList.add("%" + param + "%");
				}

			}
		}
		String sequence = searchModel.getSequence();
		if ("DESC".equals(sequence)) {
			sql.append(" order by id desc");
			countsql.append(" order by id desc");
		} else if ("ASC".equals(sequence)) {
			sql.append(" order by id asc");
			countsql.append(" order by id asc");
		}
		// 起始索引
		int fromIndex = pageSize * (pageNum - 1);
		// 使用limit关键字来实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);
		// 存放所有查询出的通知对象
		List<Inform> informList = new ArrayList<Inform>();
		try {
			// 获取数据库连接
			conn = getConnection();
			// 获取总记录数
			pst = conn.prepareStatement(countsql.toString());
			int index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord");// 总记录数
			// 获取查询的学生记录
			pst = conn.prepareStatement(sql.toString());
			index = 1;
			if (!paramList.isEmpty()) {
				for (int i = 0; i < paramList.size(); i++) {
					pst.setObject(index++, paramList.get(i));
				}
			}
			rs = pst.executeQuery();
			Inform im = null;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			while (rs.next()) {
				im = new Inform();
				im.setId(rs.getInt("id"));
				im.setPublisher(rs.getString("publisher"));
				im.setPublishTime(sdf.parse(sdf.format(rs.getObject("publishTime"))));
				im.setUpdateTime(sdf.parse(sdf.format(rs.getObject("updateTime"))));
				im.setTitle(rs.getString("title"));
				im.setContent(rs.getString("content"));
				im.setAttachmentName(rs.getString("attachmentName"));
				im.setAttachmentUrl(rs.getString("attachmentUrl"));
				informList.add(im);
			}
			// 获取总页数
			int totalPage = totalRecord / pageSize;
			if (totalRecord % pageSize != 0) {
				totalRecord++;
			}
			// 组装Pager对象
			result = new Pager<Inform>(pageSize, pageNum, totalRecord, totalPage, informList);

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			closeOperate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	// 精确查找通知
	public Inform findInformById(int id) {
		try {
			conn = getConnection();
			sql = "select * from t_inform where id=?";
			pst = conn.prepareStatement(sql);

			pst.setInt(1, id);

			Inform im = null;
			rs = pst.executeQuery();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if (rs.next()) {
				im = new Inform();
				im.setId(rs.getInt("id"));
				im.setPublisher(rs.getString("publisher"));
				im.setPublishTime(sdf.parse(sdf.format(rs.getObject("publishTime"))));
				im.setUpdateTime(sdf.parse(sdf.format(rs.getObject("updateTime"))));
				im.setTitle(rs.getString("title"));
				im.setContent(rs.getString("content"));
				im.setAttachmentName(rs.getString("attachmentName"));
				im.setAttachmentUrl(rs.getString("attachmentUrl"));
			}

			closeOperate();
			return im;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// 删除通知
	public boolean deleteInform(int id) {
		try {
			conn = getConnection();
			sql = "delete from t_inform where id=?";
			pst = conn.prepareStatement(sql);

			pst.setInt(1, id);
			if (pst.executeUpdate() == 1) {
				closeOperate();
				return true; // 删除成功
			} else {
				closeOperate();
				return false; // 删除失败
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false; // 程序出错
		}
	}

	// 修改通知
	public boolean updateInform(Inform im) {
		try {
			conn = getConnection();
			sql = "update t_inform set title=?,content=?,attachmentName=?,attachmentUrl=? where id=?";
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, im.getTitle());
			pst.setString(2, im.getContent());
			pst.setString(3, im.getAttachmentName());
			pst.setString(4, im.getAttachmentUrl());
			pst.setInt(5, im.getId());
			

			if (pst.executeUpdate() == 1) {
				closeOperate();
				return true; // 修改成功
			} else {
				closeOperate();
				return false; // 修改失败
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false; // 系统出错
		}
	}
}

//
// }
// //更改通知
// public boolean updateInform(Inform im){
// try {
// conn = getConnection();
// sql = "update t_inform set author=?,day=?,content=? where id=?";
// pst = conn.prepareStatement(sql);
//
// pst.setString(1, im.getAuthor());
// pst.setString(2, im.getDay());
// pst.setString(3, im.getContent());
//
// if (pst.executeUpdate() == 1) {
// closeOperate();
// return true; // 修改成功
// } else {
// closeOperate();
// return false; // 修改失败
// }
//
// } catch (Exception e) {
// e.printStackTrace();
// return false; //系统出错
// }
// }

// //按顺序查找所有通知
// public List<Inform> findAllInformByDaySequence(String sequence) throws
// Exception{
// List<Inform> list = new ArrayList<Inform>();
// Inform im = null;
// conn = getConnection();
// sql = "select * from t_inform order by day "+sequence;
// pst = conn.prepareStatement(sql);
//
//
// rs = pst.executeQuery();
//
// while(rs.next()){
// im = new Inform();
// im.setId(rs.getInt("id"));
// im.setAuthor(rs.getString("author"));
// im.setDay(rs.getString("day"));
// im.setContent(rs.getString("content"));
// list.add(im);
// }
// closeOperate();
// return list;
// }
// //查找一段时间内的通知
// public List<Inform> findInformByDays(int start, int end){
// List<Inform> list = new ArrayList<Inform>();
// Inform im = null;
// try {
// conn = getConnection();
// sql = "select * from t_inform where day >=? and day <=?";
// pst = conn.prepareStatement(sql);
//
// pst.setInt(1, start);
// pst.setInt(2, end);
//
// rs = pst.executeQuery();
// while(rs.next()){
// im = new Inform();
// im.setId(rs.getInt("id"));
// im.setAuthor(rs.getString("author"));
// im.setDay(rs.getString("day"));
// im.setContent(rs.getString("content"));
// list.add(im);
// }
// closeOperate();
// return list;
// } catch (Exception e) {
// e.printStackTrace();
// return null;
// }
// }
// //查找包含某个关键字的通知
// public List<Inform> findInformByKeyword(String keyword){
// List<Inform> list = new ArrayList<Inform>();
// Inform im = null;
// try {
// conn = getConnection();
// sql = "select * from t_inform where content like ?";
// pst = conn.prepareStatement(sql);
// pst.setString(1, "%"+keyword+"%");
//
// rs = pst.executeQuery();
// while(rs.next()){
// im = new Inform();
// im.setId(rs.getInt("id"));
// im.setAuthor(rs.getString("author"));
// im.setDay(rs.getString("day"));
// im.setContent(rs.getString("content"));
// list.add(im);
// }
// closeOperate();
// return list;
// } catch (Exception e) {
// e.printStackTrace();
// return null;
// }
// }
