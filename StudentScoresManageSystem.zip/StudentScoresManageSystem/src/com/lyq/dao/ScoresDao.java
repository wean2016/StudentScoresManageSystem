package com.lyq.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.lyq.dao.innerfunction.InnerFunction;
import com.lyq.model.Pager;
import com.lyq.model.Scores;
import com.lyq.model.Student;

//成绩操作相关的Dao
public class ScoresDao {

	public ScoresDao() {
	}

	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String url = "jdbc:mysql://localhost:3306/db_studentscoremanagesystem";
	private String user = "root";
	private String password = "root";
	// 定义操作时要用到的变量
	private String sql = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	/**
	 * 定义内部函数开始
	 */
	// 获取连接
	private Connection getConnection() throws SQLException {
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}

	// 关闭操作和连接
	private void closeOperate() throws Exception {
		pst.close();
		conn.close();
	}

	/**
	 * 定义结束
	 */
	// 选课
	public boolean selectClass(Scores scores) {
		try {
			conn = getConnection();
			sql = "INSERT INTO t_scores(term, stuClass, CourseId, StudentId, score, GPA) VALUE(?, ?, ?, ?, ?, ?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, scores.getTerm());
			pst.setString(2, scores.getStuClass());
			pst.setString(3, scores.getCourseId());
			pst.setString(4, scores.getStudentId());
			pst.setDouble(5, 0);
			pst.setDouble(6, 0);

			pst.executeUpdate();
			closeOperate();

			return true; // 添加成功
		} catch (Exception e) {
			return false; // 添加失败
		}
	}

	// 查找某个课程的学生
	public Pager<Student> findStudentByCourse(String courseid, int pageNum, int pageSize) {
		Pager<Student> result = null;
		// 定义基础查询语句
		StringBuilder sql = new StringBuilder(
				"SELECT sd.`name`, sd.id, sd.stuClass, sc.score, sc.GPA FROM t_student as sd, t_scores as sc WHERE sd.id=sc.StudentId AND sc.CourseId=? ORDER BY sc.stuClass");
		StringBuilder countSql = new StringBuilder(
				"SELECT count(sd.id) as totalRecord FROM t_student as sd, t_scores as sc WHERE sd.id=sc.StudentId AND sc.CourseId=? ORDER BY sc.stuClass");

		// 起始索引
		int fromIndex = pageSize * (pageNum - 1);

		// 使用limit关键字实现分页
		sql.append(" limit " + fromIndex + ", " + pageSize);

		// 存放所有查询出的学生对象
		List<Student> studentList = new ArrayList<Student>();

		try {
			// 获取数据库连接
			conn = getConnection();
			// 获取总记录数
			pst = conn.prepareStatement(countSql.toString());
			pst.setString(1, courseid);
			rs = pst.executeQuery();
			rs.next();
			int totalRecord = rs.getInt("totalRecord"); // 总记录数

			// 获取查询的学生记录
			pst = conn.prepareStatement(sql.toString());
			pst.setString(1, courseid);
			rs = pst.executeQuery();
			Student stu;
			while (rs.next()) {
				stu = new Student();
				stu.setId(rs.getString("id"));
				stu.setName(rs.getString("name"));
				stu.setStuClass(rs.getString("stuClass"));
				stu.setGPA(rs.getDouble("GPA"));
				stu.setScore(rs.getDouble("score"));
				studentList.add(stu);
			}
			// 获取总页数
			int totalPage = totalRecord / pageSize;
			if (totalRecord % pageSize != 0) {
				totalPage++;
			}
			// 组装pager对象
			result = new Pager<Student>(pageSize, pageNum, totalRecord, totalPage, studentList);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				closeOperate(); // 释放资源
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result; // 返回结果
	}

	// 为单个学生录入成绩
	public boolean entryScore(Scores score) {
		try {
			conn = getConnection();
			sql = "update t_scores set score=?,GPA=? where CourseId=? and StudentId=?";
			pst = conn.prepareStatement(sql);
			pst.setDouble(1, score.getScore());
			pst.setDouble(2, InnerFunction.calSingleGPA(score.getScore()));
			pst.setString(3, score.getCourseId());
			pst.setString(4, score.getStudentId());

			if (pst.executeUpdate() == 1) { // 判断操作是否有影响到数据
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有上课记录
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}

	// 修改成绩表上某个学生的班级信息
	public boolean updateClassOnScores(Student stu) {
		try {
			conn = getConnection();
			sql = "UPDATE t_scores SET  t_scores.stuClass=? WHERE t_scores.StudentId=?";
			pst = conn.prepareStatement(sql);

			pst.setString(1, stu.getStuClass());
			pst.setString(2, stu.getId());
			if (pst.executeUpdate() >= 0) {
				closeOperate();

				return true; // 操作成功
			} else {
				closeOperate();
				return false; // 没有上课记录
			}
		} catch (Exception e) {
			return false; // 操作出错
		}
	}

	// 查询某个学生某个学期的成绩
	public List<Scores> findStudentScoresByStudentIdAndTerm(String id, String term) {
		List<Scores> result = new ArrayList<Scores>();
		try {
			conn = getConnection();
			sql = "SELECT t_scores.score, t_scores.GPA, t_scores.stuClass, 	t_scores.CourseId, t_course.Cname, t_course.credit, t_teacher.`name` FROM t_scores INNER JOIN t_course ON t_scores.CourseId = t_course.CourseId INNER JOIN t_teacher ON t_course.TeacherId = t_teacher.id WHERE t_scores.StudentId = ? AND t_scores.term = ? GROUP BY t_scores.CourseId";
			pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, term);
			rs = pst.executeQuery();
			Scores s = null;
			while (rs.next()) {
				s = new Scores();
				s.setCname(rs.getString("Cname"));
				s.setCourseId(rs.getString("CourseId"));
				s.setTeacherName(rs.getString("name"));
				s.setStuClass(rs.getString("stuClass"));
				s.setScore(rs.getDouble("score"));
				s.setGPA(rs.getDouble("GPA"));
				s.setCredit(rs.getDouble("credit"));
				result.add(s);
			}
			closeOperate();
			return result;
		} catch (Exception e) {
			return result;
		}
	}
	// 查询某个学生某个学期的成绩的信息
	public Student findStudentTermScore(String id, String term){
		Student stu = null;
		DecimalFormat df = new DecimalFormat("######0.00");
		try {
			conn = getConnection();
			sql = "SELECT t_scores.StudentId, t_student.`name`, t_student.stuGrade, t_student.stuClass, ( SELECT Sum( t_course.credit * t_scores.GPA ) / Sum(t_course.credit)  FROM t_scores INNER JOIN t_student ON t_scores.StudentId = t_student.id INNER JOIN t_course ON t_scores.CourseId = t_course.CourseId WHERE  t_scores.score > 0 AND t_scores.StudentId = ? AND t_scores.term = ? ) AS TermGPA, Count(t_scores.score) AS PassCourseSum, ( SELECT Count(t_scores.CourseId) FROM t_scores WHERE t_scores.StudentId = ? AND t_scores.term = ? AND t_scores.score > 0 AND t_scores.score < 60 ) AS failSum, ( SELECT Count(t_scores.CourseId) FROM t_scores WHERE t_scores.StudentId = ? AND t_scores.term = ? ) AS courseSum, SUM(t_scores.score)/( SELECT Count(t_scores.CourseId) FROM t_scores WHERE t_scores.StudentId = ? AND t_scores.term = ? ) AS ave  FROM t_scores INNER JOIN t_course ON t_scores.CourseId = t_course.CourseId INNER JOIN t_student ON t_scores.StudentId = t_student.id WHERE t_scores.StudentId = ? AND t_scores.term = ? AND t_scores.GPA > 0";
			pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			pst.setString(2, term);
			pst.setString(3, id);
			pst.setString(4, term);
			pst.setString(5, id);
			pst.setString(6, term);
			pst.setString(5, id);
			pst.setString(6, term);
			pst.setString(7, id);
			pst.setString(8, term);
			pst.setString(9, id);
			pst.setString(10, term);
			rs = pst.executeQuery();
			if(rs.next()){
				stu = new Student();
				stu.setId(rs.getString("StudentId"));
				stu.setName(rs.getString("name"));
				stu.setStuGrade(rs.getInt("stuGrade"));
				stu.setStuClass(rs.getString("stuClass"));
				stu.setGPA(Double.parseDouble(df.format(rs.getDouble("TermGPA"))));
				stu.setPassCourseSum(rs.getDouble("PassCourseSum"));
				stu.setFailSum(rs.getDouble("failSum"));
				stu.setCourseSum(rs.getDouble("courseSum"));
				try{
					stu.setPassRate(Double.parseDouble(df.format(100*stu.getPassCourseSum()/(stu.getPassCourseSum()+stu.getFailSum()))));
				}catch(Exception e){
					stu.setPassRate(0);
				}
				stu.setAve(Double.parseDouble(df.format(rs.getDouble("ave"))));
			}
			return stu;
		} catch (SQLException e) {
			return stu;
		}
	}
	//
}
