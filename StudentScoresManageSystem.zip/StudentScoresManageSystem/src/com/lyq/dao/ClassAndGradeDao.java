package com.lyq.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClassAndGradeDao {

	public ClassAndGradeDao() {
		// TODO 自动生成的构造函数存根
	}

	
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private String url = "jdbc:mysql://localhost:3306/db_studentscoremanagesystem";
	private String user = "root";
	private String password = "root";
	//定义操作时要用到的变量
	private String sql = null;
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	/**
	 * 定义内部函数开始
	 */
	//获取连接
	private Connection getConnection() throws SQLException {
		conn = DriverManager.getConnection(url, user, password);
		return conn;
	}
	//关闭操作和连接
	private void closeOperate() throws Exception {
		pst.close();
		conn.close();
	}
	/**
	 * 定义结束
	 */
	//获取年级
	public List<Integer> getGrades(){
		try {
			List<Integer> result = new ArrayList<Integer>();
			conn = getConnection();
			sql = "select * from t_grade";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while(rs.next()){
				result.add(rs.getInt("stuGrade"));
			}
			closeOperate();
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	//获取班级
	public List<String> getClasses(){
		try {
			List<String> result = new ArrayList<String>();
			conn = getConnection();
			sql = "select * from t_class";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			while(rs.next()){
				result.add(rs.getString("stuClass"));
			}
			closeOperate();
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
