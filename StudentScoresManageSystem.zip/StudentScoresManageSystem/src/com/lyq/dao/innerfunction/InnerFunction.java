package com.lyq.dao.innerfunction;

import java.text.DecimalFormat;

import com.lyq.model.Student;

public class InnerFunction {
	//定义符号常量
//	private static final double JIDIAN_C = 1;
//	private static final double JIDIAN_JAVA = 3;
//	private static final double JIDIAN_MYSQL = 2;
//	private static final double JIDIAN_HTML = 2;
//	private static final double JIDIAN_JAVASCRIPT = 2;
	
	
//	//计算总GPA
//	public static double calculateGPA(Student stu){
//			//设置返回绩点格式为x.xx
//			DecimalFormat df = new DecimalFormat("######0.00");
//			double GPA = (calSingleGPA(stu.getC())*JIDIAN_C + calSingleGPA(stu.getJava())*JIDIAN_JAVA 
//					+ calSingleGPA(stu.getMysql())*JIDIAN_MYSQL+ calSingleGPA(stu.getHtml())*JIDIAN_HTML
//					+ calSingleGPA(stu.getJavascript())*JIDIAN_JAVASCRIPT)/(JIDIAN_C + JIDIAN_JAVA 
//					+ JIDIAN_MYSQL + JIDIAN_HTML + JIDIAN_JAVASCRIPT);
//			GPA = Double.parseDouble(df.format(GPA));
//			return GPA;
//			
//
//		}
	//单科GPA计算方法
	public static double calSingleGPA(double score){
		if(score < 60 ){
			return 0;
		}else{
			DecimalFormat df = new DecimalFormat("######0.00");
			return Double.parseDouble(df.format((score - 50)/10));
		}
	}
}
