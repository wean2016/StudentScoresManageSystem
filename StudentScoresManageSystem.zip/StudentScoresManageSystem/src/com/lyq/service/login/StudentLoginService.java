package com.lyq.service.login;

import java.util.List;

import com.lyq.dao.TermDao;
import com.lyq.dao.ClassAndGradeDao;
import com.lyq.dao.StudentDao;
import com.lyq.model.Student;

/**
 * 学生角色登陆使用的service
 */
public class StudentLoginService {
	/**
	 * 加载dao
	 */
	StudentDao sd = new StudentDao();
	TermDao ed = new TermDao();
	ClassAndGradeDao cagd = new ClassAndGradeDao();

	/**
	 * 登陆前检查输入的学生的账号状态
	 * 
	 * @param id
	 *            要检查的id
	 * @return 若查找不到该学生，返回null；否则将该学生的状态信息打包发回
	 */
	public Student checkStudentStatus(String id) {
		try {
			return sd.checkStudentStatus(id);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 检查账号对应的密码是否正确
	 * 
	 * @param stu
	 *            传入的账号密码
	 * @return 若账号对应的密码正确,打包返回该学生的所有信息，若密码错误，返回null
	 * @throws Exception
	 *             可能会报找不到该id的学生资料异常，但在登陆的第一个步骤checkStudentStatus
	 *             中已经确保了该id有对应的学生
	 */
	public Student login(Student stu) throws Exception {
		Student db_student = sd.findStudentById(stu.getId());
		if (stu.getPassword().equals(db_student.getPassword())) {
			return db_student;

		} else {
			return null;
		}
	}

	/**
	 * 执行完登陆操作后更新学生账号的状态
	 * 
	 * @param id
	 *            要更新状态的学生账号
	 * @param operation
	 *            true为密码错误增加一次，false为密码错误次数清零 当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return 更新完状态后，若账号正常，返回true，若账号异常，返回false
	 * @throws Exception
	 *             可能会报找不到该id的学生资料异常，但在登陆的第一个步骤checkStudentStatus
	 *             中已经确保了该id有对应的学生
	 */
	public boolean updateStudentStatus(String id, boolean operation) throws Exception {
		return sd.updateStudentStatus(id, operation);
	}

	// 获得班级。年级。学期信息
	public List<String> getClasses() {
		return cagd.getClasses();
	}

	public List<Integer> getGrades() {
		return cagd.getGrades();
	}

	public List<String> getTerms() {
		return ed.getTerms();
	}
}
