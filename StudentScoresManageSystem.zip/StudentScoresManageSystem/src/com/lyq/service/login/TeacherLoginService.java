package com.lyq.service.login;

import java.util.ArrayList;
import java.util.List;

import com.lyq.dao.ClassAndGradeDao;
import com.lyq.dao.TermDao;
import com.lyq.dao.TeacherDao;
import com.lyq.model.Teacher;

/**
 * 教师账号登陆使用的service
 */
public class TeacherLoginService {
	/**
	 * 加载dao
	 */
	TeacherDao td = new TeacherDao();
	ClassAndGradeDao cagd = new ClassAndGradeDao();
	TermDao ed = new TermDao();
	/**
	 * 登陆前检查输入的教师的账号状态
	 * @param id	要检查的id
	 * @return	若查找不到该教师，返回null；否则将该教师的状态信息打包发回
	 */
	public Teacher checkTeacherStatus(String id){
		try {
			return td.checkTeacherStatus(id);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 检查账号对应的密码是否正确
	 * @param stu	传入的账号密码
	 * @return	若账号对应的密码正确,打包返回该教师的所有信息，若密码错误，返回null
	 * @throws Exception	可能会报找不到该id的教师资料异常，但在登陆的第一个步骤checkTeacherStatus
	 * 						中已经确保了该id有对应的教师
	 */
	public Teacher login(Teacher tch) throws Exception{
		Teacher db_teacher = td.findTeacherById(tch.getId());
		if(tch.getPassword().equals(db_teacher.getPassword())){
			return db_teacher;
		}else{
			return null;
		}
	}
	
	/**
	 * 执行完登陆操作后更新教师账号的状态
	 * @param id	要更新状态的教师账号
	 * @param operation	true为密码错误增加一次，false为密码错误次数清零
	 * 					当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return	更新完状态后，若账号正常，返回true，若账号异常，返回false
	 * @throws Exception	可能会报找不到该id的教师资料异常，但在登陆的第一个步骤checkStudentStatus
	 * 						中已经确保了该id有对应的教师
	 */
	public boolean updateTeacherStatus(String id,boolean operation) throws Exception{
		return td.updateTeacherStatus(id, operation);
	}
	//获得班级。年级。学期信息
	public List<String> getClasses(){
		return cagd.getClasses();
	}
	public List<Integer> getGrades(){
		return cagd.getGrades();
	}
	public List<String> getTerms(){
		return ed.getTerms();
	}
}
