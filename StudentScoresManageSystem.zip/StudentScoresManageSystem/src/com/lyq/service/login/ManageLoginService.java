package com.lyq.service.login;

import java.util.List;

import com.lyq.dao.ClassAndGradeDao;
import com.lyq.dao.ManageDao;
import com.lyq.dao.TermDao;
import com.lyq.model.Manage;
import com.lyq.model.Teacher;

public class ManageLoginService {
	// 加载Dao层
	ClassAndGradeDao cagd = null;
	TermDao td = null;
	ManageDao mgd = null;

	public ManageLoginService() {
		// 初始化
		cagd = new ClassAndGradeDao();
		td = new TermDao();
		mgd = new ManageDao();
	}

	// 获得班级。年级。考试信息
	public List<String> getClasses() {
		return cagd.getClasses();
	}

	public List<Integer> getGrades() {
		return cagd.getGrades();
	}

	public List<String> getTerms() {
		return td.getTerms();
	}

	/**
	 * 检查管理员账号状态
	 * 
	 * @param id
	 *            传入的管理员账号id
	 * @return 返回null代表无此管理员，否则将该管理员的密码错误次数和锁定状态打包返回
	 * @throws Exception
	 */
	public Manage checkManageStatus(String id) throws Exception {
		return mgd.checkManageStatus(id);
	}

	/**
	 * 更新管理员账号密码错误次数和锁定状态
	 * 
	 * @param id
	 *            要操作的管理员对象的id
	 * @param operation
	 *            true为密码错误增加一次，false为密码错误次数清零并解除锁定状态 当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return true为账号正常或者被修改为正常，false为账号被锁定
	 * @throws Exception
	 */
	public boolean updateManageStatus(String id, boolean operation) throws Exception {
		return mgd.updateManageStatus(id, operation);
	}

	// 精确查询
	public Manage findManageById(String id) {
		return mgd.findManageById(id);
	}
	/**
	 * 检查账号对应的密码是否正确
	 * @param stu	传入的账号密码
	 * @return	若账号对应的密码正确,打包返回该教师的所有信息，若密码错误，返回null
	 * @throws Exception	可能会报找不到该id的教师资料异常，但在登陆的第一个步骤checkTeacherStatus
	 * 						中已经确保了该id有对应的教师
	 */
	public Manage login(Manage mng) throws Exception{
		Manage db_manage = mgd.findManageById(mng.getId());
		if(mng.getPassword().equals(db_manage.getPassword())){
			return db_manage;
		}else{
			return null;
		}
	}
}
