package com.lyq.service.manage;

import java.util.List;

import com.lyq.dao.ClassAndGradeDao;
import com.lyq.dao.EvaluateDao;
import com.lyq.dao.ManageDao;
import com.lyq.dao.ScoresDao;
import com.lyq.dao.StudentDao;
import com.lyq.dao.TeacherDao;
import com.lyq.dao.TermDao;
import com.lyq.model.Course;
import com.lyq.model.Evaluate;
import com.lyq.model.Pager;
import com.lyq.model.Scores;
import com.lyq.model.Student;
import com.lyq.model.Teacher;

public class ManageService {
	private StudentDao sd;
	private ClassAndGradeDao cagd;
	private TeacherDao td;
	private ManageDao md;
	private TermDao trd;
	private ScoresDao srd;
	private EvaluateDao evd;

	public ManageService() {
		sd = new StudentDao();
		cagd = new ClassAndGradeDao();
		td = new TeacherDao();
		md = new ManageDao();
		trd = new TermDao();
		srd = new ScoresDao();
		evd = new EvaluateDao();
	}

	// 添加学生
	public boolean addStudent(Student stu) {
		return sd.addStudent(stu);
	}

	// 获得年级列表
	public List<Integer> getGrades() {
		return cagd.getGrades();
	}

	// 获得班级列表
	public List<String> getClasses() {
		return cagd.getClasses();
	}

	// 按资料查找学生
	public Pager<Student> findStudent(Student searchModel, int pageNum, int pageSize) {
		return sd.findStudent(searchModel, pageNum, pageSize);
	}

	// 删除学生
	public boolean deleteStudent(String id) {
		return sd.deleteStudent(id);
	}

	/**
	 * 登陆前检查输入的学生的账号状态
	 * 
	 * @param id
	 *            要检查的id
	 * @return 若查找不到该学生，返回null；否则将该学生的状态信息打包发回
	 */
	public Student checkStudentStatus(String id) {
		try {
			return sd.checkStudentStatus(id);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 用来解锁账号
	 * 
	 * @param id
	 *            要解锁的学生账号
	 * @param operation
	 *            true为密码错误增加一次，false为密码错误次数清零 当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return 更新完状态后，若账号正常，返回true，若账号异常，返回false
	 * @throws Exception
	 *             可能会报找不到该id的学生资料异常，但在登陆的第一个步骤checkStudentStatus
	 *             中已经确保了该id有对应的学生
	 */
	public boolean updateStudentStatus(String id, boolean operation) throws Exception {
		return sd.updateStudentStatus(id, operation);
	}

	// 添加教师账号
	public boolean addTeacher(Teacher tch) {
		return td.addTeacher(tch);
	}

	// 查找教师
	public Pager<Teacher> findTeacher(Teacher searchModel, int pageNum, int pageSize) {
		return td.findTeacher(searchModel, pageNum, pageSize);
	}

	// 添加课程
	public boolean addCourse(Course crs) {
		return md.addCourse(crs);
	}

	/**
	 * 检查教师账号状态
	 * 
	 * @param id
	 *            传入的教师账号id
	 * @return 返回null代表无此教师，否则将该教师的密码错误次数和锁定状态打包返回
	 * @throws Exception
	 */
	public Teacher checkTeacherStatus(String id) {
		return td.checkTeacherStatus(id);
	}

	/**
	 * 用来解锁教师账号
	 * 
	 * @param id
	 *            要操作的教师对象的id
	 * @param operation
	 *            true为密码错误增加一次，false为密码错误次数清零并解除锁定状态 当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return true为账号正常或者被修改为正常，false为账号被锁定
	 * @throws Exception
	 */
	public boolean updateTeacherStatus(String id, boolean operation) throws Exception {
		return td.updateTeacherStatus(id, operation);
	}

	// 删除教师
	public boolean deleteTeacher(String id) {
		return td.deleteTeacher(id);
	}

	// 查找通知
	public Pager<Course> findCourse(Course searchModel, int pageNum, int pageSize) {
		return md.findCourse(searchModel, pageNum, pageSize);
	}

	// 查找某个课程
	public Course findCourseById(String CourseId) {
		return md.findCourseById(CourseId);
	}

	// 更新某个课程的教师信息
	public boolean updateCourseTeacherInformation(Course crs) {
		return md.updateCourseTeacherInformation(crs);
	}

	// 删除课程
	public boolean deleteCourse(String CourseId) {
		return md.deleteCourse(CourseId);
	}

	// 添加学期
	public boolean addTerm(String term) {
		return md.addTerm(term);
	}

	// 查找学期
	public Pager<String> findTerm(String searchModel, int pageNum, int pageSize) {
		return md.findTerm(searchModel, pageNum, pageSize);
	}

	// 删除学期
	public boolean deleteTerm(String term) {
		return md.deleteTerm(term);
	}

	// 获得学期列表
	public List<String> getTerms() {
		return trd.getTerms();
	}

	// 添加年级
	public boolean addGrade(int grade) {
		return md.addGrade(grade);
	}

	// 查找年级
	public Pager<Integer> findGrade(int searchModel, int pageNum, int pageSize) {
		return md.findGrade(searchModel, pageNum, pageSize);
	}

	// 删除年级
	public boolean deleteGrade(int grade) {
		return md.deleteGrade(grade);
	}

	// 添加班级
	public boolean addClass(String addclass) {
		return md.addClass(addclass);
	}

	// 查找班级
	public Pager<String> findClasses(String searchModel, int pageNum, int pageSize) {
		return md.findClasses(searchModel, pageNum, pageSize);
	}

	// 删除班级
	public boolean deleteClass(String delClass) {
		return md.deleteClass(delClass);
	}

	// 选课
	public boolean selectClass(Scores scores, Evaluate ev) {
		return srd.selectClass(scores) && evd.addEvaluate(ev);
	}

	// 获得默认学期
	public String getDefaultTerm() {
		return trd.getDefaultTerm();
	}

	// 设置默认学期
	public boolean updateDefaultterm(String defaultterm) {
		return trd.updateDefaultterm(defaultterm);
	}
}
