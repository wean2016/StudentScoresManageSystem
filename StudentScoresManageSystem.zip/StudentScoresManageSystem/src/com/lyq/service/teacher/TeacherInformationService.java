package com.lyq.service.teacher;

import com.lyq.dao.TeacherDao;
import com.lyq.model.Teacher;

public class TeacherInformationService {

	TeacherDao td = new TeacherDao();

	// 修改资料
	public boolean updateTeacherInformation(Teacher tch) {
		return td.updateTeacherBasicInformation(tch);
	}

	/**
	 * 检查输入的教师的账号状态
	 * 
	 * @param id
	 *            要检查的id
	 * @return 若查找不到该教师，返回null；否则将该教师的状态信息打包发回
	 */
	public Teacher checkTeacherStatus(String id) {
		try {
			return td.checkTeacherStatus(id);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 更新教师账号的状态
	 * 
	 * @param id
	 *            要更新状态的教师账号
	 * @param operation
	 *            true为密码错误增加一次，false为密码错误次数清零 当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return 更新完状态后，若账号正常，返回true，若账号异常，返回false
	 * @throws Exception
	 */
	public boolean updateTeacherStatus(String id, boolean operation) throws Exception {
		return td.updateTeacherStatus(id, operation);
	}

	// 修改密码
	public boolean updateTeacherPasswordInformation(Teacher tch) {
		return td.updateTeacherPasswordInformation(tch);
	}
}
