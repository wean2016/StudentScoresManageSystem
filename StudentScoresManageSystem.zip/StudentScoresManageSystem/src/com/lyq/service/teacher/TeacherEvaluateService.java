package com.lyq.service.teacher;

import java.awt.Font;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.Legend;
import org.jfree.chart.TextTitle;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.DefaultCategoryDataset;
import org.jfree.data.DefaultPieDataset;

import com.lyq.dao.CourseDao;
import com.lyq.dao.EvaluateDao;
import com.lyq.model.Course;
import com.lyq.model.CourseAnalysisModel;
import com.lyq.model.EvaluateAnalysis;

public class TeacherEvaluateService {

	EvaluateDao ed = null;
	CourseDao cd = null;

	public TeacherEvaluateService() {
		ed = new EvaluateDao();
		cd = new CourseDao();
	}

	// 统计某个课程的教学评价
	public EvaluateAnalysis getEvaluateAnalysis(String CourseId) {
		return ed.getEvaluateAnalysis(CourseId);
	}

	// 查找某个课程
	public Course findCourseById(String CourseId) {
		return cd.findCourseById(CourseId);
	}

	// 创建科目评价分析图表
	public List<String> getEvaluateAnalysisChart(EvaluateAnalysis ea, String path) {
		// 创建图表的数据集合
		DefaultPieDataset datasetforlesson = new DefaultPieDataset();
		DefaultPieDataset datasetforhomework = new DefaultPieDataset();
		
		// 输入数据到数据集合
		datasetforlesson.setValue("非常满意", ea.getLessonfcmy());
		datasetforlesson.setValue("很满意", ea.getLessonhmy());
		datasetforlesson.setValue("满意", ea.getLessonmy());
		datasetforlesson.setValue("一般", ea.getLessonyb());
		datasetforlesson.setValue("不满意", ea.getLessonbmy());
		
		datasetforhomework.setValue("非常满意", ea.getHomeworkfcmy());
		datasetforhomework.setValue("很满意", ea.getHomeworkhmy());
		datasetforhomework.setValue("满意", ea.getHomeworkmy());
		datasetforhomework.setValue("一般", ea.getHomeworkyb());
		datasetforhomework.setValue("不满意", ea.getHomeworkbmy());
		// 创建图表
		JFreeChart chartforlesson = ChartFactory.createPie3DChart("课堂教学评价图", datasetforlesson, true, false, false);
		JFreeChart chartforhomewor = ChartFactory.createPie3DChart("作业批改评价图", datasetforhomework, true, false, false);
		//设置标题字体
		TextTitle textTitle = chartforlesson.getTitle();  
		textTitle.setFont(new Font("黑体",Font.BOLD,25));  
		textTitle = chartforhomewor.getTitle(); 
		textTitle.setFont(new Font("黑体",Font.BOLD,25)); 
		//设置饼图字体
		PiePlot pieplot = (PiePlot) chartforlesson.getPlot();  
		pieplot.setSectionLabelFont(new Font("宋体", 0, 20));  
		pieplot = (PiePlot) chartforhomewor.getPlot();  
		pieplot.setSectionLabelFont(new Font("宋体", 0, 20)); 
		
		
		// 随机生成一个字符串作为文件保存在服务器中的名字
		String tFileName1 = UUID.randomUUID().toString();
		String tFileName2 = UUID.randomUUID().toString();
		String realchartpath1 = path + "\\" + tFileName1 + ".jpg";
		String relativePath1 = "/chart/" + tFileName1 + ".jpg";
		String realchartpath2 = path + "\\" + tFileName2 + ".jpg";
		String relativePath2 = "/chart/" + tFileName2 + ".jpg";
		FileOutputStream fos_jpg = null;
		try {
			fos_jpg = new FileOutputStream(realchartpath1);
			ChartUtilities.writeChartAsJPEG(fos_jpg, 100, chartforlesson, 800, 600, null);
		} catch (IOException e) {
		} finally {
			try {
				fos_jpg.close();
			} catch (Exception e) {
			}
		}
		try {
			fos_jpg = new FileOutputStream(realchartpath2);
			ChartUtilities.writeChartAsJPEG(fos_jpg, 100, chartforhomewor, 800, 600, null);
		} catch (IOException e) {
		} finally {
			try {
				fos_jpg.close();
			} catch (Exception e) {
			}
		}
		List<String> result = new ArrayList<String>();
		result.add(relativePath1);
		result.add(relativePath2);
		return result;
	}
}
