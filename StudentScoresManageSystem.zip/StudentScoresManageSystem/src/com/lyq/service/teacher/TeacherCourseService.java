package com.lyq.service.teacher;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.DefaultCategoryDataset;

import com.lyq.dao.CourseDao;
import com.lyq.model.Course;
import com.lyq.model.CourseAnalysisModel;
import com.lyq.model.Pager;
import com.lyq.model.Student;

public class TeacherCourseService {
	private CourseDao cd;

	public TeacherCourseService() {
		cd = new CourseDao();
	}

	// 查找课程
	public Pager<Course> findCourse(Course searchModel, int pageNum, int pageSize) {
		return cd.findCourse(searchModel, pageNum, pageSize);
	}

	/**
	 * 教师把课程添加为自己的课程
	 * 
	 * @param courseId
	 *            课程id
	 * @return 添加成功返回true, 课程已有教师返回false，添加失败返回false
	 */
	public boolean addCourseForTeacher(String courseId, String teacherId) {
		// 查看课程是否已经有教师
		String courseTeacherId = cd.findCourseById(courseId).getTeacherId();
		if (!"".equals(courseTeacherId) && courseTeacherId != null) {
			return false; // 已经有教师
		}
		// 添加为自己的课程
		Course crs = new Course();
		crs.setCourseId(courseId);
		crs.setTeacherId(teacherId);
		if (cd.updateCourseTeacherInformation(crs)) {
			return true; // 添加成功
		} else {
			return false; // 添加失败
		}
	}

	// 科目分数统计
	public Pager<Student> analysisCourseStudent(String courseId, String factor, String sequence, int pageNum,
			int pageSize) {
		return cd.analysisCourseStudent(courseId, factor, sequence, pageNum, pageSize);
	}

	// 查找某个课程
	public Course findCourseById(String CourseId) {
		return cd.findCourseById(CourseId);
	}

	// 科目分数分析
	public List<CourseAnalysisModel> CourseAnalysis(String CourseId) {
		// 创建结果集
		List<CourseAnalysisModel> result = new ArrayList<CourseAnalysisModel>();
		// 拿到所有班级的结果并加入结果集
		result.add(cd.CourseAnalysis(CourseId));
		// 拿到该课程的所有班级名单
		List<String> classnames = new ArrayList<String>();
		Iterator<String> iter = cd.getClassList(CourseId).iterator();
		// 遍历班级名单拿到每个班的成绩分析
		while (iter.hasNext()) {
			result.add(cd.CourseAnalysisByClass(CourseId, iter.next()));
		}
		// 返回结果
		return result;
	}

	// 创建科目分数分析图表
	public String getCourseAnalysisChartInStudent(Course crs, List<CourseAnalysisModel> casList, String path) {
		// 创建图表的数据集合
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		// 获得要分析的数据的迭代
		Iterator<CourseAnalysisModel> iter = casList.iterator();
		// 输入数据到数据集合
		CourseAnalysisModel cas = null;
		while (iter.hasNext()) {
			cas = iter.next();
			dataset.addValue(cas.getJionNum(), cas.getClassname(), "学生总数");
			dataset.addValue(cas.getNoneScore(), cas.getClassname(), "未评分数");
			dataset.addValue(cas.getF0t60(), cas.getClassname(), "0<score<60");
			dataset.addValue(cas.getF60t70(), cas.getClassname(), "60<=score<70");
			dataset.addValue(cas.getF70to80(), cas.getClassname(), "70<=score<80");
			dataset.addValue(cas.getF80to90(), cas.getClassname(), "80<=score<90");
			dataset.addValue(cas.getF90to100(), cas.getClassname(), "90<=score<100");
			dataset.addValue(cas.getF100(), cas.getClassname(), "score=100");
		}
		// 创建图表
		String charttitle = crs.getTerm() + " " + crs.getCname() + "(" + crs.getCourseId() + ") 分数统计图";
		JFreeChart chart = ChartFactory.createBarChart3D(charttitle, // 图表标题
				"", // 目录轴的显示标签
				"", // 数值轴的显示标签
				dataset, // 数据类
				PlotOrientation.VERTICAL, // 图表方向，水平、垂直
				true, // 是否显示图例（对于简单的柱状图必须满足false）
				false, // 是否生成工具
				false); // 是否生成URL链接
		// 随机生成一个字符串作为文件保存在服务器中的名字
		String tFileName = UUID.randomUUID().toString();
		String realchartpath = path + "\\" + tFileName + ".jpg";
		String relativePath = "/chart/"+tFileName+ ".jpg";
		FileOutputStream fos_jpg = null;
		try {
			fos_jpg = new FileOutputStream(realchartpath);
			ChartUtilities.writeChartAsJPEG(fos_jpg, 100, chart, 800, 600, null);
		} catch (IOException e) {
		} finally {
			try {
				fos_jpg.close();
			} catch (Exception e) {
			}
		}
		return relativePath;
	}
	// 创建科目分数分析图表
		public String getCourseAnalysisChartInScores(Course crs, List<CourseAnalysisModel> casList, String path) {
			// 创建图表的数据集合
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			// 获得要分析的数据的迭代
			Iterator<CourseAnalysisModel> iter = casList.iterator();
			// 输入数据到数据集合
			CourseAnalysisModel cas = null;
			while (iter.hasNext()) {
				cas = iter.next();
				dataset.addValue(cas.getAve(), cas.getClassname(), "平均分");
				dataset.addValue(cas.getStd(), cas.getClassname(), "方差");
				dataset.addValue(cas.getFailRate(), cas.getClassname(), "挂科率");
				dataset.addValue(cas.getMax(), cas.getClassname(), "最高分");
				dataset.addValue(cas.getMin(), cas.getClassname(), "最低分");
			}
			// 创建图表
			String charttitle = crs.getTerm() + " " + crs.getCname() + "(" + crs.getCourseId() + ") 分数统计图";
			JFreeChart chart = ChartFactory.createBarChart3D(charttitle, // 图表标题
					"", // 目录轴的显示标签
					"", // 数值轴的显示标签
					dataset, // 数据类
					PlotOrientation.VERTICAL, // 图表方向，水平、垂直
					true, // 是否显示图例（对于简单的柱状图必须满足false）
					false, // 是否生成工具
					false); // 是否生成URL链接
			// 随机生成一个字符串作为文件保存在服务器中的名字
			String tFileName = UUID.randomUUID().toString();
			String realchartpath = path + "\\" + tFileName + ".jpg";
			String relativePath = "/chart/"+tFileName+ ".jpg";
			FileOutputStream fos_jpg = null;
			try {
				fos_jpg = new FileOutputStream(realchartpath);
				ChartUtilities.writeChartAsJPEG(fos_jpg, 100, chart, 800, 600, null);
			} catch (IOException e) {
			} finally {
				try {
					fos_jpg.close();
				} catch (Exception e) {
				}
			}
			return relativePath;
		}
}
