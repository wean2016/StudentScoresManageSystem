package com.lyq.service.teacher;

import java.util.ArrayList;
import java.util.List;

import com.lyq.dao.ClassAndGradeDao;
import com.lyq.dao.CourseDao;
import com.lyq.dao.ScoresDao;
import com.lyq.dao.TermDao;
import com.lyq.dao.StudentDao;
import com.lyq.model.Course;
import com.lyq.model.Pager;
import com.lyq.model.Scores;
import com.lyq.model.Student;

public class TeacherManageService {
	private StudentDao sd;
	private ClassAndGradeDao cagd;
	private TermDao td;
	private CourseDao cd;
	private ScoresDao srd;

	public TeacherManageService() {
		sd = new StudentDao();
		cagd = new ClassAndGradeDao();
		td = new TermDao();
		cd = new CourseDao();
		srd = new ScoresDao();
	}

	// 按资料查找学生
	public Pager<Student> findStudent(Student searchModel, int pageNum, int pageSize) {
		return sd.findStudent(searchModel, pageNum, pageSize);
	}

	// 获得年级列表
	public List<Integer> getGrades() {
		return cagd.getGrades();
	}

	// 获得班级列表
	public List<String> getClasses() {
		return cagd.getClasses();
	}

	// 添加学生
	public boolean addStudent(Student stu) {
		return sd.addStudent(stu);
	}

	// 获得默认学期
	public String getDefaultTerm() {
		return td.getDefaultTerm();
	}

	// 获得某个教师的课程
	public List<Course> findCourseByTeacher(String TeacherId, String term) {
		return cd.findCourseByTeacher(TeacherId, term);
	}

	// 查找某个课程的学生
	public Pager<Student> findStudentByCourse(String courseid, int pageNum, int pageSize) {
		return srd.findStudentByCourse(courseid, pageNum, pageSize);
	}

	// 查找某个课程
	public Course findCourseById(String CourseId) {
		return cd.findCourseById(CourseId);
	}

	// 为单个学生录入成绩
	public boolean entryScore(Scores score) {
		return srd.entryScore(score);
	}
}
