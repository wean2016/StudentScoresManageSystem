package com.lyq.service.teacher;

import com.lyq.dao.InformDao;
import com.lyq.model.Inform;
import com.lyq.model.InformSearchModel;
import com.lyq.model.Pager;

public class TeacherInformService {
	InformDao ifd = null;
	public TeacherInformService() {
		ifd = new InformDao();
	}
	//发布通知
	public boolean addInform(Inform im){
		return ifd.addInform(im);
	}
	//查找通知
	public Pager<Inform> findInform(InformSearchModel searchModel, int pageNum, int pageSize){
		return ifd.findInform(searchModel, pageNum, pageSize);
	}
	//精确查找某个通知
	public Inform findInformById(int id){
		return ifd.findInformById(id);
	}
	//删除通知
	public boolean deleteInform(int id){
		return ifd.deleteInform(id);
	}
	//修改通知
	public boolean updateInform(Inform im){
		return ifd.updateInform(im);
	}
}
