package com.lyq.service.regist;

import java.util.List;

import com.lyq.dao.ClassAndGradeDao;
import com.lyq.dao.StudentDao;
import com.lyq.model.Student;

public class StudentRegistService {
	StudentDao sd = new StudentDao();
	ClassAndGradeDao cagd = new ClassAndGradeDao();
	public boolean RegistStudent(Student stu){
		return sd.addStudent(stu);
	}
	//检查账号是否存在
	public boolean ifAccountAlreadyExists(String id){
		return (sd.findStudentById(id) == null)?false:true;
	}
	//获得年级列表
	public List<Integer> getGrades(){
		return cagd.getGrades();
	}
	//获得班级列表
	public List<String> getClasses(){
		return cagd.getClasses();
	}
	
}
