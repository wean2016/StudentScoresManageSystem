package com.lyq.service.student;

import java.util.List;

import com.lyq.dao.ClassAndGradeDao;
import com.lyq.dao.EvaluateDao;
import com.lyq.dao.InformDao;
import com.lyq.dao.ScoresDao;
import com.lyq.dao.StudentDao;
import com.lyq.dao.TermDao;
import com.lyq.model.Evaluate;
import com.lyq.model.Inform;
import com.lyq.model.InformSearchModel;
import com.lyq.model.Pager;
import com.lyq.model.Scores;
import com.lyq.model.Student;
import com.lyq.util.CalStudentTermGPA;

/**
 * 定义学生操作实现的service
 */
public class StudentService {

	public StudentService() {
	}

	StudentDao sd = new StudentDao();
	InformDao ifd = new InformDao();
	TermDao td = new TermDao();
	ClassAndGradeDao cagd = new ClassAndGradeDao();
	ScoresDao sc = new ScoresDao();
	EvaluateDao ed = new EvaluateDao();

	// 修改资料
	public boolean updateStudentInformation(Student stu) {
		return sd.updateStudentBasicInformation(stu);
	}

	// 修改成绩表上某个学生的班级信息
	public boolean updateClassOnScores(Student stu) {
		return sc.updateClassOnScores(stu);
	}

	/**
	 * 检查输入的学生的账号状态
	 * 
	 * @param id
	 *            要检查的id
	 * @return 若查找不到该学生，返回null；否则将该学生的状态信息打包发回
	 */
	public Student checkStudentStatus(String id) {
		try {
			return sd.checkStudentStatus(id);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 更新学生账号的状态
	 * 
	 * @param id
	 *            要更新状态的学生账号
	 * @param operation
	 *            true为密码错误增加一次，false为密码错误次数清零 当密码错误次数达到三次，锁定值设置为1，账号被锁定
	 * @return 更新完状态后，若账号正常，返回true，若账号异常，返回false
	 * @throws Exception
	 */
	public boolean updateStudentStatus(String id, boolean operation) throws Exception {
		return sd.updateStudentStatus(id, operation);
	}

	// 修改密码
	public boolean updateStudentPasswordInformation(Student stu) {
		return sd.updateStudentPasswordInformation(stu);
	}

	// 修改学生头像
	public boolean updateStudentPicInformation(Student stu) {
		return sd.updateStudentPicInformation(stu);
	}

	// 查找通知
	public Pager<Inform> findInform(InformSearchModel searchModel, int pageNum, int pageSize) {
		return ifd.findInform(searchModel, pageNum, pageSize);
	}

	// 精确查找某个通知
	public Inform findInformById(int id) {
		return ifd.findInformById(id);
	}

	// 获得班级。年级。学期信息
	public List<String> getClasses() {
		return cagd.getClasses();
	}

	public List<Integer> getGrades() {
		return cagd.getGrades();
	}

	public List<String> getTerms() {
		return td.getTerms();
	}

	// 获得默认学期
	public String getDefaultTerm() {
		return td.getDefaultTerm();
	}

	// 查询某个学生某个学期的成绩
	public List<Scores> findStudentScoresByStudentIdAndTerm(String id, String term) {
		return sc.findStudentScoresByStudentIdAndTerm(id, term);
	}

	// 查询某个学生某个学期的成绩的信息
	public Student findStudentTermScore(String id, String term) {
		return sc.findStudentTermScore(id, term);
	}

	// 找出某个学生某学期的学生评价教师表
	public List<Evaluate> findEvaluateByStudentAndTerm(Evaluate ev) {
		return ed.findEvaluateByStudentAndTerm(ev);
	}

	/**
	 * 检查是否已经评价
	 * 
	 * @param ev
	 *            查询的条件
	 * @return -1代表未选课，0代表未评价，1代表已评价
	 */
	public int ifIsEvaluated(Evaluate ev) {
		return ed.ifIsEvaluated(ev);
	}

	// 学生进入评价教师页面
	public Evaluate findEvaluate(Evaluate ev) {
		return ed.findEvaluate(ev);
	}

	// 学生进行评价，并将是否评价设置为1（代表已评价）
	public boolean updateEvaluate(Evaluate ev) {
		return ed.updateEvaluate(ev);
	}
}
