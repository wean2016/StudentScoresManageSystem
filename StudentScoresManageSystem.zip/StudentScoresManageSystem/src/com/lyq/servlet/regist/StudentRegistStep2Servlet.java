package com.lyq.servlet.regist;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.lyq.model.Student;
import com.lyq.service.regist.StudentRegistService;
import com.lyq.util.FileTypeUtils;
import com.lyq.util.PBEUtils;


@WebServlet("/servlet/regist/StudentRegistStep2Servlet")
public class StudentRegistStep2Servlet extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//定义上传图片的限制类型
		List<String> suffixList = new ArrayList<String>();
		suffixList.add(".png");
		suffixList.add(".gif");
		suffixList.add(".jpg");
		//加载学生注册的service
		StudentRegistService srs = new StudentRegistService();
		//拿到session
		HttpSession session = request.getSession();
		
		//获得注册页面二中表单传过来的数据
		String phone = null;
		String address = null;
		String e_mail = null;
		String pic = null;
		
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(factory);
		//设置单个文件大小限制
		sfu.setFileSizeMax(1024*1014);
		try {
			List<FileItem> fiList = sfu.parseRequest(request);
			for(FileItem fi : fiList){
				//获得表单的文本域名字
				String fieldName = fi.getFieldName();
				//是否是文件类型
				boolean isComm = fi.isFormField();
				//获得原始文件名
				String oriFileName = fi.getName();
				//如果是普通数据
				if(isComm && fieldName != null && !"".equals(fieldName)){
					String content = fi.getString();
					content = new String(content.getBytes("ISO-8859-1"),"UTF-8");
					if(fieldName.equals("phone")){
						if(!content.matches("[0-9]{11}") && !"".equals(content) && !(content == null)){
							request.setAttribute("PhoneFormatWrong", true);
							request.getRequestDispatcher("/registStep2.jsp").forward(request, response);
							return;
						}
						phone = content;
					}else if(fieldName.equals("address")){
						if(!content.matches("^(?=.*?[\u4E00-\u9FA5])[\\dA-Za-z\u4E00-\u9FA5]+") && !"".equals(content) && !(content == null)){
							request.setAttribute("AddressFormatWrong", true);
							request.getRequestDispatcher("/registStep2.jsp").forward(request, response);
							return;
						}
						address = content;
					}else if(fieldName.equals("e_mail")){
						if(!content.matches("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$")
								 && !"".equals(content) && !(content == null)){
							request.setAttribute("E_mailFormatWrong", true);
							request.getRequestDispatcher("/registStep2.jsp").forward(request, response);
							return;
						}
						e_mail = content;
					}else if(fieldName.equals("checkcode")){
						//检查验证码
						String piccode = (String) request.getSession().getAttribute("piccode");//session中的验证码
						if(content == null || "".equals(content.trim())){
							request.setAttribute("CheckcodeIsBlank", true);
							request.getRequestDispatcher("/registStep2.jsp").forward(request, response);
							return;
						}
						content = content.trim().toUpperCase();
						if(!content.equals(piccode)){
							request.setAttribute("CheckcodeFormatWrong", true);
							request.getRequestDispatcher("/registStep2.jsp").forward(request, response);
							return;
						}
					}
				}
				//如果是文件（用户上传的头像）
				if(!isComm && fieldName != null && !"".equals(fieldName)){
					//获得要上传的绝对路径
					String realPath = request.getSession().getServletContext().getRealPath("/pic/");
					if(oriFileName != null && !"".equals(oriFileName)){
						String suffix = oriFileName.substring(oriFileName.lastIndexOf("."));
						//确认是图片
//						boolean flag = false;
//						try {
//							BufferedImage bufreader = ImageIO.read(fi.getInputStream());
//							int width = bufreader.getWidth();
//							int height = bufreader.getHeight();
//							if(width==0 || height==0){
//								flag = false;
//							}else{
//								flag = true;
//							}
//						} catch (Exception e) {
//							flag = false;
//						}
//						if(!flag){
//							response.getWriter().print("图片格式错误，请上传jpg,png,gif格式的图片");
//							response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
//							return;
//						}
						InputStream ips = fi.getInputStream();
						if(!FileTypeUtils.isImage(ips)){
							response.getWriter().print("上传的头像不是图片！");
							response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
							return;
						}
						ips.close();
						ips = fi.getInputStream();
						//确认图片类型
						if(!suffixList.contains(FileTypeUtils.getImageFileType(ips))){
							response.getWriter().print("上传的头像的格式不正确！请上传jpg,png,gif格式的图片！");
							response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
							return;
						}
						ips.close();
						//确认后缀
						if(suffixList.contains(suffix)){
							//随机生成一个字符串再加上id作为文件保存在服务器中的名字
							String tFileName = UUID.randomUUID().toString() + "_" + (String) session.getAttribute("registId");
							String relativePath = "/pic/"+tFileName+suffix;
							pic = relativePath;
							File file = new File(realPath,tFileName+suffix);
							fi.write(file);
						}else{
							response.getWriter().print("图片格式错误，请上传jpg,png,gif格式的图片");
							response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
							return;
						}
					}
				}
			}
			//对密码进行加密
			PBEUtils pbeUtils = new PBEUtils();
			String encryptPassword = pbeUtils.encrypt((String) session.getAttribute("registId"), (String) session.getAttribute("registPassword"));
			
			Student stu = new Student();
			stu.setId((String) session.getAttribute("registId"));
			stu.setPassword(encryptPassword);
			stu.setName((String) session.getAttribute("registName"));
			stu.setGender((String) session.getAttribute("registGender"));
			stu.setStuGrade(Integer.parseInt((String) session.getAttribute("stuGrade")));
			stu.setStuClass((String) session.getAttribute("stuClass"));
			stu.setPhone(phone);
			stu.setAddress(address);
			stu.setE_mail(e_mail);
			stu.setPic(pic);
			session.removeAttribute("registId");
			session.removeAttribute("registPassword");
			session.removeAttribute("registName");
			session.removeAttribute("registGender");
			session.removeAttribute("stuGrade");
			session.removeAttribute("stuClass");
			
			if(srs.RegistStudent(stu)){
				response.getWriter().write("恭喜你注册成功！<br>");
				response.getWriter().write("三秒后自动前往登陆页面<br>");
				response.getWriter().print("<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/login.jsp'\",3000)</script>");
			}else{
				response.getWriter().write("sorry...发生了未知的错误...<br>");
				response.getWriter().write("三秒后自动前往注册页面");
				response.getWriter().print("<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/servlet/regist/LoadClassAndGradeSevlet'\",3000)</script>");
			}
		
		}catch (Exception e) {
			if(e instanceof FileUploadBase.FileSizeLimitExceededException){
				response.getWriter().write("文件过大，请上传1M以内的图片");
				response.getWriter().write("三秒后自动前往注册页面");
				response.getWriter().print("<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/servlet/regist/LoadClassAndGradeSevlet'\",3000)</script>");
			}
		}
	}

}
