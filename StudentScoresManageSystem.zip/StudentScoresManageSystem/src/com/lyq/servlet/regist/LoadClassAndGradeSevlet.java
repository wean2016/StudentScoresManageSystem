package com.lyq.servlet.regist;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.service.regist.StudentRegistService;

/**
 * Servlet implementation class LoadClassAndGradeSevlet
 */
@WebServlet("/servlet/regist/LoadClassAndGradeSevlet")
public class LoadClassAndGradeSevlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentRegistService srs = new StudentRegistService();
		//拿到年级列表和班级列表
		List<String> classes = srs.getClasses();
		List<Integer> grades = srs.getGrades();
		//添加到request中
		request.setAttribute("classes", classes);
		request.setAttribute("grades", grades);
		//转发页面
		request.getRequestDispatcher("/registStep1.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
