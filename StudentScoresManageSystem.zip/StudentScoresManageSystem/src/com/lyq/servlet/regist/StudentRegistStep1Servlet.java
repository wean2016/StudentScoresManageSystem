package com.lyq.servlet.regist;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lyq.service.regist.StudentRegistService;

/**
 * Servlet implementation class StudentRegistStep1Servlet
 */
@WebServlet("/servlet/regist/StudentRegistStep1Servlet")
public class StudentRegistStep1Servlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentRegistService srs = new StudentRegistService();
		/**
		 * 获得学生注册一页面里的数据
		 */
		String registId = request.getParameter("id");
		String registPassword = request.getParameter("password");
		String registName = request.getParameter("name");
		String registGender = request.getParameter("gender");
		String stuGrade = request.getParameter("stuGrade");
		String stuClass = request.getParameter("stuClass");
		
		//验证输入的数据格式是否正确
		if(!registId.matches("[0-9]{10}")){
			request.setAttribute("IdFormatWrong", true);
			request.getRequestDispatcher("/servlet/regist/LoadClassAndGradeSevlet").forward(request, response);
			return;
		}
		if(!registPassword.matches("\\w{6,10}")){
			request.setAttribute("PasswordFormatWrong", true);
			request.getRequestDispatcher("/servlet/regist/LoadClassAndGradeSevlet").forward(request, response);
			return;
		}
		if(!registName.matches("[\u4E00-\u9FA5]{2,5}(?:·[\u4E00-\u9FA5]{2,5})*")){
			request.setAttribute("NameFormatWrong", true);
			request.getRequestDispatcher("/servlet/regist/LoadClassAndGradeSevlet").forward(request, response);
			return;
		}
		if(!registGender.matches("[男]|[女]")){
			request.setAttribute("GenderFormatWrong", true);
			request.getRequestDispatcher("/servlet/regist/LoadClassAndGradeSevlet").forward(request, response);
			return;
		}
		//检查stuGrade和stuClass是否正确
		if(stuGrade == null || "".equals(stuGrade) || !srs.getGrades().contains(Integer.parseInt(stuGrade))){
			response.getWriter().write("选择的年级不存在！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(!srs.getClasses().contains(stuClass)){
			response.getWriter().write("选择的班级不存在！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//检查账号是否已存在
		if(srs.ifAccountAlreadyExists(registId)){
			response.getWriter().write("该账号已存在！三秒钟后将前往登陆页面");
			response.getWriter().print("<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/login.jsp'\",3000)</script>");
			return;
		}
		//获得session对象
		HttpSession session = request.getSession();
		//将用户注册的数据加入到session对象中
		session.setAttribute("registId", registId);
		session.setAttribute("registPassword", registPassword);
		session.setAttribute("registName", registName);
		session.setAttribute("registGender", registGender);
		session.setAttribute("stuGrade", stuGrade);
		session.setAttribute("stuClass", stuClass);
		
		response.sendRedirect(request.getContextPath()+"/registStep2.jsp");
	}

}
