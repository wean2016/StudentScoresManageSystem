package com.lyq.servlet.manage.classes;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Pager;
import com.lyq.service.manage.ManageService;

@WebServlet("/servlet/manage/classes/FindClassesServlet")
public class FindClassesServlet extends HttpServlet {
	ManageService mgs = new ManageService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 接受request里的参数
		String stuClass = request.getParameter("stuClass");
		// 检查参数的正确性
		
		if (stuClass != null && !"".equals(stuClass) && !stuClass.trim().matches("[\u4E00-\u9FA5]+")) {
			response.getWriter().write("年级名称格式错误！！请输入中文");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}

		// 检查pageNum
		String pageNumStr = request.getParameter("pageNum");
		if (pageNumStr != null && !"".equals(pageNumStr.trim()) && !pageNumStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请选择正确的页数！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageNum = 1; // 默认显示第一页数据
		if (pageNumStr != null && !"".equals(pageNumStr.trim())) {
			pageNum = Integer.parseInt(pageNumStr);
		}
		// 检查pageSize
		String pageSizeStr = request.getParameter("pageSize");
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim()) && !pageSizeStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请正确输入每页显示几条数据");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageSize = 10; // 默认显示10条数据
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim())) {
			pageSize = Integer.parseInt(pageSizeStr);
		}
		
		// 调用service获取查询结果
		Pager<String> result = mgs.findClasses(stuClass, pageNum, pageSize);
		// 返回结果到页面
		request.setAttribute("result", result);
		request.setAttribute("stuClass", stuClass);
		request.setAttribute("pageSize", pageSize);
		request.getRequestDispatcher("/manage/classes/searchClasses.jsp").forward(request, response);
	}

}
