package com.lyq.servlet.manage.classes;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.service.manage.ManageService;


@WebServlet("/servlet/manage/classes/DeleteClassesServlet")
public class DeleteClassesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//拿到stuGrade
		String stuClass = request.getParameter("stuClass");
		if(stuClass == null || "".equals(stuClass.trim())){
			response.getWriter().write("请输入要删除的班级！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else if(!stuClass.trim().matches("[\u4E00-\u9FA5]+")){
			response.getWriter().write("输入的班级格式不正确！请检查！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else{
			stuClass = stuClass.trim();
		}
		
		//拿到service
		ManageService mgs = new ManageService();
		
		//执行操作
		if(mgs.deleteClass(stuClass)){
			response.getWriter().write("删除成功！");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			response.getWriter().write("<input type=\"button\" value=\"返回上一页\" onclick=\"javascript:window.history.back(-1);\">");
			//更新session中的数据
			request.getSession().setAttribute("classes", mgs.getClasses());
		}else{
			response.getWriter().write("该班级不存在！");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			response.getWriter().write("<input type=\"button\" value=\"返回上一页\" onclick=\"javascript:window.history.back(-1);\">");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
