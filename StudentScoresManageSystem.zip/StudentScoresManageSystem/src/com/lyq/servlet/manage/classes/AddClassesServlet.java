package com.lyq.servlet.manage.classes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Student;
import com.lyq.service.manage.ManageService;
import com.lyq.service.teacher.TeacherManageService;

@WebServlet("/servlet/manage/classes/AddClassesServlet")
public class AddClassesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到service
		ManageService mgs = new ManageService();
		// 获得参数
		String classes = request.getParameter("classes");
		// 检查参数的正确性
		
		String[] classesArray = null;
		if(classes == null || "".matches(classes.trim())){
			response.getWriter().write("请输入要添加的班级");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else{
			classesArray = classes.split("\n");
			for(int i = 0; i < classesArray.length; i++){
				classesArray[i] = classesArray[i].trim();
				if(!classesArray[i].matches("[\u4E00-\u9FA5]+")){
					response.getWriter().write("第"+(i+1)+"个要添加的班级格式错误<br>"
							+"为:  "+classesArray[i]);
					response.getWriter()
							.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
					return;
				}
			}
		}
		
		//添加年级并返回结果
		int totalRecord = classesArray.length;	//总记录数
		int successNum = 0;	//添加成功个数
		int failureNum = 0;	//添加失败个数
		List<String> successList = new ArrayList<String>();	//添加成功的年级
		List<String> failureList = new ArrayList<String>();	//添加失败的年级
		for (int i = 0; i < classesArray.length; i++) {
			if(mgs.addClass(classesArray[i])){
				//添加成功
				successNum++;
				successList.add(classesArray[i]);
			}else{
				//添加失败
				failureNum++;
				failureList.add(classesArray[i]);
			}
		}
		//更新session中的数据
		request.getSession().setAttribute("classes", mgs.getClasses());
		response.getWriter().write("总共接收到"+totalRecord+"条数据<br>"
				+ "其中添加成功了"+successNum+"条数据，分别为<hr>");
		Iterator<String> successIterator = successList.iterator();
		while(successIterator.hasNext()){
			response.getWriter().write(successIterator.next() + "<br>");
		}
		response.getWriter().write("<hr>添加失败的数据有"+failureNum+"条，分别为<hr>");
		Iterator<String> failureIterator = failureList.iterator();
		while(failureIterator.hasNext()){
			response.getWriter().write(failureIterator.next() + "<br>");
		}
		response.getWriter().write("<hr>");
		response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
		response.getWriter().write("<input type=\"button\" value=\"继续添加\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/grades/addGrades.jsp';\">");
	}

}
