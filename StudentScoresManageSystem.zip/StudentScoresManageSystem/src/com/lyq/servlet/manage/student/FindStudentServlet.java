package com.lyq.servlet.manage.student;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Pager;
import com.lyq.model.Student;
import com.lyq.service.manage.ManageService;
import com.lyq.service.teacher.TeacherManageService;


@WebServlet("/servlet/manage/student/FindStudentServlet")
public class FindStudentServlet extends HttpServlet {
	ManageService mgs = new ManageService();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接受request里的参数
		String status = request.getParameter("status");
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String e_mail = request.getParameter("e_mail");
		String stuGrade = request.getParameter("stuGrade");
		String stuClass = request.getParameter("stuClass");
		
		
		//检查输入数据格式是否正确
		if(status == null || "".equals(status) || !status.matches("[-]?[01]{1}")){//-1为不搜索记号
			response.getWriter().write("选择的账号状态格式不存在！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(id != null && !"".equals(id.trim()) && !id.matches("^[0-9]{1,10}")){	//可以输入1-10位数字进行模糊搜索
			response.getWriter().write("输入的id格式不正确！请输入1-10位数字");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(name != null && !"".equals(name.trim()) && !name.matches("[\u4E00-\u9FA5]{1,5}(?:·[\u4E00-\u9FA5]{2,5})*")){	//可以进行模糊搜索
			response.getWriter().write("输入的姓名格式不正确！请输入一个以上的汉字，可加·号");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(gender != null && !"".equals(gender) && !gender.matches("[男]|[女]|全部")){
			response.getWriter().write("性别格式不正确");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(phone != null && !"".equals(phone.trim()) && !phone.matches("[0-9]{11}")){		//手机号码必须为11位数字
			response.getWriter().write("输入的电话格式不正确！请输入11位数字");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(address != null && !"".equals(address.trim()) && !address.matches("^(?=.*?[\u4E00-\u9FA5])[\\dA-Za-z\u4E00-\u9FA5]+")){		//可以进行模糊搜索
			response.getWriter().write("输入的地址格式不正确！请以中文开头，可输入数字、字母和汉字");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(e_mail != null && !"".equals(e_mail.trim()) &&!e_mail.matches("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$")){
			response.getWriter().write("输入的邮箱格式不正确！请输入正确的邮箱");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//检查stuGrade和stuClass是否正确
		try{
			if(stuGrade != null && !"".equals(stuGrade) && !mgs.getGrades().contains(Integer.parseInt(stuGrade))){
				response.getWriter().write("选择的年级不存在！");
				response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
		}
		}catch(Exception e){
			response.getWriter().write("选择的年级格式错误！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(stuClass != null && !"".equals(stuClass) && !mgs.getClasses().contains(stuClass)){
			response.getWriter().write("选择的班级不存在！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		
		//检查pageNum
		String pageNumStr = request.getParameter("pageNum");
		if(pageNumStr !=null && !"".equals(pageNumStr.trim()) &&!pageNumStr.matches("^[1-9]\\d*$")){
			response.getWriter().write("请选择正确的页数！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageNum = 1; //默认显示第一页数据
		if(pageNumStr!=null && !"".equals(pageNumStr.trim())){
			pageNum = Integer.parseInt(pageNumStr);
		}
		//检查pageSize
		String pageSizeStr = request.getParameter("pageSize");
		if(pageSizeStr!=null && !"".equals(pageSizeStr.trim()) &&!pageSizeStr.matches("^[1-9]\\d*$")){
			response.getWriter().write("请正确输入每页显示几条数据");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageSize = 10;  // 默认显示10条数据
		if(pageSizeStr!=null && !"".equals(pageSizeStr.trim())){
			pageSize = Integer.parseInt(pageSizeStr);
		}
		// 组装查询条件
		Student searchModel = new Student(); 
		searchModel.setIsLocking(Integer.parseInt(status));
		searchModel.setId(id.trim());
		searchModel.setName(name.trim());
		searchModel.setGender(gender.trim());
		searchModel.setPhone(phone.trim());
		searchModel.setAddress(address.trim());
		searchModel.setE_mail(e_mail.trim());
		try{
			searchModel.setStuGrade(Integer.parseInt(stuGrade));
		}catch(Exception E){
			
		}
		searchModel.setStuClass(stuClass);
		
		//调用service获取查询结果
		Pager<Student> result = mgs.findStudent(searchModel, pageNum, pageSize);
		
		// 返回结果到页面
		request.setAttribute("result", result);
		request.setAttribute("status", status);
		request.setAttribute("id", id);
		request.setAttribute("name", name);
		request.setAttribute("gender", gender);
		request.setAttribute("phone", phone);
		request.setAttribute("address", address);
		request.setAttribute("e_mail", e_mail);
		request.setAttribute("pageSize", pageSize);
		request.setAttribute("stuGrade", stuGrade);
		request.setAttribute("stuClass", stuClass);
		request.getRequestDispatcher("/manage/student/searchStudent.jsp").forward(request, response);
	}

}
