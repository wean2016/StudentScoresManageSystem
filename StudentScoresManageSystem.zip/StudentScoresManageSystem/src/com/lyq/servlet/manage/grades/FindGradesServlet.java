package com.lyq.servlet.manage.grades;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Pager;
import com.lyq.service.manage.ManageService;

@WebServlet("/servlet/manage/grades/FindGradesServlet")
public class FindGradesServlet extends HttpServlet {
	ManageService mgs = new ManageService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 接受request里的参数
		String stuGradeStr = request.getParameter("stuGrade");
		int stuGrade = -1;	//-1代表不添加搜索参数，默认选择-1
		// 检查参数的正确性
		
		if (stuGradeStr != null && !"".equals(stuGradeStr) && !stuGradeStr.trim().matches("\\d{4}")) {
			response.getWriter().write("年级名称格式错误！！请输入4位数字");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if (stuGradeStr != null && !"".equals(stuGradeStr)) {
			stuGrade = Integer.parseInt(stuGradeStr);
		}

		// 检查pageNum
		String pageNumStr = request.getParameter("pageNum");
		if (pageNumStr != null && !"".equals(pageNumStr.trim()) && !pageNumStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请选择正确的页数！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageNum = 1; // 默认显示第一页数据
		if (pageNumStr != null && !"".equals(pageNumStr.trim())) {
			pageNum = Integer.parseInt(pageNumStr);
		}
		// 检查pageSize
		String pageSizeStr = request.getParameter("pageSize");
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim()) && !pageSizeStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请正确输入每页显示几条数据");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageSize = 10; // 默认显示10条数据
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim())) {
			pageSize = Integer.parseInt(pageSizeStr);
		}
		
		// 调用service获取查询结果
		Pager<Integer> result = mgs.findGrade(stuGrade, pageNum, pageSize);
		// 返回结果到页面
		request.setAttribute("result", result);
		request.setAttribute("stuGrade", stuGradeStr);
		request.setAttribute("pageSize", pageSize);
		request.getRequestDispatcher("/manage/grades/searchGrades.jsp").forward(request, response);
	}

}
