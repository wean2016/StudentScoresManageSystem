package com.lyq.servlet.manage.teacher;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Student;
import com.lyq.model.Teacher;
import com.lyq.service.manage.ManageService;

@WebServlet("/servlet/manage/teacher/UnlockTeacherServlet")
public class UnlockTeacherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到id
		String id = request.getParameter("id");
		if (id == null || "".equals(id.trim())) {
			response.getWriter().write("请输入要删除的教师的id！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		} else if (!id.trim().matches("^tch\\d{6}")) {
			response.getWriter().write("输入的教师id格式不正确！请检查！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		} else {
			id = id.trim();
		}
		// 拿到service
		ManageService mgs = new ManageService();
		// 检查账号状态
		Teacher status = mgs.checkTeacherStatus(id);
		if (status == null) {
			response.getWriter().write("要解锁的教师账号不存在！请检查！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if (status.getIsLocking() == 0) {
			response.getWriter().write("该账号并没有被锁定！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 执行解锁
		try {
			if (mgs.updateTeacherStatus(id, false)) {
				response.getWriter().write("解锁成功！！！");
				response.getWriter()
						.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				response.getWriter().write(
						"<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
				return;
			}else{
				response.getWriter().write("解锁失败！！");
				response.getWriter()
						.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
