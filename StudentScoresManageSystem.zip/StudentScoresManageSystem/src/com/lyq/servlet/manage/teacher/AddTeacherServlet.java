package com.lyq.servlet.manage.teacher;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Student;
import com.lyq.model.Teacher;
import com.lyq.service.manage.ManageService;
import com.lyq.service.teacher.TeacherManageService;
import com.lyq.util.PBEUtils;

@WebServlet("/servlet/manage/teacher/AddTeacherServlet")
public class AddTeacherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//获得加密工具
		PBEUtils pbeUtils = new PBEUtils();
		// 拿到service
		ManageService mgs = new ManageService();
		// 获得参数
		String prefix = request.getParameter("prefix");
		String gender = request.getParameter("gender");
		String password = request.getParameter("password");
		String ids = request.getParameter("ids");
		String names = request.getParameter("names");
		// 检查参数的正确性
		if(prefix == null || "".equals(prefix.trim()) || !prefix.trim().matches("[a-zA-Z]{3}")){
			response.getWriter().write("输入前缀格式错误，格式为3个字母！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		prefix = prefix.trim();
		if(gender == null || "".equals(gender) || !gender.matches("[男]|[女]")){
			response.getWriter().write("输入性别格式错误，只能输入 男 或者 女！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(password == null || "".equals(password.trim()) || !password.trim().matches("\\w{6,10}")){
			response.getWriter().write("输入的密码格式错误，只能输入6到10个字母、数字、下划线");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		password = password.trim();
		//检查ids和names并获得学号列表和姓名列表
		String[] TeacherIds = null;
		if(ids == null || "".matches(ids.trim())){
			response.getWriter().write("请输入账号后缀");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else{
			TeacherIds = ids.split("\n");
			for(int i = 0; i < TeacherIds.length; i++){
				TeacherIds[i] = TeacherIds[i].trim();
				if(!TeacherIds[i].matches("\\d{6}")){
					response.getWriter().write("第"+(i+1)+"个账号后缀错误<br>"
							+"为:  "+TeacherIds[i]);
					response.getWriter()
							.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
					return;
				}
			}
		}
		String[] TeacherNames = null;
		if(names == null || "".matches(names.trim())){
			response.getWriter().write("请输入教师姓名");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else{
			TeacherNames = names.split("\n");
			for(int i = 0; i < TeacherNames.length; i++){
				TeacherNames[i] = TeacherNames[i].trim();
				if(!TeacherNames[i].matches("^(?=.*?[\u4E00-\u9FA5])[\\dA-Za-z\u4E00-\u9FA5]+")){
					response.getWriter().write("第"+(i+1)+"个教师姓名错误<br>"
							+"为:  "+TeacherNames[i]);
					response.getWriter()
							.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
					return;
				}
			}
		}
		//确认输入的姓名和账号个数一样
		if(TeacherIds.length != TeacherNames.length){
			response.getWriter().write("输入的账号后缀个数和姓名个数不一致，请检查！<br>"
					+"建议一行只输入一个账号后缀或姓名");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		
		//添加教师并返回结果
		int totalRecord = TeacherIds.length;	//总记录数
		int successNum = 0;	//添加成功个数
		int failureNum = 0;	//添加失败个数
		List<Teacher> successList = new ArrayList<Teacher>();	//添加成功的教师
		List<Teacher> failureList = new ArrayList<Teacher>();	//添加失败的教师 
		Teacher tch = null;
		for (int i = 0; i < TeacherIds.length; i++) {
			tch = new Teacher();
			tch.setId(prefix + TeacherIds[i]);
			tch.setName(TeacherNames[i]);
			tch.setPassword(pbeUtils.encrypt(tch.getId(), password));
			tch.setGender(gender);
			if(mgs.addTeacher(tch)){
				//添加成功
				successNum++;
				successList.add(tch);
			}else{
				//添加失败
				failureNum++;
				failureList.add(tch);
			}
		}
		response.getWriter().write("总共接收到"+totalRecord+"条数据<br>"
				+ "其中添加成功了"+successNum+"条数据，分别为<hr>");
		Iterator<Teacher> successIterator = successList.iterator();
		while(successIterator.hasNext()){
			Teacher teacher = successIterator.next();
			response.getWriter().write(teacher.getId()+"   "+teacher.getName()+"<br>");
		}
		response.getWriter().write("<hr>添加失败的数据有"+failureNum+"条，分别为<hr>");
		Iterator<Teacher> failureIterator = failureList.iterator();
		while(failureIterator.hasNext()){
			Teacher teacher = failureIterator.next();
			response.getWriter().write(teacher.getId()+"   "+teacher.getName()+"<br>");
		}
		response.getWriter().write("<hr>");
		response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
		response.getWriter().write("<input type=\"button\" value=\"继续添加\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/teacher/addTeacher.jsp';\">");
	}

}
