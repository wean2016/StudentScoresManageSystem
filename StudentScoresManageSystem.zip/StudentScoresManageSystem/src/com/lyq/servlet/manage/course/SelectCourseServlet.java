package com.lyq.servlet.manage.course;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Course;
import com.lyq.model.Evaluate;
import com.lyq.model.Scores;
import com.lyq.model.Student;
import com.lyq.service.manage.ManageService;

@WebServlet("/servlet/manage/course/SelectCourseServlet")
public class SelectCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到service
		ManageService mgs = new ManageService();
		// 获得页面传来的数据
		String CourseId = request.getParameter("CourseId");
		String term = request.getParameter("term");
		String stuGrade = request.getParameter("stuGrade");
		String stuClass = request.getParameter("stuClass");
		// 检查参数的正确性
		List<String> terms = (List<String>) request.getSession().getAttribute("terms");
		if (term == null || "".equals(term) || !terms.contains(term)) {
			response.getWriter().write("选择的学期不存在！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if (CourseId == null || "".equals(CourseId)) {
			response.getWriter().write("课程id不能为空！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if (!CourseId.matches("CRS\\d{3}")) {
			response.getWriter().write("课程id格式错误！！课程id由 CRS加上三个数字组成");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		Course crs = mgs.findCourseById(CourseId);
		if(crs == null){
			response.getWriter().write("找不到该课程");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 检查stuGrade和stuClass是否正确
		try {
			if (stuGrade != null && !"".equals(stuGrade) && !mgs.getGrades().contains(Integer.parseInt(stuGrade))) {
				response.getWriter().write("选择的年级不存在！");
				response.getWriter()
						.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
			}
		} catch (Exception e) {
			response.getWriter().write("选择的年级格式错误！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		
		if (stuClass != null && !"".equals(stuClass) && !mgs.getClasses().contains(stuClass)) {
			response.getWriter().write("选择的班级不存在！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 创建选课操作模型和相应的评价教师模型
		Scores scores = new Scores(term, CourseId);
		
		Evaluate ev = new Evaluate(crs.getTeacherId(),crs.getCourseId(),crs.getTerm());
		// 拿到要操作的学生列表
		Student searchModel = new Student();
		searchModel.setStuClass(stuClass);
		if (stuGrade != null && !"".equals(stuGrade)){
			searchModel.setStuGrade(Integer.parseInt(stuGrade));
		}
		List<Student> stuList = mgs.findStudent(searchModel, 1, 1000000).getDataList();
		// 选课并返回结果
		int totalRecord = stuList.size(); // 总记录数
		int successNum = 0; // 添加成功个数
		int failureNum = 0; // 添加失败个数
		List<Student> successList = new ArrayList<Student>(); // 添加成功的学生
		List<Student> failureList = new ArrayList<Student>(); // 添加失败的学生
		// 拿到迭代器
		Iterator<Student> it = stuList.iterator();
		//执行操作
		Student stu = null;
		while(it.hasNext()){
			stu = it.next();
			ev.setStudent_id(stu.getId());
			scores.setStuClass(stu.getStuClass());
			scores.setStudentId(stu.getId());;
			if(mgs.selectClass(scores, ev)){
				//添加成功
				successNum++;
				successList.add(stu);
			}else{
				//添加失败
				failureNum++;
				failureList.add(stu);
			}
		}
		//返回结果
		response.getWriter().write("总共有"+totalRecord+"个学生要添加课程<br>"
				+ "其中添加成功了"+successNum+"个学生的课程，分别为<hr>");
		Iterator<Student> successIterator = successList.iterator();
		while(successIterator.hasNext()){
			Student student = successIterator.next();
			response.getWriter().write(student.getId()+"   "+student.getName()+"   "+student.getStuGrade()+"   "+student.getStuClass()+"<br>");
		}
		response.getWriter().write("<hr>添加失败的学生有"+failureNum+"条，分别为<hr>");
		Iterator<Student> failureIterator = failureList.iterator();
		while(failureIterator.hasNext()){
			Student student = failureIterator.next();
			response.getWriter().write(student.getId()+"   "+student.getName()+"   "+student.getStuGrade()+"   "+student.getStuClass()+"<br>");
		}
		response.getWriter().write("<hr>");
		response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
		response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
	}

}
