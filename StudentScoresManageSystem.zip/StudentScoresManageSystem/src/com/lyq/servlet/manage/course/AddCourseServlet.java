package com.lyq.servlet.manage.course;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Course;
import com.lyq.model.Student;
import com.lyq.service.manage.ManageService;
import com.lyq.service.teacher.TeacherManageService;

@WebServlet("/servlet/manage/course/AddCourseServlet")
public class AddCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到service
		ManageService mgs = new ManageService();
		// 获得参数
		String term = request.getParameter("term");
		String CourseId = request.getParameter("CourseId");
		String Cname = request.getParameter("Cname");
		String TeacherId = request.getParameter("TeacherId");
		String creditStr = request.getParameter("credit");
		// 检查参数的正确性
		List<String> terms = (List<String>) request.getSession().getAttribute("terms");
		if(term == null || "".equals(term) || !terms.contains(term)){
			response.getWriter().write("选择的学期不存在！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(CourseId == null || "".equals(CourseId)){
			response.getWriter().write("课程id不能为空！！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if(!CourseId.matches("CRS\\d{3}")){
			response.getWriter().write("课程id格式错误！！课程id由 CRS加上三个数字组成");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(Cname == null || "".equals(Cname)){
			response.getWriter().write("课程名称不能为空！！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		Cname = Cname.trim();
		if(!Cname.matches("[\u4E00-\u9FA5]+")){
			response.getWriter().write("课程名称格式错误！！只能输入中文");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(TeacherId != null && !"".equals(TeacherId.trim()) && !TeacherId.trim().matches("tch\\d{6}")){
			response.getWriter().write("教师id格式错误");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(creditStr == null || "".equals(creditStr.trim())){
			response.getWriter().write("学分不能为空！！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		creditStr = creditStr.trim();
		if(!creditStr.matches("^[+-]?([0-9]*\\.?[0-9]+|[0-9]+\\.?[0-9]*)([eE][+-]?[0-9]+)?$")){
			response.getWriter().write("学分格式错误！！请输入正确的学分");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		double credit = Double.parseDouble(creditStr);
		//添加课程并返回结果
		Course crs = new Course(term, CourseId, Cname, TeacherId, credit);
		if(mgs.addCourse(crs)){
			response.getWriter().write("添加成功<hr>");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			response.getWriter().write("<input type=\"button\" value=\"继续添加\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/course/addCourse.jsp';\">");
		}else{
			response.getWriter().write("添加失败！请检查课程是否已经存在");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
	}
}
