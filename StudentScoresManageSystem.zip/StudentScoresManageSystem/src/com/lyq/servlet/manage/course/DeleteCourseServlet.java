package com.lyq.servlet.manage.course;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.service.manage.ManageService;


@WebServlet("/servlet/manage/course/DeleteCourseServlet")
public class DeleteCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获取要修改的课程的id并检查格式
		String CourseId = request.getParameter("CourseId");
		if(CourseId == null || "".equals(CourseId)){
			response.getWriter().write("课程id不能为空！！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if(!CourseId.matches("CRS\\d{3}")){
			response.getWriter().write("课程id格式错误！！课程id由 CRS加上三个数字组成");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		
		//拿到service
		ManageService mgs = new ManageService();
		
		//执行操作
		if(mgs.deleteCourse(CourseId)){
			response.getWriter().write("删除成功！");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			response.getWriter().write("<input type=\"button\" value=\"返回上一页\" onclick=\"javascript:window.history.back(-1);\">");
		}else{
			response.getWriter().write("该课程不存在！");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			response.getWriter().write("<input type=\"button\" value=\"返回上一页\" onclick=\"javascript:window.history.back(-1);\">");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
