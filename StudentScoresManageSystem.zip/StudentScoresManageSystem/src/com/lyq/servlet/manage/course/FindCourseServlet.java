package com.lyq.servlet.manage.course;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Course;
import com.lyq.model.Pager;
import com.lyq.model.Student;
import com.lyq.service.manage.ManageService;
import com.lyq.service.teacher.TeacherManageService;


@WebServlet("/servlet/manage/course/FindCourseServlet")
public class FindCourseServlet extends HttpServlet {
	ManageService mgs = new ManageService();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接受request里的参数
		String Cname = request.getParameter("Cname");
		String term = request.getParameter("term");
		String TeacherId = request.getParameter("TeacherId");
		String name = request.getParameter("name");
		
		//检查输入数据格式是否正确
		if(Cname != null && !"".equals(Cname.trim()) && !Cname.trim().matches("[a-zA-Z\u4E00-\u9FA5]+")){
			response.getWriter().write("输入的课程名称不正确，请输入中文！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		List<String> terms = (List<String>) request.getSession().getAttribute("terms");
		if(term == null && "".equals(term) && !terms.contains(term)){
			response.getWriter().write("选择的学期不存在！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(TeacherId != null && !"".equals(TeacherId.trim()) && !TeacherId.trim().matches("tch\\d{6}")){
			response.getWriter().write("教师id格式错误");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(name != null && !"".equals(name.trim()) && !name.matches("[\u4E00-\u9FA5]{1,5}(?:·[\u4E00-\u9FA5]{2,5})*")){	//可以进行模糊搜索
			response.getWriter().write("输入的姓名格式不正确！请输入一个以上的汉字，可加·号");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(name != null && !"".equals(name.trim()) && !name.matches("[\u4E00-\u9FA5]{1,5}(?:·[\u4E00-\u9FA5]{2,5})*")){	//可以进行模糊搜索
			response.getWriter().write("输入的姓名格式不正确！请输入一个以上的汉字，可加·号");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		
		//检查pageNum
		String pageNumStr = request.getParameter("pageNum");
		if(pageNumStr !=null && !"".equals(pageNumStr.trim()) &&!pageNumStr.matches("^[1-9]\\d*$")){
			response.getWriter().write("请选择正确的页数！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageNum = 1; //默认显示第一页数据
		if(pageNumStr!=null && !"".equals(pageNumStr.trim())){
			pageNum = Integer.parseInt(pageNumStr);
		}
		//检查pageSize
		String pageSizeStr = request.getParameter("pageSize");
		if(pageSizeStr!=null && !"".equals(pageSizeStr.trim()) &&!pageSizeStr.matches("^[1-9]\\d*$")){
			response.getWriter().write("请正确输入每页显示几条数据");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageSize = 10;  // 默认显示10条数据
		if(pageSizeStr!=null && !"".equals(pageSizeStr.trim())){
			pageSize = Integer.parseInt(pageSizeStr);
		}
		// 组装查询条件
		Course searchModel = new Course(); 
		searchModel.setCname(Cname);
		searchModel.setTerm(term);
		searchModel.setTeacherId(TeacherId);
		searchModel.setTeacherName(name);
		
		
		//调用service获取查询结果
		Pager<Course> result = mgs.findCourse(searchModel, pageNum, pageSize);
		
		// 返回结果到页面
		request.setAttribute("result", result);
		request.setAttribute("Cname", Cname);
		request.setAttribute("term", term);
		request.setAttribute("TeacherId", TeacherId);
		request.setAttribute("name", name);
		request.setAttribute("pageSize", pageSize);
		request.getRequestDispatcher("/manage/course/searchCourse.jsp").forward(request, response);
	}

}
