package com.lyq.servlet.manage.term;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.service.manage.ManageService;


@WebServlet("/servlet/manage/term/DeleteTermServlet")
public class DeleteTermServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//拿到id
		String term = request.getParameter("term");
		if(term == null || "".equals(term.trim())){
			response.getWriter().write("请输入要删除的学期！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else if(!term.trim().matches("[\\d\u4E00-\u9FA5]+")){
			response.getWriter().write("输入的学期格式不正确！请检查！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else{
			term = term.trim();
		}
		
		//拿到service
		ManageService mgs = new ManageService();
		
		//执行操作
		if(mgs.deleteTerm(term)){
			response.getWriter().write("删除成功！");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			response.getWriter().write("<input type=\"button\" value=\"返回上一页\" onclick=\"javascript:window.history.back(-1);\">");
			//更新session中的数据
			request.getSession().setAttribute("terms", mgs.getTerms());
		}else{
			response.getWriter().write("该学期不存在！");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			response.getWriter().write("<input type=\"button\" value=\"返回上一页\" onclick=\"javascript:window.history.back(-1);\">");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
