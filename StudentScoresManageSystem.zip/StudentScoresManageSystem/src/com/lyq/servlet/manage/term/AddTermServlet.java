package com.lyq.servlet.manage.term;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Student;
import com.lyq.model.Teacher;
import com.lyq.service.manage.ManageService;
import com.lyq.service.teacher.TeacherManageService;

@WebServlet("/servlet/manage/term/AddTermServlet")
public class AddTermServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到service
		ManageService mgs = new ManageService();
		// 获得参数
		String term = request.getParameter("term");
		// 检查参数的正确性
		if(term == null || "".equals(term)){
			response.getWriter().write("请输入要添加的学期的名称！！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		term = term.trim();
		if(!term.matches("[\\d\u4E00-\u9FA5]+")){
			response.getWriter().write("学期名称格式错误！！只能输入数字和中文，例如“2016年春季”");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		
		//添加学期并返回结果
		if(mgs.addTerm(term)){
			//添加成功
			//更新session中的数据
			request.getSession().setAttribute("terms", mgs.getTerms());
			response.getWriter().write("添加成功！<br>");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			response.getWriter().write("<input type=\"button\" value=\"继续添加\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/term/addTerm.jsp';\">");
		}else{
			response.getWriter().write("该学期已存在！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
		}
	}

}
