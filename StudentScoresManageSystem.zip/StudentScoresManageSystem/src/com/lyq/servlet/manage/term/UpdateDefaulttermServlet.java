package com.lyq.servlet.manage.term;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.service.manage.ManageService;

@WebServlet("/servlet/manage/term/UpdateDefaulttermServlet")
public class UpdateDefaulttermServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得页面传来的默认学期
		String term = request.getParameter("term");
		List<String> terms = (List<String>) request.getSession().getAttribute("terms");
		if (term == null && "".equals(term) && !terms.contains(term)) {
			response.getWriter().write("选择的学期不存在！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 调用service进行操作
		ManageService mgs = new ManageService();
		if (mgs.updateDefaultterm(term)) {
			response.getWriter().write("修改成功！<br>");
			response.getWriter().write(
					"<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			return;
		} else {
			response.getWriter().write("sorry，发生了未知的错误<br>");
			response.getWriter().write(
					"<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/manage/main.jsp';\">");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
	}

}
