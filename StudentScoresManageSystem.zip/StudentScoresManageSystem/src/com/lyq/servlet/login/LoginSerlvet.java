package com.lyq.servlet.login;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lyq.dao.ClassAndGradeDao;
import com.lyq.model.Manage;
import com.lyq.model.Student;
import com.lyq.model.Teacher;
import com.lyq.service.login.ManageLoginService;
import com.lyq.service.login.StudentLoginService;
import com.lyq.service.login.TeacherLoginService;
import com.lyq.util.PBEUtils;

//@WebServlet("/servlet/login/StudentLoginSerlvet")
public class LoginSerlvet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			//防爆破，登陆时先休眠0.5秒再进去
			Thread.sleep(500);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		//定义service
		TeacherLoginService tlv = null;
		StudentLoginService slv = null;
		ManageLoginService	mls = null;
		// 定义保存从数据库中拿到的学生，教师,管理员信息的实体类
		Student stu_info = null;
		Teacher tch_info = null;
		Manage mng_info = null;
		/**
		 * 获取用户输入的账号密码和验证码
		 */
		String inputId = request.getParameter("id");
		String inputPassword = request.getParameter("password");
		String checkcode = request.getParameter("checkcode");
		//检查验证码
		String piccode = (String) request.getSession().getAttribute("piccode");//session中的验证码
		if(checkcode == null || "".equals(checkcode.trim())){
			request.setAttribute("CheckcodeIsBlank", true);
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		checkcode = checkcode.trim().toUpperCase();
		if(!checkcode.equals(piccode)){
			request.setAttribute("CheckcodeFormatWrong", true);
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		
		/**
		 * 检查输入的账号密码格式是否正确和输入的是学生账号还是教师账号
		 */
		String identify = null;
		if (!inputId.matches("[0-9]{10}|tch\\d{6}|[\\u4e00-\\u9fa5]+")) {
			request.setAttribute("IdFormatWrong", true);
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		} else {
			if (inputId.matches("[0-9]{10}")) {
				identify = "student";
			}
			if (inputId.matches("tch\\d{6}")) {
				identify = "teacher";
			}
			if (inputId.matches("[\\u4e00-\\u9fa5]+")) {
				identify = "manage";
			}
		}
		if (!inputPassword.matches("\\w{6,10}|[\\u4e00-\\u9fa5]+")) {
			request.setAttribute("PasswordFormatWrong", true);
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		//将密码转换为加密后的密码
		PBEUtils pbeUtils = new PBEUtils();
		inputPassword = pbeUtils.encrypt(inputId, inputPassword);
		// 如果是学生
		if ("student".equals(identify)) {
			Student stu = new Student();
			stu.setId(inputId);
			stu.setPassword(inputPassword);
			/**
			 * 检查账号状态、账号是否存在
			 */
			slv = new StudentLoginService();
			Student stu_status = null;
			stu_status = slv.checkStudentStatus(stu.getId());
			if (stu_status == null) { // 若用户输入的账号不存在
				request.setAttribute("AccountNotFound", true);
				request.getRequestDispatcher("/login.jsp").forward(request, response);
				return; // 结束后面执行的语句
			}
			if (stu_status.getIsLocking() == 1) {
				request.setAttribute("AccountIsLocking", true);
				request.getRequestDispatcher("/login.jsp").forward(request, response);
				return; // 结束后面执行的语句
			}
			/**
			 * 检查账号密码是否正确 若不正确，更新账号状态，返回密码错误次数并提示三次错误冻结账号 若正确，更新账号状态
			 */
			try {
				stu_info = slv.login(stu);

				if (stu_info == null) { // 密码错误
					request.setAttribute("PasswordWrong", true);
					if (slv.updateStudentStatus(stu.getId(), true)) { // 账号状态正常，返回账号密码错误次数
						request.setAttribute("PasswordWrongTimes", slv.checkStudentStatus(stu.getId()).getWrongTimes());
						request.getRequestDispatcher("/login.jsp").forward(request, response);
						return; // 结束后面执行的语句
					} else {
						request.setAttribute("AccountIsLocking", true);
						request.getRequestDispatcher("/login.jsp").forward(request, response);
						return; // 结束后面执行的语句
					}
				} else {
					// 密码正确,更新装好状态
					slv.updateStudentStatus(stu.getId(), false);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// 如果是教师
		if ("teacher".equals(identify)) {
			Teacher tch = new Teacher();
			tch.setId(inputId);
			tch.setPassword(inputPassword);
			/**
			 * 检查账号状态、账号是否存在
			 */
			tlv = new TeacherLoginService();
			Teacher tch_status = null;
			tch_status = tlv.checkTeacherStatus(tch.getId());
			if (tch_status == null) { // 若用户输入的账号不存在
				request.setAttribute("AccountNotFound", true);
				request.getRequestDispatcher("/login.jsp").forward(request, response);
				return; // 结束后面执行的语句
			}
			if (tch_status.getIsLocking() == 1) {
				request.setAttribute("AccountIsLocking", true);
				request.getRequestDispatcher("/login.jsp").forward(request, response);
				return; // 结束后面执行的语句
			}
			/**
			 * 检查账号密码是否正确 若不正确，更新账号状态，返回密码错误次数并提示三次错误冻结账号 若正确，更新账号状态
			 */
			try {
				tch_info = tlv.login(tch);

				if (tch_info == null) { // 密码错误
					request.setAttribute("PasswordWrong", true);
					if (tlv.updateTeacherStatus(tch.getId(), true)) { // 账号状态正常，返回账号密码错误次数
						request.setAttribute("PasswordWrongTimes", tlv.checkTeacherStatus(tch.getId()).getWrongTimes());
						request.getRequestDispatcher("/login.jsp").forward(request, response);
						return; // 结束后面执行的语句
					} else {
						request.setAttribute("AccountIsLocking", true);
						request.getRequestDispatcher("/login.jsp").forward(request, response);
						return; // 结束后面执行的语句
					}
				} else {
					// 密码正确,更新装好状态
					tlv.updateTeacherStatus(tch.getId(), false);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//如果是管理员
		if ("manage".equals(identify)) {
			Manage mng = new Manage();
			mng.setId(inputId);
			mng.setPassword(inputPassword);
			/**
			 * 检查账号状态、账号是否存在
			 */
			mls = new ManageLoginService();
			Manage mng_status = null;
			try {
				mng_status = mls.checkManageStatus(mng.getId());
			} catch (Exception e1) {
				// TODO 自动生成的 catch 块
				e1.printStackTrace();
			}
			if (mng_status == null) { // 若用户输入的账号不存在
				request.setAttribute("AccountNotFound", true);
				request.getRequestDispatcher("/login.jsp").forward(request, response);
				return; // 结束后面执行的语句
			}
			if (mng_status.getIsLocking() == 1) {
				request.setAttribute("AccountIsLocking", true);
				request.getRequestDispatcher("/login.jsp").forward(request, response);
				return; // 结束后面执行的语句
			}
			/**
			 * 检查账号密码是否正确 若不正确，更新账号状态，返回密码错误次数并提示三次错误冻结账号 若正确，更新账号状态
			 */
			try {
				mng_info = mls.login(mng);

				if (mng_info == null) { // 密码错误
					request.setAttribute("PasswordWrong", true);
					if (mls.updateManageStatus(mng.getId(), true)) { // 账号状态正常，返回账号密码错误次数
						request.setAttribute("PasswordWrongTimes", mls.checkManageStatus(mng.getId()).getWrongTimes());
						request.getRequestDispatcher("/login.jsp").forward(request, response);
						return; // 结束后面执行的语句
					} else {
						request.setAttribute("AccountIsLocking", true);
						request.getRequestDispatcher("/login.jsp").forward(request, response);
						return; // 结束后面执行的语句
					}
				} else {
					// 密码正确,更新装好状态
					mls.updateManageStatus(mng.getId(), false);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		// 密码正确,在session中添加该学生/教师/管理员的信息和已以学生/教师/管理员身份登陆的标记,
		HttpSession session = request.getSession();

		// 是否记住账号
		if (request.getParameter("remenberAccount") != null && "true".equals(request.getParameter("remenberAccount"))) {
			// 设置session周期为7天
			session.setMaxInactiveInterval(7 * 24 * 3600);
			// 创建session对应的cookie，并设置路径和生命为7天
			Cookie cookie = new Cookie("JSESSIONID", session.getId());
			cookie.setMaxAge(7 * 24 * 3600);
			cookie.setPath(session.getServletContext().getContextPath() + "/");
			// 添加cookie到本地
			response.addCookie(cookie);
		}
		session.setAttribute("logined", true);
		
		// 转到主页面
		if ("student".equals(identify)) {
			//如果是学生，再添加学期、班级和年级信息到session
			List<String> terms = slv.getTerms();
			List<Integer> grades = slv.getGrades();
			List<String> classes = slv.getClasses();
			session.setAttribute("terms", terms);
			session.setAttribute("grades", grades);
			session.setAttribute("classes", classes);
			session.setAttribute("stu_info", stu_info);
			// 跳转到登陆成功的页面
			response.sendRedirect(session.getServletContext().getContextPath() + "/student/main.jsp");
		}
		if ("teacher".equals(identify)) {
			//如果是教师，再添加学期、班级和年级信息到session
			
			List<Integer> grades = tlv.getGrades();
			List<String> classes = tlv.getClasses();
			List<String> terms = tlv.getTerms();
			
			session.setAttribute("grades", grades);
			session.setAttribute("classes", classes);
			session.setAttribute("terms", terms);
			session.setAttribute("tch_info", tch_info);
			// 跳转到登陆成功的页面
			response.sendRedirect(session.getServletContext().getContextPath() + "/teacher/main.jsp");
		}
		if ("manage".equals(identify)) {
			//如果是教师，再添加学期、班级和年级信息到session
			
			List<Integer> grades = mls.getGrades();
			List<String> classes = mls.getClasses();
			List<String> terms = mls.getTerms();
			
			
			session.setAttribute("grades", grades);
			session.setAttribute("classes", classes);
			session.setAttribute("terms", terms);
			session.setAttribute("mng_info", mng_info);
			// 跳转到登陆成功的页面
			request.getRequestDispatcher("/manage/main.jsp").forward(request, response);
		}
	}

}
