package com.lyq.servlet.logout;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/servlet/logout/LogoutServlet")
public class LogoutServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.removeAttribute("logined");
		session.removeAttribute("stu_info");
		session.removeAttribute("tch_info");
		response.getWriter().print("注销成功！三秒后自动前往登陆页面");
		response.getWriter().print("<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/login.jsp'\",3000)</script>");
	}

}
