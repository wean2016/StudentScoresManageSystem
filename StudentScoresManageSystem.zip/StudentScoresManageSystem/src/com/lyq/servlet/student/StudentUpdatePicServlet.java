package com.lyq.servlet.student;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.lyq.model.Student;
import com.lyq.service.student.StudentService;

@WebServlet("/servlet/student/StudentUpdatePicServlet")
public class StudentUpdatePicServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		StudentService ss = new StudentService();
		// 定义上传图片的限制类型
		List<String> suffixList = new ArrayList<String>();
		suffixList.add(".png");
		suffixList.add(".gif");
		suffixList.add(".jpg");

		String pic = null;
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(factory);
		// 设置单个文件大小限制
		sfu.setFileSizeMax(1024 * 2014);
		try {
			List<FileItem> fiList = sfu.parseRequest(request);
			for (FileItem fi : fiList) {
				// 获得表单的文本域名字
				String fieldName = fi.getFieldName();
				// 是否是文件类型
				boolean isComm = fi.isFormField();
				// 获得原始文件名
				String oriFileName = fi.getName();
				// 如果是文件（用户上传的头像）
				if (!isComm && fieldName != null && !"".equals(fieldName)) {
					// 获得要上传的绝对路径
					String realPath = request.getSession().getServletContext().getRealPath("/pic/");
					if (oriFileName != null && !"".equals(oriFileName)) {
						String suffix = oriFileName.substring(oriFileName.lastIndexOf("."));
						// 确认后缀
						if (suffixList.contains(suffix)) {
							// 随机生成一个字符串再加上id作为文件保存在服务器中的名字
							String tFileName = UUID.randomUUID().toString() + "_"
									+ (String) session.getAttribute("registId");
							String relativePath = "/pic/" + tFileName + suffix;
							pic = relativePath;
							File file = new File(realPath, tFileName + suffix);
							fi.write(file);
						} else {
							response.getWriter().print("图片格式错误，请上传jpg,png,gif格式的图片");
							return;
						}
					}
				}
			}
			//将图片地址更新到数据库和session
			Student stu = (Student) session.getAttribute("stu_info");
			stu.setPic(pic);
			session.setAttribute("stu_info", stu);
			ss.updateStudentPicInformation(stu);
			//提示更新成功
			response.getWriter().write("修改成功，三秒后返回主页！");
			response.getWriter().print(
					"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/student/main.jsp'\",3000)</script>");
		} catch (Exception e) {
			if (e instanceof FileUploadBase.FileSizeLimitExceededException) {
				response.getWriter().write("文件过大，请上传1M以内的图片\n");
				response.getWriter().write("三秒后返回更新头像页面");
				response.getWriter().print(
						"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/student/information/updatePic.jsp'\",3000)</script>");
			}
		}
	}
}
