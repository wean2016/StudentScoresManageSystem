package com.lyq.servlet.student;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Evaluate;
import com.lyq.model.Student;
import com.lyq.service.student.StudentService;

@WebServlet("/servlet/student/evaluate/EvaluateIndexServlet")
public class EvaluateIndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获得service
		StudentService ss = new StudentService();
		//获得session中的studentid
		Student stu_info = (Student) request.getSession().getAttribute("stu_info");
		String studentId = stu_info.getId();
		//获得默认学期
		String defaultterm = ss.getDefaultTerm();
		//拿到学生本学期的课程列表
		//创建查询模型
		Evaluate param = new Evaluate();
		param.setStudent_id(studentId);
		param.setTerm(defaultterm);
		//查询
		List<Evaluate> result = ss.findEvaluateByStudentAndTerm(param);
		//返回结果
		request.setAttribute("defaultterm", defaultterm);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/student/evaluate/evaluate.jsp").forward(request, response);
	}

}
