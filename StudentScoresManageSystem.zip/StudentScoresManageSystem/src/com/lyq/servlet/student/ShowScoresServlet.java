package com.lyq.servlet.student;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Scores;
import com.lyq.model.Student;
import com.lyq.service.student.StudentService;

@WebServlet("/servlet/student/scores/ShowScoresServlet")
public class ShowScoresServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 接受request里的参数
		String term = request.getParameter("term");
		List<String> terms = (List<String>) request.getSession().getAttribute("terms");
		if (term == null && "".equals(term) && !terms.contains(term)) {
			response.getWriter().write("选择的学期不存在！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 拿到学生id
		Student stu_info = (Student) request.getSession().getAttribute("stu_info");
		String id = stu_info.getId();
		// 拿到service
		StudentService ss = new StudentService();
		// 查询
		List<Scores> scores = ss.findStudentScoresByStudentIdAndTerm(id, term);
		Student scoresInformation = ss.findStudentTermScore(id, term);
		// 返回结果
		request.setAttribute("searchterm", term);
		request.setAttribute("scores", scores);
		request.setAttribute("scoresInformation", scoresInformation);
		request.getRequestDispatcher("/student/scores/showScores.jsp").forward(request, response);
	}

}
