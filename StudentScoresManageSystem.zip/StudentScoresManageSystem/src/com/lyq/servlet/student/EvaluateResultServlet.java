package com.lyq.servlet.student;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Evaluate;
import com.lyq.model.Student;
import com.lyq.service.student.StudentService;

@WebServlet("/servlet/student/evaluate/EvaluateResultServlet")
public class EvaluateResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得service
		StudentService ss = new StudentService();
		// 获得session中的studentid
		Student stu_info = (Student) request.getSession().getAttribute("stu_info");
		String studentId = stu_info.getId();
		// 获得request中的课程id
		String CourseId = request.getParameter("CourseId");
		// 检查courseid的格式
		if (CourseId == null || "".equals(CourseId)) {
			response.getWriter().write("课程id不能为空！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if (!CourseId.matches("CRS\\d{3}")) {
			response.getWriter().write("课程id格式错误！！课程id由 CRS加上三个数字组成");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 组装参数查询该evaluate是否已评价
		Evaluate param = new Evaluate();
		param.setStudent_id(studentId);
		param.setCourseId(CourseId);
		// 调用service进行查询
		int status = ss.ifIsEvaluated(param);
		if (status == -1) {
			response.getWriter().write("您并未选修该课程！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		} else if (status == 1) {
			response.getWriter().write("您已经对该课程进行了评价！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//获得request中的评价内容
		String lesson = request.getParameter("lesson");
		String homework = request.getParameter("homework");
		//检查格式
		if(lesson == null || "".equals(lesson)){
			response.getWriter().write("您评价该课程的教学情况！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(!lesson.matches("非常满意|很满意|满意|一般|不满意")){
			response.getWriter().write("评价的格式不正确！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(homework == null || "".equals(homework)){
			response.getWriter().write("您评价该课程的作业批改情况！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(!homework.matches("非常满意|很满意|满意|一般|不满意")){
			response.getWriter().write("评价的格式不正确！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//组装模型进行评价并返回结果
		Evaluate ev = new Evaluate();
		ev.setStudent_id(studentId);
		ev.setCourseId(CourseId);
		ev.setHomework(homework);
		ev.setLesson(lesson);
		if(ss.updateEvaluate(ev)){
			response.getWriter().write("评价成功！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/teacher/main.jsp';\">");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else{
			response.getWriter().write("发生了未知的错误……！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/teacher/main.jsp';\">");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
	}

}
