package com.lyq.servlet.student;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Evaluate;
import com.lyq.model.Student;
import com.lyq.service.student.StudentService;

/**
 * Servlet implementation class EvaluateServlet
 */
@WebServlet("/servlet/student/evulate/EvaluateServlet")
public class EvaluateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得service
		StudentService ss = new StudentService();
		// 获得session中的studentid
		Student stu_info = (Student) request.getSession().getAttribute("stu_info");
		String studentId = stu_info.getId();
		//获得request中的课程id
		String CourseId = request.getParameter("CourseId");
		//检查courseid的格式
		if(CourseId == null || "".equals(CourseId)){
			response.getWriter().write("课程id不能为空！！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if(!CourseId.matches("CRS\\d{3}")){
			response.getWriter().write("课程id格式错误！！课程id由 CRS加上三个数字组成");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//组装参数查询该evaluate是否已评价
		Evaluate param = new Evaluate();
		param.setStudent_id(studentId);
		param.setCourseId(CourseId);
		//调用service进行查询
		int status = ss.ifIsEvaluated(param);
		if(status == -1){
			response.getWriter().write("您并未选修该课程！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else if(status == 1){
			response.getWriter().write("您已经对该课程进行了评价！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//进入评价页面
		Evaluate result = ss.findEvaluate(param);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/student/evaluate/evaluatePage.jsp").forward(request, response);
		
	}

}
