package com.lyq.servlet.student;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Inform;
import com.lyq.service.student.StudentService;
import com.lyq.service.teacher.TeacherInformService;

/**
 * Servlet implementation class WatchAnInformServlet
 */
@WebServlet(name = "WatchAnInformServletForStudent", urlPatterns = {
		"/servlet/student/inform/WatchAnInform" })
public class WatchAnInformServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得service
		StudentService ss = new StudentService();
		// 获得要查看的通知的id
		String idStr = request.getParameter("id");
		if (!idStr.matches("\\d+")) {
			response.getWriter().write("获取要查找的通知失败！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int id = Integer.parseInt(idStr);
		// 拿到inform
		Inform im = ss.findInformById(id);
		// 把信息添加到request
		request.setAttribute("inform", im);
		request.getRequestDispatcher("/student/inform/watchInform.jsp").forward(request, response);
	}

}
