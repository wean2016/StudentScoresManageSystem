package com.lyq.servlet.student;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

import com.lyq.model.Inform;
import com.lyq.model.InformSearchModel;
import com.lyq.model.Pager;
import com.lyq.service.student.StudentService;
import com.lyq.service.teacher.TeacherInformService;

/**
 * Servlet implementation class ListInform
 */
@WebServlet(name = "ListInformForStudent", urlPatterns = { "/servlet/student/inform/ListInform" })
public class ListInform extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String startStr = request.getParameter("start");
		String endStr = request.getParameter("end");
		String keywords = request.getParameter("keywords");
		String sequence = request.getParameter("sequence");
		//检查输入格式是否正确并处理数据
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date start = null;
		if(startStr != null && !"".equals(startStr)){
			try {
				start = sdf.parse(startStr.trim());
			} catch (ParseException e) {
				response.getWriter().write("输入的起始日期格式不正确！<br>");
				response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
			}
		}
		Date end = null;
		if(endStr != null && !"".equals(endStr.trim())){
			try {
				//因为查询结果是以end这一天的0时0分0秒为结束，所以为了查询到这一天的通知，需要把end的时间后移一天
				end = sdf.parse(endStr);
				Calendar ca =  new GregorianCalendar(); //创建日历类
				ca.setTime(end);	
				ca.add(Calendar.DATE, 1);	//把时间往后移一天
				end = ca.getTime();	//设置时间
			} catch (ParseException e) {
				response.getWriter().write("输入的结束日期格式不正确！<br>");
				response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
			}
		}
		List<String> keywordsList = null;
		if(keywords != null && !"".equals(keywords.trim())){
			keywordsList = new ArrayList<String>();
			String[] keyword = keywords.split(" ");
			for(String s : keyword){
				keywordsList.add(StringEscapeUtils.escapeHtml(s.trim()));
			}
		}
		if(sequence != null && !"".equals(sequence)){
			if(!"ASC".equals(sequence) && !"DESC".equals(sequence)){
				response.getWriter().write("输入的排序方式不存在！<br>");
				response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
			}
		}
		//检查pageNum
		String pageNumStr = request.getParameter("pageNum");
		if(pageNumStr !=null && !"".equals(pageNumStr.trim()) &&!pageNumStr.matches("^[1-9]\\d*$")){
			response.getWriter().write("输入的页数格式不正确！<br>");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageNum = 1; //默认显示第一页数据
		if(pageNumStr!=null && !"".equals(pageNumStr.trim())){
			pageNum = Integer.parseInt(pageNumStr);
		}
		//检查pageSize
		String pageSizeStr = request.getParameter("pageSize");
		if(pageSizeStr!=null && !"".equals(pageSizeStr.trim()) &&!pageSizeStr.matches("^[1-9]\\d*$")){
			response.getWriter().write("输入的每页显示多少天数据格式不正确！<br>");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageSize = 10;  // 默认显示10条数据
		if(pageSizeStr!=null && !"".equals(pageSizeStr.trim())){
			pageSize = Integer.parseInt(pageSizeStr);
		}
		//组装查询条件
		InformSearchModel ism = new InformSearchModel(start, end, keywordsList, sequence);
		//调用service获得查询结果
		Pager<Inform> result = new StudentService().findInform(ism, pageNum, pageSize);
		//返回结果到页面
		request.setAttribute("result", result);
		request.setAttribute("start", startStr);
		request.setAttribute("end", endStr);
		request.setAttribute("keywords", keywords);
		request.setAttribute("sequence", sequence);
		request.setAttribute("pageSize", pageSize);
		request.getRequestDispatcher("/student/inform/listInform.jsp").forward(request, response);
	}

}
