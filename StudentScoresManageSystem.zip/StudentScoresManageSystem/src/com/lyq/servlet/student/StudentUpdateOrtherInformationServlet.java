package com.lyq.servlet.student;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lyq.model.Student;
import com.lyq.service.student.StudentService;

@WebServlet("/servlet/student/StudentUpdateOrtherInformationServlet")
public class StudentUpdateOrtherInformationServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到service类和session
		StudentService ss = new StudentService();
		HttpSession session = request.getSession();
		// 拿到保存在session中的Student类
		Student stu_info = (Student) session.getAttribute("stu_info");
		// 拿到用户输入的信息
		String stuGrade = request.getParameter("stuGrade");
		String stuClass = request.getParameter("stuClass");
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String e_mail = request.getParameter("e_mail");

		// 检查用户输入的数据的格式是否正确
		// 检查stuGrade和stuClass是否正确
		try {
			if (stuGrade == null || "".equals(stuGrade) || !ss.getGrades().contains(Integer.parseInt(stuGrade))) {
				response.getWriter().write("选择的年级不存在！");
				response.getWriter()
						.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
			}
		} catch (Exception e) {
			response.getWriter().write("选择的年级格式错误！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if (stuClass == null || "".equals(stuClass) || !ss.getClasses().contains(stuClass)) {
			response.getWriter().write("选择的班级不存在！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 检查姓名
		if (!name.matches("[\u4E00-\u9FA5]{2,5}(?:·[\u4E00-\u9FA5]{2,5})*")) {
			request.setAttribute("NameFormatWrong", true);
			request.getRequestDispatcher("/student/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 检查性别
		if (!gender.matches("[男]|[女]")) {
			request.setAttribute("GenderFormatWrong", true);
			request.getRequestDispatcher("/student/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 检查手机号码
		if (!phone.matches("[0-9]{11}") && !"".equals(phone) && !(phone == null)) {
			request.setAttribute("PhoneFormatWrong", true);
			request.getRequestDispatcher("/student/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 检查地址
		if (!address.matches("^(?=.*?[\u4E00-\u9FA5])[\\dA-Za-z\u4E00-\u9FA5]+") && !"".equals(address)
				&& !(address == null)) {
			request.setAttribute("AddressFormatWrong", true);
			request.getRequestDispatcher("/student/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 检查邮箱
		if (!e_mail.matches("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$") && !"".equals(e_mail)
				&& !(e_mail == null)) {
			request.setAttribute("E_mailFormatWrong", true);
			request.getRequestDispatcher("/student/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 用户输入数据格式正确
		// 将信息打包传入后台修改
		Student stu = new Student();
		stu.setId(stu_info.getId());
		stu.setName(name);
		stu.setGender(gender);
		stu.setPhone(phone);
		stu.setAddress(address);
		stu.setE_mail(e_mail);
		stu.setStuClass(stuClass);
		stu.setStuGrade(Integer.parseInt(stuGrade));

		if (ss.updateStudentInformation(stu) && ss.updateClassOnScores(stu)) {
			// 修改成功,更新session中的数据
			stu_info.setName(name);
			stu_info.setGender(gender);
			stu_info.setPhone(phone);
			stu_info.setAddress(address);
			stu_info.setE_mail(e_mail);
			stu_info.setStuClass(stuClass);
			stu_info.setStuGrade(Integer.parseInt(stuGrade));
			
			response.getWriter().write("修改成功，三秒后返回主页！");
			response.getWriter().print(
					"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/student/main.jsp'\",3000)</script>");
		} else {
			response.getWriter().write("sorry...发生了未知的错误...");
			response.getWriter().write("三秒后返回主页！");
			response.getWriter().print(
					"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/student/main.jsp'\",3000)</script>");
		}
	}

}
