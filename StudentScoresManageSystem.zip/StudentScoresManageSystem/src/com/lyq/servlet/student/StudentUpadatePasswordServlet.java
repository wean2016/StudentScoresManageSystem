package com.lyq.servlet.student;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lyq.model.Student;
import com.lyq.service.student.StudentService;
import com.lyq.util.PBEUtils;

@WebServlet("/servlet/student/StudentUpadatePasswordServlet")
public class StudentUpadatePasswordServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		StudentService ss = new StudentService();
		//获得加密工具
		PBEUtils pbeUtils = new PBEUtils();
		// 获得用户输入的数据
		String updata_oldPassword = request.getParameter("updata_oldPassword");
		String update_newPassword = request.getParameter("update_newPassword");
		String update_newPassword1 = request.getParameter("update_newPassword1");
		// 获得session中的学生数据
		Student stu_info = (Student) session.getAttribute("stu_info");
		/**
		 * 检查旧密码是否正确，若错误则更新学生账号状态，若正确则更新学生账号状态并继续执行
		 */
		//检查输入的新旧密码是否为空
		if(updata_oldPassword == null || "".equals(updata_oldPassword.trim())){
			response.getWriter().write("请输入旧密码！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(update_newPassword == null || "".equals(update_newPassword.trim())){
			response.getWriter().write("请输入新密码！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(update_newPassword == null || "".equals(update_newPassword.trim())){
			response.getWriter().write("请重复新密码！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//将输入的旧密码转化成加密后的字符串
		updata_oldPassword = pbeUtils.encrypt(stu_info.getId(), updata_oldPassword);
		// 若旧密码错误
		if (!updata_oldPassword.equals(stu_info.getPassword())) {
			// 更新状态
			try {
				// 如果账号被冻结，清除登陆状态并返回登陆页面
				if (ss.updateStudentStatus(stu_info.getId(), true) == false) {
					request.setAttribute("AccountIsLocking", true);
					session.removeAttribute("logined");
					session.removeAttribute("stu_info");
					request.getRequestDispatcher("/login.jsp").forward(request, response);
					return; // 结束后面执行的语句
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			// 否则返回错误次数
			request.setAttribute("oldPasswordWorng", true);
			request.setAttribute("PasswordWrongTimes", ss.checkStudentStatus(stu_info.getId()).getWrongTimes());
			request.getRequestDispatcher("/student/information/updatePassword.jsp").forward(request, response);
			return;
		} else {
			// 密码正确,更新装好状态
			try {
				ss.updateStudentStatus(stu_info.getId(), false);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// 检查新密码是否一致
		if (!update_newPassword.equals(update_newPassword1)) {
			// 不一致，返回修改页面
			request.setAttribute("NewPasswordDifferent", true);
			request.getRequestDispatcher("/student/information/updatePassword.jsp").forward(request, response);
			return;
		}
		// 检查新密码格式是否正确
		if (!update_newPassword.matches("\\w{6,10}")) {
			request.setAttribute("PasswordFormatWrong", true);
			request.getRequestDispatcher("/student/information/updatePassword.jsp").forward(request, response);
			return;
		}
		//将新密码转化为加密后的字符串
		update_newPassword = pbeUtils.encrypt(stu_info.getId(), update_newPassword);
		// 将信息打包传入后台修改
		Student stu = new Student();
		stu.setId(stu_info.getId());
		stu.setPassword(update_newPassword);

		if (ss.updateStudentPasswordInformation(stu)) {
			// 修改成功,更新session中的数据
			stu_info.setPassword(update_newPassword);
			session.setAttribute("stu_info", stu_info);
			response.getWriter().write("修改成功，三秒后返回主页！");
			response.getWriter().print(
					"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/student/main.jsp'\",3000)</script>");
		} else {
			response.getWriter().write("sorry...发生了未知的错误...");
			response.getWriter().write("三秒后返回主页！");
			response.getWriter().print(
					"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/student/main.jsp'\",3000)</script>");
		}

	}

}
