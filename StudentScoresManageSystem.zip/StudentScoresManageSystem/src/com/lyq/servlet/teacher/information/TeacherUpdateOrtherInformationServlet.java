package com.lyq.servlet.teacher.information;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherInformationService;

@WebServlet("/servlet/teacher/information/TeacherUpdateOrtherInformationServlet")
public class TeacherUpdateOrtherInformationServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到sevice类和session
		TeacherInformationService tis = new TeacherInformationService();
		HttpSession session = request.getSession();
		// 拿到保存在session中的Teacher类
		Teacher tch_info = (Teacher) session.getAttribute("tch_info");
		// 拿到用户输入的信息
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String e_mail = request.getParameter("e_mail");
		String course = request.getParameter("course");
		// 检查用户输入的数据的格式是否正确
		// 检查姓名
		if (!name.matches("[\u4E00-\u9FA5]{2,5}(?:·[\u4E00-\u9FA5]{2,5})*")) {
			request.setAttribute("NameFormatWrong", true);
			request.getRequestDispatcher("/teacher/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 检查性别
		if (!gender.matches("[男]|[女]")) {
			request.setAttribute("GenderFormatWrong", true);
			request.getRequestDispatcher("/teacher/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 检查手机号码
		if (!phone.matches("[0-9]{11}") && !"".equals(phone) && !(phone == null)) {
			request.setAttribute("PhoneFormatWrong", true);
			request.getRequestDispatcher("/teacher/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 检查地址
		if (!address.matches("^(?=.*?[\u4E00-\u9FA5])[\\dA-Za-z\u4E00-\u9FA5]+") && !"".equals(address)
				&& !(address == null)) {
			request.setAttribute("AddressFormatWrong", true);
			request.getRequestDispatcher("/teacher/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 检查邮箱
		if (!e_mail.matches("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$") && !"".equals(e_mail)
				&& !(e_mail == null)) {
			request.setAttribute("E_mailFormatWrong", true);
			request.getRequestDispatcher("/teacher/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 检查课程
		if (!course.matches("C|Java|Mysql|Html|Javascript") && !"".equals(address) && !(address == null)) {
			request.setAttribute("AddressFormatWrong", true);
			request.getRequestDispatcher("/teacher/information/updateOrtherInformation.jsp").forward(request, response);
			return;
		}
		// 用户输入数据格式正确
		// 将信息打包传入后台修改
		Teacher tch = new Teacher();
		tch.setId(tch_info.getId());
		tch.setName(name);
		tch.setGender(gender);
		tch.setPhone(phone);
		tch.setAddress(address);
		tch.setE_mail(e_mail);
		
		if (tis.updateTeacherInformation(tch)) {
			// 修改成功,更新session中的数据
			tch_info.setName(name);
			tch_info.setGender(gender);
			tch_info.setPhone(phone);
			tch_info.setAddress(address);
			tch_info.setE_mail(e_mail);
			response.getWriter().write("修改成功，三秒后返回主页！");
			response.getWriter().print(
					"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
		} else {
			response.getWriter().write("sorry...发生了未知的错误...");
			response.getWriter().write("三秒后返回主页！");
			response.getWriter().print(
					"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
		}
	}

}
