package com.lyq.servlet.teacher.manage.addStudent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Student;
import com.lyq.service.teacher.TeacherManageService;

@WebServlet("/servlet/teacher/manage/addStudent/AddStudentServlet")
public class AddStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到service
		TeacherManageService tms = new TeacherManageService();
		// 获得参数
		String stuGrade = request.getParameter("stuGrade");
		String stuClass = request.getParameter("stuClass");
		String prefix = request.getParameter("prefix");
		String gender = request.getParameter("gender");
		String password = request.getParameter("password");
		String ids = request.getParameter("ids");
		String names = request.getParameter("names");
		// 检查参数的正确性
		// 检查stuGrade和stuClass是否正确
		try {
			if (stuGrade == null || "".equals(stuGrade) || !tms.getGrades().contains(Integer.parseInt(stuGrade))) {
				response.getWriter().write("选择的年级不存在！");
				response.getWriter()
						.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
			}
		} catch (Exception e) {
			response.getWriter().write("选择的年级格式错误！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if (stuClass == null || "".equals(stuClass) || !tms.getClasses().contains(stuClass)) {
			response.getWriter().write("选择的班级不存在！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//检查剩下的参数
		if(prefix == null || "".equals(prefix.trim()) || !prefix.trim().matches("^[0-9]{6}")){	//可以输入1-10位数字进行模糊搜索
			response.getWriter().write("输入前缀格式错误，格式为6个数字！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		prefix = prefix.trim();
		if(gender == null || "".equals(gender) || !gender.matches("[男]|[女]")){
			response.getWriter().write("输入性别格式错误，只能输入 男 或者 女！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(password == null || "".equals(password.trim()) || !password.trim().matches("\\w{6,10}")){
			response.getWriter().write("输入的密码格式错误，只能输入6到10个字母、数字、下划线");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		password = password.trim();
		//检查ids和names并获得学号列表和姓名列表
		String[] StudentIds = null;
		if(ids == null || "".matches(ids.trim())){
			response.getWriter().write("请输入学号后缀");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else{
			StudentIds = ids.split("\n");
			for(int i = 0; i < StudentIds.length; i++){
				StudentIds[i] = StudentIds[i].trim();
				if(!StudentIds[i].matches("\\d{4}")){
					response.getWriter().write("第"+(i+1)+"个学号后缀错误<br>"
							+"为:  "+StudentIds[i]);
					response.getWriter()
							.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
					return;
				}
			}
		}
		String[] StudentNames = null;
		if(names == null || "".matches(names.trim())){
			response.getWriter().write("请输入学生姓名");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else{
			StudentNames = names.split("\n");
			for(int i = 0; i < StudentNames.length; i++){
				StudentNames[i] = StudentNames[i].trim();
				if(!StudentNames[i].matches("^(?=.*?[\u4E00-\u9FA5])[\\dA-Za-z\u4E00-\u9FA5]+")){
					response.getWriter().write("第"+(i+1)+"个学生姓名错误<br>"
							+"为:  "+StudentNames[i]);
					response.getWriter()
							.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
					return;
				}
			}
		}
		//确认输入的姓名和学号个数一样
		if(StudentIds.length != StudentNames.length){
			response.getWriter().write("输入的学号后缀个数和姓名个数不一致，请检查！<br>"
					+"建议一行只输入一个学号后缀或姓名");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		
		//添加学生并返回结果
		int totalRecord = StudentIds.length;	//总记录数
		int successNum = 0;	//添加成功个数
		int failureNum = 0;	//添加失败个数
		List<Student> successList = new ArrayList<Student>();	//添加成功的学生
		List<Student> failureList = new ArrayList<Student>();	//添加失败的学生 
		Student stu = null;
		for (int i = 0; i < StudentIds.length; i++) {
			stu = new Student();
			stu.setId(prefix + StudentIds[i]);
			stu.setName(StudentNames[i]);
			stu.setPassword(password);
			stu.setGender(gender);
			stu.setStuGrade(Integer.parseInt(stuGrade));
			stu.setStuClass(stuClass);
			if(tms.addStudent(stu)){
				//添加成功
				successNum++;
				successList.add(stu);
			}else{
				//添加失败
				failureNum++;
				failureList.add(stu);
			}
		}
		response.getWriter().write("总共接收到"+totalRecord+"条数据<br>"
				+ "其中添加成功了"+successNum+"条数据，分别为<hr>");
		Iterator<Student> successIterator = successList.iterator();
		while(successIterator.hasNext()){
			Student student = successIterator.next();
			response.getWriter().write(student.getId()+"   "+student.getName()+"<br>");
		}
		response.getWriter().write("<hr>添加失败的数据有"+failureNum+"条，分别为<hr>");
		Iterator<Student> failureIterator = failureList.iterator();
		while(failureIterator.hasNext()){
			Student student = failureIterator.next();
			response.getWriter().write(student.getId()+"   "+student.getName()+"<br>");
		}
		response.getWriter().write("<hr>");
		response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/teacher/main.jsp';\">");
		response.getWriter().write("<input type=\"button\" value=\"继续添加\" onclick=\"javascript:window.location='/StudentScoresManageSystem/teacher/manage/findStudentByInformation/index.jsp';\">");
	}

}
