package com.lyq.servlet.teacher.manage.scores;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Course;
import com.lyq.model.Scores;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherManageService;

@WebServlet("/servlet/teacher/manage/scores/EntryScoresServlet")
public class EntryScoresServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到service
		TeacherManageService tms = new TeacherManageService();
		// 拿到CourseId
		String CourseId = request.getParameter("CourseId");
		if (CourseId == null || "".equals(CourseId)) {
			response.getWriter().write("课程id不能为空！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if (!CourseId.matches("CRS\\d{3}")) {
			response.getWriter().write("课程id格式错误！！课程id由 CRS加上三个数字组成");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 获得session里的教师id
		Teacher tch_info = (Teacher) request.getSession().getAttribute("tch_info");
		String TeacherId = tch_info.getId();
		// 检查该课程的老师是不是当前教师
		Course course = tms.findCourseById(CourseId);
		if (!course.getTeacherId().equals(TeacherId)) {
			response.getWriter().write("您不是该课程的教师，不能录入该课程学生的成绩！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//执行录入成绩
		List<String> successList = new ArrayList<String>();	//录入成功的学生的信息
		List<String> failureList = new ArrayList<String>();	//录入失败的学生的信息
		Iterator<Entry<String, String[]>> iter =  request.getParameterMap().entrySet().iterator();
		Entry<String, String[]> er = null;
		//创建录入模型
		Scores score = new Scores(); 
		score.setCourseId(CourseId);
		while(iter.hasNext()){
			er = iter.next();
			//判断参数的名字是不是传入的学生的学号，如果是，拿到它的值进行录入成绩
			if(er.getKey().matches("\\d{10}")){
				//是学生学号，进行录入
				score.setStudentId(er.getKey());
				String[] s = er.getValue(); 
				//判断输入的成绩的格式，如果正确则添加，错误则将这条记录添加到失败的学生信息中去
				if(!s[0].trim().matches("^\\d+(\\.\\d+)?$")){
					failureList.add(er.getKey()+"  "+s[0]);
					continue;
				}
				try{
					double sc = Double.parseDouble(s[0]);
					if(sc > 0 && sc < 0.01){
						//如果教师输入的成绩大于0又小于0.01，则将输入的成绩设置为0.01
						sc = 0.01;
					}
					score.setScore(sc);
				}catch(Exception e){
					//转化为浮点数失败
					failureList.add(er.getKey()+"  "+s[0]);
					continue;
				}
				//执行录入
				if(tms.entryScore(score)){
					//录入成功
					successList.add(er.getKey()+"  "+s[0]);
				}else{
					//录入失败
					failureList.add(er.getKey()+"  "+s[0]);
				}
			}
		}
		//操作完毕，返回结果
		int totalRecord = successList.size() + failureList.size();//执行录入的学生的总数
		response.getWriter().write("收到" + totalRecord + "条数据<hr>");
		response.getWriter().write("录入成功的数据有" + successList.size() + "条，分别为<br>");
		for(String s : successList){
			response.getWriter().write(s+"<br>");
		}
		response.getWriter().write("<hr>录入失败的数据有" + failureList.size() + "条，分别为<br>");
		for(String s : failureList){
			response.getWriter().write(s+"<br>");
		}
		response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
