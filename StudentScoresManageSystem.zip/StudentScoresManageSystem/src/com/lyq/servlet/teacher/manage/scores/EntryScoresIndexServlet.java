package com.lyq.servlet.teacher.manage.scores;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Course;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherManageService;


@WebServlet("/servlet/teacher/manage/scores/EntryScoresIndexServlet")
public class EntryScoresIndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获得service
		TeacherManageService tmc = new TeacherManageService();
		//获得session中的teacherid
		Teacher tch_info = (Teacher) request.getSession().getAttribute("tch_info");
		String TeacherId = tch_info.getId();
		//获得默认学期
		String defaultterm = tmc.getDefaultTerm();
		//拿到教师本学期的课程列表
		List<Course> courses = tmc.findCourseByTeacher(TeacherId, defaultterm);
		

		//返回结果
		request.setAttribute("defaultterm", defaultterm);
		request.setAttribute("courses", courses);
		request.getRequestDispatcher("/teacher/manage/scores/entryScore.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
