package com.lyq.servlet.teacher.manage.findStudentByInformation;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Pager;
import com.lyq.model.Student;
import com.lyq.service.teacher.TeacherManageService;


@WebServlet("/servlet/teacher/manage/findStudentByInformation/TeacherFindStudentByInformationServlet")
public class TeacherFindStudentByInformationServlet extends HttpServlet {
	TeacherManageService tms = new TeacherManageService();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接受request里的参数
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String e_mail = request.getParameter("e_mail");
		String stuGrade = request.getParameter("stuGrade");
		String stuClass = request.getParameter("stuClass");
		
		
		//检查输入数据格式是否正确
		if(id != null && !"".equals(id.trim()) && !id.matches("^[0-9]{1,10}")){	//可以输入1-10位数字进行模糊搜索
			request.setAttribute("IdFormatWrong", true);
			request.getRequestDispatcher("/teacher/manage/findStudentByInformation/index.jsp").forward(request, response);
			return;
		}
		if(name != null && !"".equals(name.trim()) && !name.matches("[\u4E00-\u9FA5]{1,5}(?:·[\u4E00-\u9FA5]{2,5})*")){	//可以进行模糊搜索
			request.setAttribute("NameFormatWrong", true);
			request.getRequestDispatcher("/teacher/manage/findStudentByInformation/index.jsp").forward(request, response);
			return;
		}
		if(gender != null && !"".equals(gender) && !gender.matches("[男]|[女]|全部")){
			request.setAttribute("GenderFormatWrong", true);
			request.getRequestDispatcher("/teacher/manage/findStudentByInformation/index.jsp").forward(request, response);
			return;
		}
		if(phone != null && !"".equals(phone.trim()) && !phone.matches("[0-9]{11}")){		//手机号码必须为11位数字
			request.setAttribute("PhoneFormatWrong", true);
			request.getRequestDispatcher("/teacher/manage/findStudentByInformation/index.jsp").forward(request, response);
			return;
		}
		if(address != null && !"".equals(address.trim()) && !address.matches("^(?=.*?[\u4E00-\u9FA5])[\\dA-Za-z\u4E00-\u9FA5]+")){		//可以进行模糊搜索
			request.setAttribute("AddressFormatWrong", true);
			request.getRequestDispatcher("/teacher/manage/findStudentByInformation/index.jsp").forward(request, response);
			return;
		}
		if(e_mail != null && !"".equals(e_mail.trim()) &&!e_mail.matches("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$")){
			request.setAttribute("E_mailFormatWrong", true);
			request.getRequestDispatcher("/teacher/manage/findStudentByInformation/index.jsp").forward(request, response);
			return;
		}
		//检查stuGrade和stuClass是否正确
		try{
			if(stuGrade != null && !"".equals(stuGrade) && !tms.getGrades().contains(Integer.parseInt(stuGrade))){
				response.getWriter().write("选择的年级不存在！");
				response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
		}
		}catch(Exception e){
			response.getWriter().write("选择的年级格式错误！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if(stuClass != null && !"".equals(stuClass) && !tms.getClasses().contains(stuClass)){
			response.getWriter().write("选择的班级不存在！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		
		//检查pageNum
		String pageNumStr = request.getParameter("pageNum");
		if(pageNumStr !=null && !"".equals(pageNumStr.trim()) &&!pageNumStr.matches("^[1-9]\\d*$")){
			request.setAttribute("PageNumFormatWrong", true);
			request.getRequestDispatcher("/teacher/manage/findStudentByInformation/index.jsp").forward(request, response);
			return;
		}
		int pageNum = 1; //默认显示第一页数据
		if(pageNumStr!=null && !"".equals(pageNumStr.trim())){
			pageNum = Integer.parseInt(pageNumStr);
		}
		//检查pageSize
		String pageSizeStr = request.getParameter("pageSize");
		if(pageSizeStr!=null && !"".equals(pageSizeStr.trim()) &&!pageSizeStr.matches("^[1-9]\\d*$")){
			request.setAttribute("PageSizeFormatWrong", true);
			request.getRequestDispatcher("/teacher/manage/findStudentByInformation/index.jsp").forward(request, response);
			return;
		}
		int pageSize = 10;  // 默认显示10条数据
		if(pageSizeStr!=null && !"".equals(pageSizeStr.trim())){
			pageSize = Integer.parseInt(pageSizeStr);
		}
		// 组装查询条件
		Student searchModel = new Student(); 
		searchModel.setId(id.trim());
		searchModel.setName(name.trim());
		searchModel.setGender(gender.trim());
		searchModel.setPhone(phone.trim());
		searchModel.setAddress(address.trim());
		searchModel.setE_mail(e_mail.trim());
		try{
			searchModel.setStuGrade(Integer.parseInt(stuGrade));
		}catch(Exception E){
			
		}
		searchModel.setStuClass(stuClass);
		
		//调用service获取查询结果
		Pager<Student> result = tms.findStudent(searchModel, pageNum, pageSize);
		
		// 返回结果到页面
		request.setAttribute("result", result);
		request.setAttribute("id", id);
		request.setAttribute("name", name);
		request.setAttribute("gender", gender);
		request.setAttribute("phone", phone);
		request.setAttribute("address", address);
		request.setAttribute("e_mail", e_mail);
		request.setAttribute("pageSize", pageSize);
		request.setAttribute("stuGrade", stuGrade);
		request.setAttribute("stuClass", stuClass);
		request.getRequestDispatcher("/teacher/manage/findStudentByInformation/result.jsp").forward(request, response);
	}

}
