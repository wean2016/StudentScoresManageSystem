package com.lyq.servlet.teacher.manage.scores;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Course;
import com.lyq.model.Pager;
import com.lyq.model.Student;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherManageService;


@WebServlet("/servlet/teacher/manage/scores/EntryScoresPageServlet")
public class EntryScoresPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到service
		TeacherManageService tms = new TeacherManageService();
		// 拿到CourseId
		String CourseId = request.getParameter("CourseId");
		if (CourseId == null || "".equals(CourseId)) {
			response.getWriter().write("课程id不能为空！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if (!CourseId.matches("CRS\\d{3}")) {
			response.getWriter().write("课程id格式错误！！课程id由 CRS加上三个数字组成");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 获得session里的教师id
		Teacher tch_info = (Teacher) request.getSession().getAttribute("tch_info");
		String TeacherId = tch_info.getId();
		// 检查该课程的老师是不是当前教师
		Course course = tms.findCourseById(CourseId);
		if (!course.getTeacherId().equals(TeacherId)) {
			response.getWriter().write("您不是该课程的教师，不能录入该课程学生的成绩！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 检查pageNum
		String pageNumStr = request.getParameter("pageNum");
		if (pageNumStr != null && !"".equals(pageNumStr.trim()) && !pageNumStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请选择正确的页数！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageNum = 1; // 默认显示第一页数据
		if (pageNumStr != null && !"".equals(pageNumStr.trim())) {
			pageNum = Integer.parseInt(pageNumStr);
		}
		// 检查pageSize
		String pageSizeStr = request.getParameter("pageSize");
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim()) && !pageSizeStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请正确输入每页显示几条数据");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageSize = 10; // 默认显示10条数据
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim())) {
			pageSize = Integer.parseInt(pageSizeStr);
		}
		// 获得该课程的学生列表
		Pager<Student> result = tms.findStudentByCourse(CourseId, pageNum, pageSize);
		// 返回结果到页面
		request.setAttribute("result", result);
		request.setAttribute("course", course);
		request.setAttribute("pageSize", pageSize);
		request.getRequestDispatcher("/teacher/manage/scores/EntryScoresByCourse.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
