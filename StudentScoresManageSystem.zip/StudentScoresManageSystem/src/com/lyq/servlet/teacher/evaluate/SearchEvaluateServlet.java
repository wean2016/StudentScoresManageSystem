package com.lyq.servlet.teacher.evaluate;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Course;
import com.lyq.model.EvaluateAnalysis;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherEvaluateService;

@WebServlet("/servlet/teacher/evaluate/SearchEvaluateServlet")
public class SearchEvaluateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//拿到service
		TeacherEvaluateService tes = new TeacherEvaluateService();
		// 获得页面传来的参数
		String CourseId = request.getParameter("CourseId");
		if (CourseId == null || "".equals(CourseId.trim())) {
			response.getWriter().write("没有输入要分析的课程的id！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if(!CourseId.matches("CRS\\d{3}")){
			response.getWriter().write("输入要分析的课程的id格式错误！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 检查该课程的教师是否是本人
		Teacher tch_info = (Teacher) request.getSession().getAttribute("tch_info");
		String tch_id = tch_info.getId();// 执行操作的教师的id
		// 拿到该课程的信息
		Course crs = tes.findCourseById(CourseId);
		// 判断是否是本人查询
		if (!crs.getTeacherId().equals(tch_id)) {
			response.getWriter().write("您不是该课程的任课教师！不能查询该课程！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//调用service进行查询
		EvaluateAnalysis ea = tes.getEvaluateAnalysis(CourseId);
		List<String> result = tes.getEvaluateAnalysisChart(ea,  request.getSession().getServletContext().getRealPath("/chart/")); 
		//返回结果
		request.setAttribute("ea", ea);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/teacher/evaluate/searchEvulateResult.jsp").forward(request, response);
		
		
	}

}
