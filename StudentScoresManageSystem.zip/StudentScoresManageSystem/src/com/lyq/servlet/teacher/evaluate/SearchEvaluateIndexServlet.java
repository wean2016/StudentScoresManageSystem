package com.lyq.servlet.teacher.evaluate;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Course;
import com.lyq.model.Pager;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherCourseService;

@WebServlet("/servlet/teacher/evaluate/SearchEvaluateIndexServlet")
public class SearchEvaluateIndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得页面传来的参数
		String Cname = request.getParameter("Cname");
		String term = request.getParameter("term");
		String CourseId = request.getParameter("CourseId");
		// 检查输入数据格式是否正确
		if (Cname != null && !"".equals(Cname.trim()) && !Cname.trim().matches("[a-zA-Z\u4E00-\u9FA5]+")) {
			response.getWriter().write("输入的课程名称不正确，请输入中文！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		Cname = Cname.trim();
		List<String> terms = (List<String>) request.getSession().getAttribute("terms");
		if (term == null && "".equals(term) && !terms.contains(term)) {
			response.getWriter().write("选择的学期不存在！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		if (CourseId != null && !"".equals(CourseId.trim()) && !CourseId.trim().matches("CRS\\d{3}")) {
			response.getWriter().write("课程id格式错误！！课程id由 CRS加上三个数字组成");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		// 获得教师id
		Teacher tch_info = (Teacher) request.getSession().getAttribute("tch_info");
		String TeacherId = tch_info.getId();
		// 检查pageNum
		String pageNumStr = request.getParameter("pageNum");
		if (pageNumStr != null && !"".equals(pageNumStr.trim()) && !pageNumStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请选择正确的页数！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageNum = 1; // 默认显示第一页数据
		if (pageNumStr != null && !"".equals(pageNumStr.trim())) {
			pageNum = Integer.parseInt(pageNumStr);
		}
		// 检查pageSize
		String pageSizeStr = request.getParameter("pageSize");
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim()) && !pageSizeStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请正确输入每页显示几条数据");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageSize = 10; // 默认显示10条数据
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim())) {
			pageSize = Integer.parseInt(pageSizeStr);
		}
		// 组装查询条件
		Course crs = new Course();
		crs.setCname(Cname);
		crs.setTerm(term);
		crs.setCourseId(CourseId);
		crs.setTeacherId(TeacherId);
		// 调用service查询
		TeacherCourseService tcs = new TeacherCourseService();
		Pager<Course> result = tcs.findCourse(crs, pageNum, pageSize);
		// 返回结果到页面
		request.setAttribute("result", result);
		request.setAttribute("Cname", Cname);
		request.setAttribute("term", term);
		request.setAttribute("CourseId", CourseId);
		request.setAttribute("pageSize", pageSize);
		request.getRequestDispatcher("/teacher/evaluate/searchEvulate.jsp").forward(request, response);
	}

}
