package com.lyq.servlet.teacher.course;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Course;
import com.lyq.model.CourseAnalysisModel;
import com.lyq.model.Pager;
import com.lyq.model.Student;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherCourseService;

@WebServlet("/servlet/teacher/course/AnalysisCourseServlet")
public class AnalysisCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得service
		TeacherCourseService tcs = new TeacherCourseService();
		//获得参数
		String factor = request.getParameter("factor");
		String sequence = request.getParameter("sequence");
		//检查参数正确性
		//设置默认排序方式为按成绩降序
		if(factor == null || "".equals(factor.trim())){
			factor = "score";
		}
		if(factor != null && !"".equals(factor.trim())){
			factor = factor.trim();
			if(!factor.matches("id|name|gender|stuGrade|stuClass|score|GPA")){
				response.getWriter().write("要排序的元素不存在！");
				response.getWriter()
						.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
				return;
			}
		}
		if(sequence == null || "".equals(sequence.trim())){
			sequence = "DESC";
		}
		sequence = sequence.trim();
		if(!sequence.matches("ASC|DESC")){
			response.getWriter().write("排序方式不存在！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 获得courseid
		String CourseId = request.getParameter("CourseId");
		if (CourseId == null || "".equals(CourseId.trim())) {
			response.getWriter().write("没有输入要分析的课程的id！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if(!CourseId.matches("CRS\\d{3}")){
			response.getWriter().write("输入要分析的课程的id格式错误！！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 检查该课程的教师是否是本人
		Teacher tch_info = (Teacher) request.getSession().getAttribute("tch_info");
		String tch_id = tch_info.getId();// 执行操作的教师的id
		// 拿到该课程的信息
		Course crs = tcs.findCourseById(CourseId);
		// 判断是否是本人查询
		if (!crs.getTeacherId().equals(tch_id)) {
			response.getWriter().write("您不是该课程的任课教师！不能查询该课程！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		// 检查pageNum
		String pageNumStr = request.getParameter("pageNum");
		if (pageNumStr != null && !"".equals(pageNumStr.trim()) && !pageNumStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请选择正确的页数！");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageNum = 1; // 默认显示第一页数据
		if (pageNumStr != null && !"".equals(pageNumStr.trim())) {
			pageNum = Integer.parseInt(pageNumStr);
		}
		// 检查pageSize
		String pageSizeStr = request.getParameter("pageSize");
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim()) && !pageSizeStr.matches("^[1-9]\\d*$")) {
			response.getWriter().write("请正确输入每页显示几条数据");
			response.getWriter()
					.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int pageSize = 10; // 默认显示10条数据
		if (pageSizeStr != null && !"".equals(pageSizeStr.trim())) {
			pageSize = Integer.parseInt(pageSizeStr);
		}
		//调用service获取查询结果
		Pager<Student> result = tcs.analysisCourseStudent(CourseId, factor, sequence, pageNum, pageSize);
		List<CourseAnalysisModel> casList = tcs.CourseAnalysis(CourseId);
		String chartpathInStudent = tcs.getCourseAnalysisChartInStudent(crs, casList, request.getSession().getServletContext().getRealPath("/chart/"));
		String chartpathInScores = tcs.getCourseAnalysisChartInScores(crs, casList, request.getSession().getServletContext().getRealPath("/chart/"));
		// 返回结果到页面
		request.setAttribute("result", result);
		request.setAttribute("casList", casList);
		request.setAttribute("chartpathInStudent", chartpathInStudent);
		request.setAttribute("chartpathInScores", chartpathInScores);
		request.setAttribute("course", crs);
		request.setAttribute("CourseId", CourseId);
		request.setAttribute("factor", factor);
		request.setAttribute("sequence", sequence);
		request.getRequestDispatcher("/teacher/course/analysisCourseResult.jsp").forward(request, response);
	}

}
