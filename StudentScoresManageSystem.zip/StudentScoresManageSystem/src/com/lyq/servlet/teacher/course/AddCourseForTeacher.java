package com.lyq.servlet.teacher.course;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherCourseService;

@WebServlet("/servlet/teacher/course/AddCourseForTeacher")
public class AddCourseForTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//拿到service
		TeacherCourseService tcs = new TeacherCourseService();
		//接受request里的参数
		String CourseId = request.getParameter("CourseId");
		if(CourseId == null || "".equals(CourseId)){
			response.getWriter().write("课程id不能为空！！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		CourseId = CourseId.trim();
		if(!CourseId.matches("CRS\\d{3}")){
			response.getWriter().write("课程id格式错误！！课程id由 CRS加上三个数字组成");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//获得session里的教师id
		Teacher tch_info = (Teacher) request.getSession().getAttribute("tch_info");
		String TeacherId = tch_info.getId();
		//执行添加
		if(tcs.addCourseForTeacher(CourseId, TeacherId)){
			response.getWriter().write("添加成功<hr>");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/teacher/main.jsp';\">");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
		}else{
			response.getWriter().write("添加失败！该课程已经有教师！");
			response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
