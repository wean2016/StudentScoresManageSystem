package com.lyq.servlet.teacher.inform;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringEscapeUtils;

import com.lyq.model.Inform;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherInformService;
import com.lyq.util.FileTypeUtils;

@WebServlet("/servlet/teacher/inform/UpdateInformServlet")
public class UpdateInformServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 加载service
		TeacherInformService tis = new TeacherInformService();
		// 拿到session
		HttpSession session = request.getSession();
		// 拿到修改通知的人的姓名
		Teacher tch_info = (Teacher) session.getAttribute("tch_info");
		String publisher = tch_info.getName();
		// 获得页面传来的数据
		int id = -1;//默认-1，若是没有收到数据，则报错
		String title = null;
		String content = null;
		String operation = null;
		String attachmentName = null;
		String attachmentUrl = null;
		boolean hasAttachment = false;//默认标记没有接收到附件
		// 创建工厂类
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(factory);
		// 设置单个文件大小限制
		sfu.setFileSizeMax(1024 * 1024 * 10);// 10M
		try {
			// 转化request
			List<FileItem> fiList = sfu.parseRequest(request);
			for (FileItem fi : fiList) {
				// 获得表单文本域的名字
				String fieldName = fi.getFieldName();
				// 是否是文件类型
				boolean isComm = fi.isFormField();
				// 获得原始文件名
				String oriFileName = fi.getName();
				// 如果是普通数据
				if (isComm && fieldName != null && !"".equals(fieldName)) {
					// 该FileItem的内容
					String fi_content = fi.getString();
					fi_content = new String(fi_content.getBytes("ISO_8859-1"), "UTF-8");
					// 拿到表单中的title
					if (fieldName.equals("title")) {
						// 检查格式
						if (!fi_content.matches("^[\\da-zA-Z\\u4e00-\\u9fa5]+$")) {
							response.getWriter().write("通知标题不正确，只能输入中文和英文<br>");
							response.getWriter().write(
									"<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
							return;
						}
						title = fi_content;
					}
					// 拿到content
					if (fieldName.equals("content")) {
						// 对用户输入的内容进行html转义并存入content
						content = StringEscapeUtils.escapeHtml(fi_content);
					}
					//拿到id
					if (fieldName.equals("id")) {
						// 检查格式
						if(!fi_content.matches("\\d+")){
							//id格式不正确
							response.getWriter().write("sorry..系统发生了错误..接收到的部分参数错误<br>");
							response.getWriter().write("三秒后将返回主页");
							response.getWriter().print(
									"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
							return;
						}
						id = Integer.parseInt(fi_content);
					}
					
					
					//拿到是否有附件
					if (fieldName.equals("operation")) {
						System.out.println(fi_content);
						// 检查格式
						if(!fi_content.matches("nooperation|delete|update")){
							//operation格式不正确
							response.getWriter().write("sorry..系统发生了错误..接收到的部分参数错误<br>");
							response.getWriter().write("三秒后将返回主页");
							response.getWriter().print(
									"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
							return;
						}
						operation = fi_content;
					}
					
				}
				// 如果是文件(教师上传的附件)
				if (!isComm && fieldName != null && !"".equals(fieldName)) {
					// 获得要上传的绝对路径
					String realPath = request.getSession().getServletContext().getRealPath("/WEB-INF/attachment/");
					if (oriFileName != null && !"".equals(oriFileName.trim())) {
						String suffix = oriFileName.substring(oriFileName.lastIndexOf("."));
						// 获得文件类型
						String fileType = FileTypeUtils.getFileType(fi.getInputStream());
						// 判断文件名后缀和和文件后缀是否一样且文件后缀是否符合条件
						if (!suffix.equals(".rar") && !suffix.equals(".zip")) {
							response.getWriter().write("附件后缀不符合规范，只能上传rar或zip压缩文档<br>");
							response.getWriter().write(
									"<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
							return;
						} else if (!suffix.equals(fileType)) {
							response.getWriter().write("附件真实类型与文件名后缀不一致，请检查！<br>");
							response.getWriter().write(
									"<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
							return;
						}
						// 生成文件在服务器中的名字
						String tFileName = UUID.randomUUID().toString() + "_" + publisher + "_" + oriFileName;
						attachmentName = oriFileName;
						attachmentUrl = "/WEB-INF/attachment/" + tFileName;
						File file = new File(realPath, tFileName);
						fi.write(file);
					}
					hasAttachment = true;//接收到附件
				}
			}
			//拿到服务器中的原来的Inform
			Inform db_inform = tis.findInformById(id);
			if(db_inform == null){
				response.getWriter().write("sorry..未知的错误<br>");
				response.getWriter().write("三秒后将返回主页");
				response.getWriter().print(
						"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
				return;
			}
			if(!db_inform.getPublisher().equals(publisher)){
				response.getWriter().write("只能修改自己发布的通知！<br>");
				response.getWriter().write("三秒后将返回主页");
				response.getWriter().print(
						"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
				return;
			}
			// 将数据保存
			Inform im = new Inform();
			im.setId(id);
			im.setTitle(title);
			im.setContent(content);
			if("nooperation".equals(operation)){
				//无操作
				//将附件名和附件地址设置为原来的数据
				im.setAttachmentName(db_inform.getAttachmentName());
				im.setAttachmentUrl(db_inform.getAttachmentUrl());
			}else if("delete".equals(operation)){
				//删除
				//将附件名和附件地址设置为空
				im.setAttachmentName(null);
				im.setAttachmentUrl(null);
			}else if("update".equals(operation)){
				//更新
				//检查是否接收到附件
				if(hasAttachment){
					//成功接受到附件
					//将附件名和附件地址设置为接收到的数据
					im.setAttachmentName(attachmentName);
					im.setAttachmentUrl(attachmentUrl);
				}else{
					//没有接收到附件
					response.getWriter().write("sorry..未知的错误<br>");
					response.getWriter().write("三秒后将返回主页");
					response.getWriter().print(
							"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
					return;
				}
			}else{
				//operation的值不正确
				response.getWriter().write("sorry..未知的错误<br>");
				response.getWriter().write("三秒后将返回主页");
				response.getWriter().print(
						"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
				return;
			}
			if (tis.updateInform(im)) {
				response.getWriter().write("发布成功！<br>");
				response.getWriter().write("三秒后自动返回主页！");
				response.getWriter().print(
						"<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
			} else {
				response.getWriter().write("sorry...发生了未知的错误...<br>");
				response.getWriter()
						.write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
