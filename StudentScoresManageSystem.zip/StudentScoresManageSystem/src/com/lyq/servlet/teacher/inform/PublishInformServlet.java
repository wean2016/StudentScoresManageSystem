package com.lyq.servlet.teacher.inform;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringEscapeUtils;

import com.lyq.model.Inform;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherInformService;
import com.lyq.util.FileTypeUtils;

/**
 * Servlet implementation class PublishInformServlet
 */
@WebServlet("/servlet/teacher/inform/PublishInformServlet")
public class PublishInformServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//加载service 
		TeacherInformService tis = new TeacherInformService();
		//拿到session
		HttpSession session = request.getSession();
		//拿到通知的发布者
		Teacher tch_info = (Teacher) session.getAttribute("tch_info");
		String publisher = tch_info.getName();
		//拿到时间
		Calendar ca = Calendar.getInstance();
		Date date = new Date(ca.getTimeInMillis());
		//获得页面传来的数据
		String title = null;
		String content = null;
		String attachmentName = null;
		String attachmentUrl = null;
		//创建工厂类
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(factory);
		//设置单个文件大小限制
		sfu.setFileSizeMax(1024*1024*10);//10M
		try {
			//转化request
			List<FileItem> fiList = sfu.parseRequest(request);
			for(FileItem fi : fiList){
				//获得表单文本域的名字
				String fieldName = fi.getFieldName();
				//是否是文件类型
				boolean isComm = fi.isFormField();
				//获得原始文件名
				String oriFileName = fi.getName();
				//如果是普通数据
				if(isComm && fieldName != null && !"".equals(fieldName)){
					//该FileItem的内容
					String fi_content = fi.getString();
					fi_content = new String(fi_content.getBytes("ISO_8859-1"),"UTF-8");
					//拿到表单中的title
					if(fieldName.equals("title")){
						//检查格式
						if(!fi_content.matches("^[\\da-zA-Z\\u4e00-\\u9fa5]+$")){
							response.getWriter().write("通知标题不正确，只能输入中文和英文<br>");
							response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
							return;
						}
						title = fi_content;
					}
					//拿到content
					if(fieldName.equals("content")){
						//对用户输入的内容进行html转义并存入content
						content = StringEscapeUtils.escapeHtml(fi_content);
					}
				}
				//如果是文件(教师上传的附件)
				if(!isComm && fieldName != null && !"".equals(fieldName)){
					//获得要上传的绝对路径
					String realPath = request.getSession().getServletContext().getRealPath("/WEB-INF/attachment/");
					if(oriFileName != null && !"".equals(oriFileName.trim())){
						String suffix = oriFileName.substring(oriFileName.lastIndexOf("."));
						//获得文件类型
						String fileType = FileTypeUtils.getFileType(fi.getInputStream());
						//判断文件名后缀和和文件后缀是否一样且文件后缀是否符合条件
						if(!suffix.equals(".rar") && !suffix.equals(".zip")){
							response.getWriter().write("附件后缀不符合规范，只能上传rar或zip压缩文档<br>");
							response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
							return;
						}else if(!suffix.equals(fileType)){
							response.getWriter().write("附件真实类型与文件名后缀不一致，请检查！<br>");
							response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
							return;
						}
						//生成文件在服务器中的名字
						String tFileName = UUID.randomUUID().toString()+"_"+publisher+"_"+oriFileName;
						attachmentName = oriFileName;
						attachmentUrl = "/WEB-INF/attachment/"+tFileName;
						File file = new File(realPath,tFileName);
						fi.write(file);
					}
				}
			}
			//将数据保存
			Inform im =  new Inform();
			im.setPublisher(publisher);
			im.setPublishTime(date);
			im.setUpdateTime(date);
			im.setTitle(title);
			im.setContent(content);
			im.setAttachmentName(attachmentName);
			im.setAttachmentUrl(attachmentUrl);
			
			if(tis.addInform(im)){
				response.getWriter().write("发布成功！<br>");
				response.getWriter().write("三秒后自动返回主页！");
				response.getWriter().print("<script language=\"javascript\">setTimeout(\"window.location='/StudentScoresManageSystem/teacher/main.jsp'\",3000)</script>");
			}else{
				response.getWriter().write("sorry...发生了未知的错误...<br>");
				response.getWriter().write("<input type=\"button\" value=\"后退\" onclick=\"javascript:window.history.back(-1);\">");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
