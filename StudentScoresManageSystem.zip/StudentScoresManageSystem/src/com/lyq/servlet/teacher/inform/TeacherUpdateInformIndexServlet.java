package com.lyq.servlet.teacher.inform;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lyq.model.Inform;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherInformService;

@WebServlet("/servlet/teacher/inform/TeacherUpdateInformIndexServlet")
public class TeacherUpdateInformIndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 拿到service
		TeacherInformService tis = new TeacherInformService();
		// 拿到session中的Teacher的名字
		HttpSession session = request.getSession();
		Teacher tch_info = (Teacher) session.getAttribute("tch_info");
		String tch_info_name = tch_info.getName();
		// 拿到要修改的通知的id
		String idStr = request.getParameter("id");
		if (idStr == null && !"".equals(idStr.trim())) {
			response.getWriter().write("sorry...没有接收到参数<br>");
			response.getWriter()
					.write("<input type=\"button\" value=\"返回\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		} else if (!idStr.trim().matches("\\d+")) {
			response.getWriter().write("sorry...接收到的参数格式错误<br>");
			response.getWriter()
					.write("<input type=\"button\" value=\"返回\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int id = Integer.parseInt(idStr.trim());
		// 拿到要修改的inform的发布者名字和当前账号的发布者名字做比较，若一样则转发到修改页面，若不一样则拒绝修改
		Inform im = tis.findInformById(id);
		String publisher = im.getPublisher();
		if (!tch_info_name.equals(publisher)) { // 名字不一样
			response.getWriter().write("sorry...只能修改自己发布的通知<br>");
			response.getWriter()
					.write("<input type=\"button\" value=\"返回\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else{
			// 名字一样，转发页面
			request.setAttribute("inform", im);
			request.getRequestDispatcher("/teacher/inform/updateInform.jsp").forward(request, response);
		}

	}

}
