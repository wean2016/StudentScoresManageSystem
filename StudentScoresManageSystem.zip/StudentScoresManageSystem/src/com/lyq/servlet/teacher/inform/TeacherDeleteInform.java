package com.lyq.servlet.teacher.inform;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lyq.model.Inform;
import com.lyq.model.Teacher;
import com.lyq.service.teacher.TeacherInformService;

/**
 * Servlet implementation class TeacherDeleteInform
 */
@WebServlet("/servlet/teacher/inform/TeacherDeleteInform")
public class TeacherDeleteInform extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//拿到service
		TeacherInformService tis = new TeacherInformService();
		//拿到session中的Teacher的名字
		HttpSession session = request.getSession();
		Teacher tch_info = (Teacher) session.getAttribute("tch_info");
		String tch_info_name = tch_info.getName();
		//拿到要删除的通知的id
		String idStr = request.getParameter("id");
		if(idStr == null && !"".equals(idStr.trim())){
			response.getWriter().write("sorry...没有接收到参数<br>删除失败..");
			response.getWriter().write("<input type=\"button\" value=\"返回\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}else if(!idStr.trim().matches("\\d+")){
			response.getWriter().write("sorry...接收到的参数格式错误<br>删除失败..");
			response.getWriter().write("<input type=\"button\" value=\"返回\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		int id = Integer.parseInt(idStr.trim());
		//拿到要删除的inform的发布者名字和当前账号的发布者名字做比较，若一样则执行删除，若不一样则拒绝删除
		Inform im = tis.findInformById(id);
		String publisher = im.getPublisher();
		if(!tch_info_name.equals(publisher)){		//名字不一样
			response.getWriter().write("sorry...只能删除自己发布的通知<br>");
			response.getWriter().write("<input type=\"button\" value=\"返回\" onclick=\"javascript:window.history.back(-1);\">");
			return;
		}
		//名字一样，执行删除
		if(tis.deleteInform(id)){
			//删除成功
			response.getWriter().write("删除成功！<br>");
			response.getWriter().write("<input type=\"button\" value=\"返回上一页\" onclick=\"javascript:window.history.back(-1);\">");
			response.getWriter().write("<input type=\"button\" value=\"返回主页\" onclick=\"javascript:window.location='/StudentScoresManageSystem/teacher/main.jsp';\">");
		}else{
			//删除失败
			response.getWriter().write("sorry...发生了未知的错误...删除失败<br>");
			response.getWriter().write("<input type=\"button\" value=\"返回\" onclick=\"javascript:window.history.back(-1);\">");
		}
	}

}
